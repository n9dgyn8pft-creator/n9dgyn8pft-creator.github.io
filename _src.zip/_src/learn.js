  // ====================================================================
  //  ВЕНТИЛЯЦИЯ: расчёт и обучалка
  // ====================================================================
  const rhoAir = t => 353 / (273 + t);
  const draftPa = (H, ti, to) => Math.max(0, H * 9.81 * (rhoAir(to) - rhoAir(ti)));
  const ventVel = dp => Math.min(1.0, Math.sqrt(2 * dp / (1.2 * 8)));
  const CH = { b140: ["Кирпичный 140×140", 0.0196], b140x270: ["Кирпичный 140×270", 0.0378], r125: ["Круглый Ø125", 0.0123], r150: ["Круглый Ø150", 0.0177], vb: ["Вентблок 150×200", 0.03] };
  add({
    id: "vent", cat: "tech", mark: "по тяге", name: "Естественная вентиляция: каналы и приток", kw: "вентиляция естественная вытяжка приток вентканал канал сечение кухня санузел клапан кив переток тяга котельная воздухообмен",
    desc: "Нормы воздухообмена, тяга по высоте канала, сколько каналов и приточных клапанов нужно",
    inputs: [
      { k: "area", label: "Жилая площадь (комнаты), м²", def: 80 },
      { k: "people", label: "Проживает человек", def: 4 },
      { k: "rooms", label: "Жилых комнат", def: 4 },
      { k: "stove", label: "Плита на кухне", type: "sel", def: "el", opts: [["el", "Электрическая — 60 м³/ч"], ["gas", "Газовая — 90 м³/ч"]] },
      { k: "comb", label: "Совмещённых санузлов", def: 1 },
      { k: "bath", label: "Отдельных ванных / душевых", def: 0 },
      { k: "wc", label: "Отдельных туалетов", def: 1 },
      { k: "boil", label: "Котельная (топочная)", type: "check", def: false },
      { k: "bv", label: "Объём котельной, м³", def: 15, show: v => v.boil },
      { k: "bkw", label: "Мощность котла, кВт", def: 24, show: v => v.boil },
      { k: "fl", label: "Этажей", type: "sel", def: "2", opts: [["1", "1"], ["2", "2"]] },
      { k: "up", label: "Из них санузлов на 2-м этаже", def: 1, show: v => v.fl === "2" },
      { k: "H1", label: "Высота канала с 1-го этажа, м", def: 7.5, hint: "От решётки до верха трубы" },
      { k: "H2", label: "Высота канала со 2-го этажа, м", def: 4.5, show: v => v.fl === "2" },
      { k: "ch", label: "Тип канала", type: "sel", def: "b140", opts: Object.entries(CH).map(([k, c]) => [k, c[0] + " (" + nf(c[1] * 1e4, 0) + " см²)"]) }
    ],
    run(v) {
      const ti = 20, to = 5, A = CH[v.ch][1];
      const cap = H => { const dp = draftPa(H, ti, to), vel = ventVel(dp); return { dp, vel, q: A * vel * 3600 }; };
      const two = v.fl === "2", up = two ? Math.min(v.up, v.comb + v.bath + v.wc) : 0;
      const rooms = [];
      const addR = (name, L, H, n) => { for (let i = 0; i < n; i++) rooms.push({ name: n > 1 ? name + " " + (i + 1) : name, L, H }); };
      addR("Кухня", v.stove === "gas" ? 90 : 60, v.H1, 1);
      let upLeft = up;
      const wet = [["Совмещённый санузел", 50, v.comb], ["Ванная / душевая", 25, v.bath], ["Туалет", 25, v.wc]];
      wet.forEach(([nm, L, n]) => { for (let i = 0; i < n; i++) { const onUp = upLeft > 0; if (onUp) upLeft--; rooms.push({ name: nm + (n > 1 ? " " + (i + 1) : "") + (onUp ? " (2 эт.)" : ""), L, H: onUp ? v.H2 : v.H1 }); } });
      if (v.boil) rooms.push({ name: "Котельная", L: Math.round(3 * v.bv), H: v.H1 });
      let ex = 0, chTot = 0, maxCh = 0;
      const rows = rooms.map(r => { const c = cap(r.H), n = Math.max(1, ceil(r.L / c.q)); ex += r.L; chTot += n; maxCh = Math.max(maxCh, n); return [r.name, nint(r.L), nf(r.H, 1) + " м", nf(c.dp, 1) + " Па", nf(c.vel, 2) + " м/с", nint(c.q) + " м³/ч", String(n)]; });
      const need = Math.max(ex, v.people * 30, v.area * 3);
      const valves = Math.max(v.rooms, ceil(need / 25));
      const doors = v.comb + v.bath + v.wc + 1 + (v.boil ? 1 : 0);
      const items = [["Решётка вытяжная регулируемая", chTot, "шт."], ["Приточный стеновой клапан (КИВ-125 или аналог)", valves, "шт."], ["Переточная решётка в дверь (или подрезка полотна 20 мм)", doors, "шт."]];
      if (v.boil) items.push(["Приточная решётка котельной ≥ 0,02 м²", 1, "шт."]);
      const warn = maxCh > 2 ? "Для некоторых помещений нужно 3 и больше каналов — увеличьте сечение (140×270, вентблок) или поднимите трубу выше: тяга растёт с высотой." : "";
      return {
        stats: [S("Вытяжка всего", nint(ex), "м³/ч", "по нормам для кухни и санузлов"), S("Нужно притока", nint(need), "м³/ч", "≥ 30 м³/ч на человека и ≥ 3 м³/ч на м²"), S("Вытяжных каналов", nint(chTot), "шт.", CH[v.ch][0], true), S("Приточных клапанов", nint(valves), "шт.", "≈ 25 м³/ч каждый, минимум по одному на комнату"), S("Тяга со 2-го этажа", two ? nf(cap(v.H2).dp, 1) : nf(cap(v.H1).dp, 1), "Па", "при +5 °C снаружи — расчётный случай")],
        warn, note: "Расчёт по наихудшему режиму СП 60: снаружи +5 °C, внутри +20 °C. Зимой тяга в 2–3 раза сильнее — ставьте регулируемые решётки.",
        table: { head: ["Помещение", "Норма, м³/ч", "Канал", "Тяга", "Скорость", "1 канал даёт", "Каналов"], rows },
        blocks: [{ html: '<p>Не знаете, с чего начать? ' + goBtn("ventguide", "Обучалка по естественной вентиляции") + "</p>" }],
        items
      };
    },
    info: "Тяга: Δp = H·g·(ρнар − ρвн), плотность воздуха ρ = 353 / (273 + t). Скорость в канале — из баланса давления и сопротивлений (решётки, вход, поворот, выход, приток и перетоки, суммарный КМС ≈ 8), но не больше 1 м/с. Нормы вытяжки — СП 54.13330 и СП 60.13330: кухня 60 м³/ч с электроплитой и 90 м³/ч с газовой, ванная и туалет по 25, совмещённый санузел 50; котельная — 3 обмена в час плюс воздух на горение."
  });

  // ---------- Обучалка ----------
  function houseSVG() {
    return '<svg viewBox="0 0 640 400" class="lv-svg" role="img" aria-label="Схема движения воздуха в доме"><defs><marker id="ab" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M0 0L10 5L0 10z" fill="#3b82c4"/></marker><marker id="ao" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M0 0L10 5L0 10z" fill="#e0710f"/></marker></defs>' +
      '<path d="M60 150 L320 40 L580 150" class="lv-roof"/><rect x="80" y="150" width="480" height="230" class="lv-house"/><line x1="80" y1="265" x2="560" y2="265" class="lv-wall"/><line x1="320" y1="150" x2="320" y2="380" class="lv-wall"/>' +
      '<rect x="316" y="236" width="8" height="29" class="lv-gap"/><rect x="316" y="351" width="8" height="29" class="lv-gap"/>' +
      '<rect x="470" y="40" width="22" height="225" class="lv-duct"/><rect x="500" y="62" width="22" height="318" class="lv-duct"/>' +
      '<text x="200" y="180" class="lv-t" text-anchor="middle">Спальня</text><text x="440" y="180" class="lv-t" text-anchor="middle">Санузел</text><text x="200" y="295" class="lv-t" text-anchor="middle">Гостиная</text><text x="420" y="295" class="lv-t" text-anchor="middle">Кухня</text>' +
      '<rect x="80" y="220" width="10" height="14" class="lv-valve"/><rect x="80" y="335" width="10" height="14" class="lv-valve"/>' +
      '<path d="M20 227 H120 Q200 227 230 245 T312 254" class="lv-fb" marker-end="url(#ab)"/><path d="M20 342 H120 Q200 342 240 360 T312 368" class="lv-fb" marker-end="url(#ab)"/>' +
      '<path d="M330 252 Q400 240 465 200" class="lv-fb" marker-end="url(#ab)"/><path d="M330 366 Q420 350 495 300" class="lv-fb" marker-end="url(#ab)"/>' +
      '<path d="M481 215 V30" class="lv-fo" marker-end="url(#ao)"/><path d="M511 330 V52" class="lv-fo" marker-end="url(#ao)"/>' +
      '<text x="18" y="215" class="lv-s">приточный клапан</text><text x="282" y="230" class="lv-s" text-anchor="end">переток под дверью</text><text x="530" y="24" class="lv-s">вытяжные каналы</text><text x="530" y="36" class="lv-s">выше кровли</text>' +
      '<text x="320" y="396" class="lv-s" text-anchor="middle">свежий воздух — в жилые комнаты, вытяжка — из кухни и санузлов</text></svg>';
  }
  function roofSVG() {
    return '<svg viewBox="0 0 640 260" class="lv-svg" role="img" aria-label="Высота вентканала над кровлей"><path d="M40 230 L320 90 L600 230" class="lv-roof"/>' +
      '<line x1="320" y1="90" x2="600" y2="139" class="lv-dash"/><text x="560" y="128" class="lv-s" text-anchor="end">линия 10° от конька</text>' +
      '<rect x="345" y="48" width="16" height="56" class="lv-duct"/><line x1="320" y1="48" x2="345" y2="48" class="lv-dim"/><text x="368" y="58" class="lv-s">до 1,5 м от конька: ≥ 0,5 м выше конька</text>' +
      '<rect x="420" y="86" width="16" height="56" class="lv-duct"/><line x1="300" y1="90" x2="430" y2="90" class="lv-dash"/><text x="442" y="96" class="lv-s">1,5–3 м: не ниже конька</text>' +
      '<rect x="520" y="104" width="16" height="78" class="lv-duct"/><text x="540" y="200" class="lv-s" text-anchor="end">дальше 3 м: не ниже линии 10°</text>' +
      '<text x="40" y="252" class="lv-s">Иначе ветер «задувает» канал — тяга опрокидывается. Над плоской кровлей — не менее 0,5 м.</text></svg>';
  }
  function stackSVG() {
    return '<svg viewBox="0 0 640 236" class="lv-svg" role="img" aria-label="Тяга"><rect x="260" y="20" width="40" height="185" class="lv-duct"/><path d="M280 200 V30" class="lv-fo" marker-end="url(#ao2)"/><defs><marker id="ao2" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M0 0L10 5L0 10z" fill="#e0710f"/></marker></defs>' +
      '<text x="250" y="110" class="lv-t" text-anchor="end">тёплый воздух +20 °C</text><text x="250" y="126" class="lv-s" text-anchor="end">легче — поднимается</text><text x="310" y="110" class="lv-t">холодный снаружи</text><text x="310" y="126" class="lv-s">тяжелее — давит снизу</text>' +
      '<line x1="330" y1="20" x2="330" y2="210" class="lv-dim"/><text x="338" y="30" class="lv-s">H — высота канала</text><text x="320" y="228" class="lv-s" text-anchor="middle">Δp = H · g · (ρ снаружи − ρ внутри) ≈ 0,04 · H · Δt, Па</text></svg>';
  }
  const LESSONS = [
    { t: "Как работает естественная вентиляция", h: () => "<p>Вентиляция без вентиляторов работает за счёт <b>тяги</b>: тёплый воздух в доме легче холодного уличного и уходит вверх по вертикальным каналам, а на его место через приточные отверстия заходит свежий. Чем выше канал и чем холоднее на улице, тем сильнее тяга.</p>" + stackSVG() + '<div class="lv-play"><label><span>Высота канала: <b data-o="hv">5</b> м</span><input type="range" min="2" max="12" step="0.5" value="5" data-i="h"></label><label><span>Снаружи: <b data-o="tv">5</b> °C</span><input type="range" min="-25" max="25" step="1" value="5" data-i="t"></label><div class="lv-res" data-o="res"></div></div><p>Подвигайте ползунки: зимой тяга сильная, а летом, когда на улице +20…+25 °C, её почти нет. Поэтому летом естественная вентиляция работает за счёт открытых окон, а расчёт ведут для +5 °C — это самый слабый режим отопительного сезона.</p>' },
    { t: "Путь воздуха по дому", h: () => "<p>Главное правило: <b>свежий воздух подаётся в «чистые» помещения</b> — спальни, гостиную, кабинет, — а <b>удаляется из «грязных»</b> — кухни, санузлов, гардеробных, котельной. По дороге он проходит через двери и коридор. Так запахи и влага не расходятся по дому.</p>" + houseSVG() + "<p>Если поменять местами — сделать вытяжку в спальне, а приток на кухне, — запах готовки разойдётся по всему дому.</p>" },
    { t: "Приток: откуда брать свежий воздух", h: () => '<p>В старых домах воздух заходил через щели в деревянных окнах. Пластиковые окна герметичны, и без отдельного притока вытяжка просто перестаёт работать: воздуху неоткуда прийти. Отсюда духота, сырость, плесень на откосах.</p><table class="data lv-t2"><thead><tr><th>Решение</th><th>Плюсы</th><th>Минусы</th></tr></thead><tbody><tr><td>Стеновой приточный клапан (КИВ)</td><td>20–35 м³/ч, регулируется, есть шумоглушение и фильтр</td><td>Нужно сверлить стену Ø 125–160 мм</td></tr><tr><td>Оконный клапан в раме</td><td>Не нужно сверлить стену</td><td>Меньше расход, зимой может обмерзать</td></tr><tr><td>Микропроветривание окна</td><td>Бесплатно</td><td>Нет фильтра и регулировки, сквозняк</td></tr></tbody></table><p><b>Куда ставить:</b> за радиатором под окном (воздух сразу прогревается) или под потолком на высоте 2–2,2 м. <b>Сколько:</b> не меньше одного на каждую жилую комнату — примерно 30 м³/ч на человека.</p>' },
    { t: "Перетоки: путь через двери", h: () => "<p>Воздух должен свободно пройти из комнаты в комнату к вытяжке. Плотно закрытая дверь в санузел без зазора полностью «выключает» вентиляцию в нём.</p><ul class=\"rules\"><li>Зазор под дверью <b>15–20 мм</b> — достаточно для комнаты и санузла.</li><li>Или переточная решётка в полотне двери — около 200×100 мм.</li><li>Двери в котельную — обязательно решётка, площадь — по паспорту котла.</li><li>Порог в санузле — тогда только решётка.</li></ul>" },
    { t: "Вытяжные каналы", h: () => '<table class="data lv-t2"><thead><tr><th>Помещение</th><th>Вытяжка по нормам</th></tr></thead><tbody><tr><td>Кухня с электроплитой</td><td>60 м³/ч</td></tr><tr><td>Кухня с газовой плитой</td><td>90 м³/ч</td></tr><tr><td>Ванная, туалет</td><td>по 25 м³/ч</td></tr><tr><td>Совмещённый санузел</td><td>50 м³/ч</td></tr><tr><td>Котельная</td><td>3 обмена в час + воздух на горение</td></tr></tbody></table><ul class="rules"><li><b>Отдельный канал от каждого помещения</b>: объединять кухню и санузел в один канал нельзя — запахи пойдут в соседнюю комнату.</li><li>Минимум — кирпичный 140×140 мм или круглый Ø 125–150 мм. Стенки гладкие.</li><li>Канал вертикальный, допускается отклонение до 30° на длине не больше 1 м.</li><li>На холодном чердаке и над кровлей канал <b>утепляют</b> — иначе он остывает, в нём выпадает конденсат, и тяга «опрокидывается».</li><li>Каналы со второго этажа короче — тяга в них слабее, им нужно большее сечение.</li></ul>' + roofSVG() },
    { t: "Кухня, котельная, камин", h: () => "<ul class=\"rules\"><li><b>Кухонный зонт с вентилятором</b> подключайте к отдельному каналу или каналу-спутнику. Если загнать его в единственный канал кухни, при выключенном зонте канал перекрыт его коробом, а при включённом вентилятор выдувает воздух в соседние каналы.</li><li><b>Газ на кухне</b> — окно с открывающейся створкой, вытяжной канал, приток (зазор под дверью); требования — СП 62.13330 и проект газификации.</li><li><b>Котельная</b> — постоянный приток с улицы через решётку (для горения), вытяжной канал под потолком и <b>отдельный дымоход</b>. Котёл с закрытой камерой берёт воздух коаксиальной трубой.</li><li><b>Камин и печь</b> съедают много воздуха: без отдельного притока к топке они «перетягивают» на себя вентканалы, и запахи из санузлов идут в дом.</li></ul>" },
    { t: "Частые ошибки", h: () => "<ol class=\"steps\"><li>Пластиковые окна без приточных клапанов — духота и конденсат.</li><li>Двери без зазора — санузел не проветривается.</li><li>Каналы выведены на чердак, а не на улицу — сырость и плесень на стропилах.</li><li>Неутеплённые каналы на холодном чердаке — обмерзание и обратная тяга.</li><li>Труба ниже конька или рядом с ним — ветер задувает внутрь.</li><li>Вентилятор в одном канале с соседями или зонт в единственном канале кухни.</li><li>Вытяжка из спальни и приток в кухню — запахи по всему дому.</li><li>Канал сделали 100×100 «чтобы поместился» — расхода не хватает.</li></ol>" },
    { t: "Как проверить, что работает", h: () => "<ul class=\"rules\"><li><b>Лист бумаги</b> у вытяжной решётки при приоткрытом окне должен притягиваться. Если отталкивается — тяга опрокинута.</li><li><b>Анемометр</b> у решётки: скорость × площадь решётки = расход. Сравните с нормой.</li><li><b>Датчик CO₂</b> в спальне ночью: до 800 ppm — отлично, до 1000 ppm — нормально, выше 1200 ppm — притока мало.</li><li><b>Влажность</b> 40–60%. Выше — конденсат на окнах и плесень, ниже (зимой) — сухость, нужен увлажнитель, а не закрытая вентиляция.</li><li>Запотевающие окна и тёмные пятна в углах — первый признак, что вентиляции не хватает.</li></ul><p>Если естественной тяги не хватает (одноэтажный дом, короткие каналы, жаркий климат) — ставят <b>приточно-вытяжную установку с рекуперацией</b>: она работает круглый год и возвращает до 80–90% тепла.</p>" }
  ];
  const QUIZ = [
    ["Из каких помещений делают вытяжку?", ["Из спален и гостиной", "Из кухни, санузлов, котельной", "Из коридора"], 1, "Вытяжка — из «грязных» помещений, приток — в жилые."],
    ["Почему летом естественная вентиляция почти не тянет?", ["Каналы забиваются пылью", "Разница температур внутри и снаружи маленькая", "Летом выше влажность"], 1, "Тяга пропорциональна высоте канала и разнице температур."],
    ["Дверь в санузел плотная, без зазора. Что с вытяжкой?", ["Работает как обычно", "Почти не работает — воздуху неоткуда прийти", "Работает лучше"], 1, "Нужен зазор 15–20 мм под дверью или переточная решётка."],
    ["Вентканал идёт через холодный чердак без утепления. Что будет?", ["Ничего", "Конденсат, обмерзание и опрокидывание тяги", "Тяга станет сильнее"], 1, "Канал на холодном чердаке и над кровлей утепляют."],
    ["Можно подключить кухонный зонт к единственному вентканалу кухни?", ["Да, так все делают", "Нет — нужен отдельный канал или канал-спутник", "Только с гофрой"], 1, "Иначе зонт перекрывает естественную вытяжку."],
    ["Вентканал выходит в 1 м от конька. Какой высоты трубу делать?", ["Не ниже конька", "Не менее 0,5 м выше конька", "Высота не важна"], 1, "До 1,5 м от конька — не менее 0,5 м выше него."]
  ];
  add({
    id: "ventguide", cat: "learn", custom: true, mark: "обучалка", name: "Естественная вентиляция в доме", kw: "обучение вентиляция естественная как сделать приток вытяжка ошибки тяга урок гайд обучалка",
    desc: "8 коротких уроков со схемами, интерактивная тяга, разбор ошибок и тест на понимание",
    render(panel, api) {
      let step = Math.min(store.get("vg:step") || 0, LESSONS.length);
      const answers = {};
      const draw = () => {
        store.set("vg:step", step);
        const nav = '<div class="lv-nav">' + LESSONS.map((l, i) => '<button type="button" data-step="' + i + '" class="' + (i === step ? "on" : i < step ? "done" : "") + '"><span>' + (i + 1) + "</span>" + esc(l.t) + "</button>").join("") + '<button type="button" data-step="' + LESSONS.length + '" class="' + (step === LESSONS.length ? "on" : "") + '"><span>✓</span>Тест</button></div>';
        let body;
        if (step < LESSONS.length) {
          const l = LESSONS[step];
          body = '<div class="lv-prog"><span style="width:' + Math.round(step / LESSONS.length * 100) + '%"></span></div><div class="eyebrow">Урок ' + (step + 1) + " из " + LESSONS.length + '</div><h3 class="lv-h">' + esc(l.t) + '</h3><div class="lv-body">' + l.h() + '</div><div class="lv-btns">' + (step > 0 ? '<button type="button" class="btn sm ghost" data-step="' + (step - 1) + '">← Назад</button>' : "") + '<button type="button" class="btn sm" data-step="' + (step + 1) + '">' + (step === LESSONS.length - 1 ? "К тесту →" : "Дальше →") + "</button></div>";
        } else {
          body = '<div class="eyebrow">Проверьте себя</div><h3 class="lv-h">Тест: 6 вопросов</h3>' + QUIZ.map((q, i) => '<div class="qz" data-q="' + i + '"><p><b>' + (i + 1) + ". " + esc(q[0]) + "</b></p>" + q[1].map((o, k) => '<button type="button" class="qz-o" data-q="' + i + '" data-a="' + k + '">' + esc(o) + "</button>").join("") + '<p class="qz-f"></p></div>').join("") + '<div class="qz-total" data-o="total"></div><div class="lv-btns"><button type="button" class="btn sm ghost" data-step="0">Пройти заново</button><button type="button" class="btn sm" data-open="vent">Рассчитать каналы для своего дома →</button></div>';
        }
        panel.innerHTML = '<section class="card lv">' + nav + '<div class="lv-main">' + body + "</div></section>";
        const play = panel.querySelector(".lv-play");
        if (play) {
          const upd = () => { const H = +play.querySelector('[data-i="h"]').value, t = +play.querySelector('[data-i="t"]').value; play.querySelector('[data-o="hv"]').textContent = nf(H, 1); play.querySelector('[data-o="tv"]').textContent = t; const dp = draftPa(H, 20, t), vel = ventVel(dp), q = 0.0196 * vel * 3600; play.querySelector('[data-o="res"]').innerHTML = "Тяга <b>" + nf(dp, 1) + " Па</b> · скорость в канале 140×140 <b>" + nf(vel, 2) + " м/с</b> · расход <b>" + nint(q) + " м³/ч</b>" + (q < 25 ? ' <span class="bad">— меньше нормы даже для туалета</span>' : q < 60 ? ' <span class="mid">— хватит на санузел, на кухню мало</span>' : ' <span class="good">— хватит и на кухню</span>'); };
          play.addEventListener("input", upd); upd();
        }
      };
      panel.addEventListener("click", e => {
        const op = e.target.closest("[data-open]");
        if (op) { api.open(op.dataset.open); return; }
        const s = e.target.closest("[data-step]");
        if (s) { step = +s.dataset.step; draw(); panel.scrollIntoView({ block: "start", behavior: "smooth" }); return; }
        const o = e.target.closest(".qz-o");
        if (o) {
          const qi = +o.dataset.q, a = +o.dataset.a; answers[qi] = a;
          const box = panel.querySelector('.qz[data-q="' + qi + '"]'), q = QUIZ[qi];
          box.querySelectorAll(".qz-o").forEach(b => { b.classList.remove("right", "wrong"); if (+b.dataset.a === q[2]) b.classList.add(a === q[2] ? "right" : ""); });
          o.classList.add(a === q[2] ? "right" : "wrong");
          box.querySelector(".qz-f").textContent = (a === q[2] ? "Верно. " : "Не совсем. ") + q[3];
          const done = Object.keys(answers).length, ok = Object.entries(answers).filter(([i, x]) => QUIZ[i][2] === x).length;
          panel.querySelector('[data-o="total"]').textContent = done === QUIZ.length ? "Результат: " + ok + " из " + QUIZ.length + (ok === QUIZ.length ? " — все ответы верны. Можно переходить к расчёту." : ok >= 4 ? " — хороший результат. Перечитайте урок о частых ошибках." : " — рекомендуем пройти уроки ещё раз.") : "";
        }
      });
      draw();
    }
  });
