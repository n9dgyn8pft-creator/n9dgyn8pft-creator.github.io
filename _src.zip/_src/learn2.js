  // ====================================================================
  //  ПЕРЕМЫЧКИ, ПУСТОТНЫЕ ПЛИТЫ, ОБУЧАЛКА ПО ПЛИТАМ
  // ====================================================================
  const PB_LEN = { 10: 1030, 13: 1290, 16: 1550, 17: 1680, 18: 1810, 19: 1940, 21: 2070, 22: 2200, 25: 2460, 26: 2590, 27: 2720, 29: 2850, 30: 2980, 31: 3110, 34: 3370, 36: 3630, 39: 3890 };
  const PB_FAM = { "2ПБ": [120, 140, "10-1 13-1 16-2 17-2 19-3 22-3 25-3 26-4 29-4 30-4"], "3ПБ": [120, 220, "13-37 16-37 18-8 18-37 21-8 25-8 25-37 27-8 30-8 34-4 36-4 39-8"], "8ПБ": [120, 190, "10-1 13-1 16-1 17-2 19-3"], "9ПБ": [120, 190, "13-37 16-37 18-8 18-37 22-3 25-8 26-4 27-8 29-4"], "5ПБ": [250, 220, "18-27 21-27 25-27 25-37 27-27 27-37 30-27 30-37 31-27 34-20 36-20"] };
  const PB = [];
  Object.entries(PB_FAM).forEach(([f, [b, h, list]]) => list.split(" ").forEach(s => { const [l, q] = s.split("-").map(Number); const L = PB_LEN[l]; PB.push({ name: f + l + "-" + q + "п", fam: f, b, h, L, q, kg: b / 1000 * h / 1000 * L / 1000 * 2500 }); }));
  const LW = { brickC: ["Кирпич керамический полнотелый", 18, "brick"], brickS: ["Кирпич силикатный", 19, "brick"], brickH: ["Кирпич пустотелый", 14, "brick"], keramz: ["Керамзитобетонный блок", 12, "block"], aer: ["Газобетон D500", 6.5, "aer"] };
  const pickPB = (b, Lreq, q, prefH) => PB.filter(p => p.b === b && p.L >= Lreq && p.q >= q && (!prefH || p.h === prefH || true)).sort((x, y) => x.kg - y.kg || x.L - y.L)[0];
  add({
    id: "lintel", cat: "struct", mark: "по нагрузке", name: "Подбор перемычек над проёмами", kw: "перемычка перемычки пб 2пб 3пб 5пб 9пб проём окно дверь нагрузка кладка кирпич газобетон серия 1.038.1-1 подбор брусковые",
    desc: "Нагрузка от кладки и плит, сколько брусков на толщину стены, марки по серии 1.038.1-1, схема",
    inputs: [
      { k: "B", label: "Ширина проёма в свету, мм", def: 1500 },
      { k: "mat", label: "Материал стены", type: "sel", def: "brickS", opts: Object.entries(LW).map(([k, w]) => [k, w[0]]) },
      { k: "t", label: "Толщина стены, мм", type: "sel", def: "380", opts: [["120", "120 (½ кирпича)"], ["250", "250 (1 кирпич)"], ["380", "380 (1½ кирпича)"], ["510", "510 (2 кирпича)"], ["640", "640 (2½ кирпича)"], ["300", "300 (блок)"], ["375", "375 (блок)"], ["400", "400 (блок)"]] },
      { k: "role", label: "Стена", type: "sel", def: "bear", opts: [["bear", "Несущая — на неё опираются плиты или балки"], ["self", "Самонесущая / перегородка"]] },
      { k: "ha", label: "Кладка над перемычкой до перекрытия, мм", def: 600, hint: "Если плиты ближе, чем ширина проёма, их вес идёт на перемычку" },
      { k: "span", label: "Пролёт перекрытия, опирающегося на стену, м", def: 6, show: v => v.role === "bear" },
      { k: "slab", label: "Перекрытие", type: "sel", def: "pk", opts: [["pk", "Пустотные плиты 220 мм"], ["mono", "Монолит 200 мм"], ["wood", "Деревянные балки"]], show: v => v.role === "bear" },
      { k: "two", label: "Плиты опираются с двух сторон (внутренняя стена)", type: "check", def: false, show: v => v.role === "bear" },
      { k: "clad", label: "Наружная верста — облицовочный кирпич", type: "check", def: false }
    ],
    run(v) {
      const B = v.B, t = +v.t, w = LW[v.mat], gam = w[1];
      const sup = v.role === "bear" ? (B > 1500 ? 250 : 200) : 120;
      const Lreq = B + 2 * sup;
      // нагрузки, кН/м по всей толщине
      const band = v.ha >= B / 3 ? B / 3 : v.ha;
      const qMas = gam * t / 1000 * band / 1000 * 1.1;
      let qSlab = 0;
      if (v.role === "bear" && v.ha < B) {
        const g = { pk: 3.0 + 1.5, mono: 5.0 + 1.5, wood: 0.5 + 0.5 }[v.slab];
        qSlab = (g * 1.1 + 1.5 * 1.3) * v.span / 2 * (v.two ? 2 : 1);
      }
      // варианты набора брусков по толщине
      const sets = { 120: [[120]], 250: [[120, 120], [250]], 380: [[120, 120, 120], [120, 250]], 510: [[120, 120, 120, 120], [250, 250], [120, 120, 250]], 640: [[120, 120, 120, 120, 120], [120, 250, 250]], 300: [[120, 120]], 375: [[120, 120, 120]], 400: [[120, 120, 120]] }[t];
      let best = null;
      sets.forEach(set => {
        const sum = set.reduce((s, x) => s + x, 0);
        const bars = set.map((b, i) => {
          const outer = i === 0, inner = i === set.length - 1;
          let q = qMas * b / t;
          const share = v.two && set.length > 1 ? 0.5 : 1;
          if (inner) q += qSlab * share;
          if (outer && v.two && set.length > 1) q += qSlab * 0.5;
          if (outer && v.clad && !v.two) q = 19 * 0.12 * band / 1000 * 1.1;
          const p = pickPB(b, Lreq, q);
          return { b, q, p, outer, inner };
        });
        if (bars.some(x => !x.p)) return;
        const kg = bars.reduce((s, x) => s + x.p.kg, 0);
        if (!best || kg < best.kg) best = { bars, kg, gap: t - sum };
      });
      const warn = [];
      if (!best) return { warn: "Под такую нагрузку и ширину проёма в серии нет подходящих брусковых перемычек. Нужна монолитная перемычка или металлическая (уголки, швеллеры) по расчёту." };
      if (w[2] === "aer") warn.push("В газобетонной стене ж/б перемычки — мостик холода: снаружи утеплите их 50 мм или используйте газобетонные армированные перемычки и U-блоки. Под опоры — распределительный слой раствора, в зоне опирания под плитами — армопояс.");
      if (best.gap > 20) warn.push("Остаток толщины " + nint(best.gap) + " мм между брусками заполните утеплителем или кладкой.");
      if (B > 2500 && v.role === "bear") warn.push("Проём шире 2,5 м в несущей стене — проверьте перемычку расчётом, рассмотрите монолитную.");
      // схема: фасад и разрез
      const W = 860, sc = Math.min(560 / (Lreq + 600), 0.16), ox = 40, oy = 40;
      const hBar = Math.max(...best.bars.map(x => x.p.h));
      const wallW = (Lreq + 600) * sc, opW = B * sc, opH = 1400 * sc;
      const yL = oy + Math.max(band, v.ha) * sc + 20;
      let s = '<svg viewBox="0 0 ' + W + ' ' + (yL + hBar * sc + opH + 50) + '" class="gl-svg" role="img" aria-label="Схема перемычки">';
      s += '<rect x="' + ox + '" y="' + oy + '" width="' + wallW + '" height="' + (yL - oy + hBar * sc + opH) + '" class="ln-wall"/>';
      if (v.role === "bear") s += '<rect x="' + (ox - 10) + '" y="' + (yL - v.ha * sc - 22 * sc * 10 / 10 - 8) + '" width="' + (wallW + 20) + '" height="8" class="ln-slab"/>';
      const xo = ox + 300 * sc;
      s += '<rect x="' + (xo + sup * sc) + '" y="' + (yL + hBar * sc) + '" width="' + opW + '" height="' + opH + '" class="ln-open"/>';
      s += '<rect x="' + xo + '" y="' + yL + '" width="' + Lreq * sc + '" height="' + hBar * sc + '" class="ln-bar"/>';
      s += '<path d="M' + (xo + sup * sc) + ' ' + yL + ' L' + (xo + sup * sc + opW / 2) + ' ' + (yL - band * sc) + ' L' + (xo + sup * sc + opW) + ' ' + yL + ' Z" class="ln-load"/>';
      s += '<text x="' + (xo + sup * sc + opW / 2) + '" y="' + (yL - band * sc / 3) + '" class="axis" text-anchor="middle">кладка ' + nint(band) + ' мм</text>';
      s += '<text x="' + (xo + Lreq * sc / 2) + '" y="' + (yL + hBar * sc + opH / 2) + '" class="axis" text-anchor="middle">проём ' + nint(B) + ' мм</text>';
      s += '<text x="' + (xo + Lreq * sc / 2) + '" y="' + (yL + hBar * sc + opH + 18) + '" class="axis" text-anchor="middle">перемычка ' + nint(best.bars[best.bars.length - 1].p.L) + ' мм, опирание ≥ ' + sup + ' мм</text>';
      // разрез
      const sx = ox + wallW + 80, ss = Math.min(0.45, (W - sx - 230) / (t + 40));
      let bx = sx;
      s += '<text x="' + sx + '" y="' + (oy + 10) + '" class="axis">разрез стены</text>';
      best.bars.forEach(x => { s += '<rect x="' + bx + '" y="' + (yL + (hBar - x.p.h) * ss) + '" width="' + x.b * ss + '" height="' + x.p.h * ss + '" class="ln-bar"/><text x="' + (bx + x.b * ss / 2) + '" y="' + (yL + hBar * ss + 14) + '" class="axis" text-anchor="middle">' + x.p.fam + '</text>'; bx += x.b * ss + (best.gap > 0 && x === best.bars[0] ? best.gap * ss : 3); });
      if (v.role === "bear") s += '<rect x="' + (bx - 130 * ss) + '" y="' + (yL - 230 * ss) + '" width="' + (200) + '" height="' + 220 * ss + '" class="ln-slab"/><text x="' + (bx + 40) + '" y="' + (yL - 230 * ss - 6) + '" class="axis">плита</text>';
      s += '<text x="' + sx + '" y="' + (yL + hBar * ss + 34) + '" class="axis">снаружи → внутрь</text></svg>';
      const rows = best.bars.map((x, i) => [(x.outer ? "Наружный" : x.inner ? "Внутренний" : "Средний") + " брусок " + x.b + " мм", x.p.name, nf(x.q, 1) + " кН/м", nf(x.p.q, 0) + " кН/м", nint(x.p.kg) + " кг"]);
      const cnt = {};
      best.bars.forEach(x => cnt[x.p.name] = (cnt[x.p.name] || 0) + 1);
      return {
        stats: [S("Перемычки на 1 проём", Object.entries(cnt).map(([n, c]) => c + " × " + n).join(" + "), "", "", true), S("Длина", nint(best.bars[0].p.L) + "–" + nint(Math.max(...best.bars.map(x => x.p.L))), "мм", "нужно ≥ " + nint(Lreq)), S("Нагрузка от кладки", nf(qMas, 1), "кН/м", "пояс " + nint(band) + " мм" + (v.ha >= B / 3 ? " (⅓ проёма)" : "")), S("Нагрузка от перекрытия", nf(qSlab, 1), "кН/м", qSlab ? "плиты ближе ширины проёма" : v.role === "bear" ? "плиты выше зоны — не учитывается" : "стена самонесущая"), S("Масса", nint(best.kg), "кг")],
        warn: warn.join(" "),
        blocks: [{ title: "Схема", html: '<div class="chart-scroll">' + s + "</div>" }],
        table: { head: ["Положение", "Марка", "Нагрузка", "Допускается", "Масса"], rows },
        items: Object.entries(cnt).map(([n, c]) => ["Перемычка " + n, c, "шт."])
      };
    },
    info: "Нагрузка от кладки — по поясу высотой ⅓ пролёта (сводовый эффект в схватившейся кладке), если кладки выше больше; иначе — вся кладка до перекрытия. Нагрузка от перекрытия учитывается, если оно ближе к перемычке, чем ширина проёма; вся она передаётся на внутренний брусок, на который опираются плиты. Коэффициенты надёжности 1,1 и 1,3. Несущая способность — по числу в марке серии 1.038.1-1 (кН/м). Опирание на кладку — не менее 120 мм, под плитами — 200–250 мм. Пока раствор не набрал прочность, ставьте временные стойки."
  });

  // ---------- Раскладка пустотных плит ----------
  const VOIDS = { 1000: 5, 1200: 6, 1500: 7, 1800: 9 };
  add({
    id: "slabs", cat: "struct", mark: "схема", name: "Раскладка пустотных плит", kw: "плиты перекрытия пустотные пк пб раскладка схема монолитный участок опирание кран ширина длина перекрытие 60.15",
    desc: "Подбор длины по опиранию, сочетание ширин с минимальным монолитом, схема, масса и кран",
    inputs: [
      { k: "span", label: "Пролёт в свету между несущими стенами, мм", def: 5600 },
      { k: "len", label: "Длина перекрываемого участка вдоль стен, мм", def: 8400, hint: "В свету между боковыми стенами" },
      { k: "n", label: "Одинаковых участков", def: 1 },
      { k: "wall", label: "Опирание на", type: "sel", def: "brick", opts: [["brick", "Кирпич (≥ 120 мм)"], ["aer", "Газобетон через армопояс (≥ 150 мм)"], ["rc", "Ж/б ригель или монолит (≥ 100 мм)"]] },
      { k: "wt", label: "Толщина несущей стены, мм", def: 380 },
      { k: "type", label: "Тип плит", type: "sel", def: "pk", opts: [["pk", "ПК — длины кратны 300 мм"], ["pb", "ПБ — любая длина с шагом 100 мм"]] },
      { k: "w1500", label: "Ширина 1500", type: "check", def: true }, { k: "w1200", label: "Ширина 1200", type: "check", def: true }, { k: "w1000", label: "Ширина 1000", type: "check", def: true },
      { k: "load", label: "Расчётная нагрузка", type: "sel", def: "8", opts: [["8", "8 кПа (800 кг/м²) — жилые дома"], ["12.5", "12,5 кПа — тяжёлые нагрузки"]] }
    ],
    run(v) {
      const minS = { brick: 120, aer: 150, rc: 100 }[v.wall], maxS = Math.min(v.wt - 50, 250);
      const Lmin = v.span + 2 * minS, Lmax = v.span + 2 * maxS;
      let Lp = v.type === "pk" ? Math.ceil(Lmin / 300) * 300 - 20 : Math.ceil(Lmin / 100) * 100 - 20;
      if (Lp < Lmin) Lp += v.type === "pk" ? 300 : 100;
      const warn = [];
      if (maxS < minS) warn.push("Стена слишком тонкая для опирания плит.");
      if (Lp > Lmax) warn.push("Ближайшая длина ПК (" + nint(Lp) + " мм) даёт опирание больше допустимого — возьмите ПБ под размер или увеличьте толщину стены.");
      if (v.wall === "aer") warn.push("На газобетон плиты кладут только через монолитный армопояс — иначе блоки под опорой раскрошатся.");
      if (Lp > 9000 && v.type === "pk") warn.push("ПК длиннее 9 м почти не выпускают — нужны ПБ или промежуточная несущая стена.");
      const ws = [1500, 1200, 1000].filter(x => v["w" + x]);
      if (!ws.length) return { warn: "Выберите хотя бы одну ширину плит." };
      // подбор сочетания ширин
      let best = null;
      const L = v.len, rec = (i, cur, sum) => {
        if (i === ws.length) { const r = L - sum; if (r < 0) return; const cnt = cur.reduce((s, x) => s + x, 0); const score = (r > 300 ? 1e4 + r * 10 : r * 10) + cnt; if (!best || score < best.score) best = { score, cur: cur.slice(), r }; return; }
        for (let k = 0; k <= Math.floor(L / ws[i]); k++) { cur.push(k); rec(i + 1, cur, sum + k * ws[i]); cur.pop(); }
      };
      rec(0, [], 0);
      const plates = [];
      ws.forEach((w, i) => { for (let k = 0; k < best.cur[i]; k++) plates.push(w); });
      const r = best.r;
      if (r > 300) warn.push("Монолитный участок " + nint(r) + " мм — шире 300 мм, его нужно считать как монолитную плиту или добавить ширины плит.");
      const nm = w => (v.type === "pk" ? "ПК " : "ПБ ") + Math.round((Lp + 20) / 100) + "." + w / 100 + (v.type === "pb" ? ".22" : "") + "-" + v.load;
      const t = (Lp / 1000) * 0.25; // т на 1 м ширины
      const mass = w => t * w / 1000;
      const heavy = Math.max(...plates.map(mass));
      // схема
      const Wsvg = 860, wallT = Math.min(v.wt, 400), totX = v.span + 2 * wallT, totY = L + 240;
      const sc = Math.min((Wsvg - 120) / totX, 420 / totY), ox = 60, oy = 20;
      let s = '<svg viewBox="0 0 ' + Wsvg + " " + (totY * sc + 60) + '" class="gl-svg" role="img" aria-label="Схема раскладки плит"><defs><pattern id="hatch" width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><line x1="0" y1="0" x2="0" y2="6" class="sl-h"/></pattern></defs>';
      s += '<rect x="' + ox + '" y="' + oy + '" width="' + wallT * sc + '" height="' + totY * sc + '" fill="url(#hatch)" class="sl-wall"/><rect x="' + (ox + (wallT + v.span) * sc) + '" y="' + oy + '" width="' + wallT * sc + '" height="' + totY * sc + '" fill="url(#hatch)" class="sl-wall"/>';
      s += '<rect x="' + ox + '" y="' + oy + '" width="' + totX * sc + '" height="' + 120 * sc + '" class="sl-side"/><rect x="' + ox + '" y="' + (oy + (120 + L) * sc) + '" width="' + totX * sc + '" height="' + 120 * sc + '" class="sl-side"/>';
      let y = oy + 120 * sc;
      const px = ox + (wallT - (Lp - v.span) / 2) * sc;
      const monoAt = Math.floor(plates.length / 2);
      const drawMono = () => { if (r > 0) { s += '<rect x="' + (ox + wallT * sc) + '" y="' + y + '" width="' + v.span * sc + '" height="' + r * sc + '" class="sl-mono"/>' + (r * sc > 10 ? '<text x="' + (ox + (wallT + v.span / 2) * sc) + '" y="' + (y + r * sc / 2 + 4) + '" class="axis" text-anchor="middle">монолит ' + nint(r) + "</text>" : ""); y += r * sc; } };
      plates.forEach((w, i) => {
        if (i === monoAt) drawMono();
        s += '<rect x="' + px + '" y="' + (y + 0.5) + '" width="' + Lp * sc + '" height="' + (w * sc - 1) + '" class="sl-plate"/>';
        const nv = VOIDS[w] || 6;
        for (let k = 0; k < nv; k++) s += '<line x1="' + (px + 4) + '" x2="' + (px + Lp * sc - 4) + '" y1="' + (y + (k + 0.5) * w * sc / nv) + '" y2="' + (y + (k + 0.5) * w * sc / nv) + '" class="sl-void"/>';
        s += '<text x="' + (px + Lp * sc / 2) + '" y="' + (y + w * sc / 2 + 4) + '" class="sl-l" text-anchor="middle">' + nm(w) + "</text>";
        y += w * sc;
      });
      if (monoAt >= plates.length) drawMono();
      s += '<text x="' + (ox + (wallT + v.span / 2) * sc) + '" y="' + (oy + totY * sc + 18) + '" class="axis" text-anchor="middle">пролёт ' + nint(v.span) + " мм · плита " + nint(Lp) + " мм · опирание " + nint((Lp - v.span) / 2) + " мм</text>";
      s += '<text x="' + (ox + totX * sc + 8) + '" y="' + (oy + totY * sc / 2) + '" class="axis">' + nint(L) + "</text></svg>";
      const cnt = {};
      plates.forEach(w => cnt[nm(w)] = (cnt[nm(w)] || 0) + v.n);
      const N = plates.length * v.n;
      const monoV = r / 1000 * v.span / 1000 * 0.22 * v.n;
      const anchors = (plates.length + 1) * 2 * v.n;
      const plugs = plates.reduce((s2, w) => s2 + (VOIDS[w] || 6) * 2, 0) * v.n;
      const mortar = 2 * (L / 1000) * (minS + 30) / 1000 * 0.02 * v.n + plates.length * v.n * (Lp / 1000) * 0.03 * 0.22 * 0.5;
      const items = Object.entries(cnt).map(([n, c]) => ["Плита " + n, c, "шт."]);
      if (monoV > 0) items.push(["Бетон B20 на монолитный участок", Math.round(monoV * 1.05 * 100) / 100, "м³"]);
      items.push(["Анкер Г-образный Ø10 А500", anchors, "шт."], ["Вкладыши-пробки в пустоты на опорах", plugs, "шт."], ["Раствор М100–М150 (постель и швы)", Math.round(mortar * 100) / 100, "м³"]);
      return {
        stats: [S("Плит", nint(N), "шт.", Object.entries(cnt).map(([n, c]) => c + " × " + n).join(", "), true), S("Длина плиты", nint(Lp), "мм", "опирание " + nint((Lp - v.span) / 2) + " мм (мин. " + minS + ")"), S("Монолитный участок", nint(r), "мм", r === 0 ? "без монолита" : nf(monoV, 2) + " м³ бетона"), S("Самая тяжёлая плита", nf(heavy, 2), "т", "кран ≥ " + nf(Math.max(16, ceil(heavy * 1.3 * 4)), 0) + " т с учётом вылета"), S("Площадь перекрытия", nf(v.span * L / 1e6 * v.n, 1), "м²")],
        warn: warn.join(" "),
        blocks: [{ title: "Схема раскладки" + (v.n > 1 ? " (одного участка из " + v.n + ")" : ""), html: '<div class="chart-scroll">' + s + "</div>" + '<p class="hint">Не понимаете, почему так? ' + goBtn("slabguide", "Обучалка по раскладке плит") + "</p>" }],
        table: { head: ["Позиция", "Количество"], rows: items.map(i => [i[0], (typeof i[1] === "number" ? i[1].toLocaleString("ru-RU") : i[1]) + " " + i[2]]) },
        items
      };
    },
    info: "Длина плиты = пролёт в свету + опирание с двух сторон: на кирпич не меньше 120 мм, на газобетон через армопояс не меньше 150 мм, на ж/б не меньше 100 мм; больше 200–250 мм заводить не нужно. ПК выпускают с шагом 300 мм (фактическая длина на 20 мм меньше номинала), ПБ режут под размер. Ширины подбираются так, чтобы монолитный участок был минимальным и не шире 300 мм. Масса — около 250 кг на 1 м² плиты толщиной 220 мм."
  });

  // ---------- Обучалка по плитам ----------
  function slabPlanSVG(bad) {
    return '<svg viewBox="0 0 640 230" class="lv-svg" role="img" aria-label="Опирание плит"><defs><pattern id="h2" width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><line x1="0" y1="0" x2="0" y2="6" class="sl-h"/></pattern></defs>' +
      '<rect x="40" y="30" width="24" height="160" fill="url(#h2)" class="sl-wall"/><rect x="266" y="30" width="24" height="160" fill="url(#h2)" class="sl-wall"/>' +
      '<rect x="52" y="40" width="226" height="64" class="sl-plate"/><rect x="52" y="108" width="226" height="64" class="sl-plate"/><text x="165" y="76" class="sl-l" text-anchor="middle">опора с двух коротких сторон</text><text x="165" y="214" class="lv-s" text-anchor="middle">правильно</text>' +
      '<rect x="350" y="30" width="24" height="160" fill="url(#h2)" class="sl-wall"/><rect x="576" y="30" width="24" height="160" fill="url(#h2)" class="sl-wall"/><rect x="350" y="166" width="250" height="24" fill="url(#h2)" class="sl-wall"/>' +
      '<rect x="362" y="40" width="226" height="64" class="sl-plate"/><rect x="362" y="108" width="226" height="68" class="sl-plate bad"/><text x="475" y="146" class="sl-l" text-anchor="middle">кромка заведена на стену</text><text x="475" y="214" class="lv-s" text-anchor="middle">нельзя: опора по трём сторонам</text></svg>';
  }
  function markSVG() {
    return '<svg viewBox="0 0 640 120" class="lv-svg" role="img" aria-label="Маркировка"><text x="20" y="50" class="mk-big">ПК</text><text x="90" y="50" class="mk-big">60</text><text x="150" y="50" class="mk-big">.</text><text x="165" y="50" class="mk-big">15</text><text x="225" y="50" class="mk-big">-</text><text x="245" y="50" class="mk-big">8</text><text x="275" y="50" class="mk-big">АтV</text>' +
      '<text x="20" y="80" class="lv-s">тип</text><text x="90" y="80" class="lv-s">длина 60 дм</text><text x="90" y="94" class="lv-s">(5980 мм)</text><text x="165" y="80" class="lv-s">ширина 15 дм</text><text x="165" y="94" class="lv-s">(1490 мм)</text><text x="245" y="80" class="lv-s">нагрузка</text><text x="245" y="94" class="lv-s">8 кПа</text><text x="275" y="108" class="lv-s">класс арматуры</text></svg>';
  }
  function supportSVG() {
    return '<svg viewBox="0 0 640 200" class="lv-svg" role="img" aria-label="Узел опирания"><rect x="250" y="100" width="140" height="90" fill="url(#h3)" class="sl-wall"/><defs><pattern id="h3" width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><line x1="0" y1="0" x2="0" y2="6" class="sl-h"/></pattern></defs>' +
      '<rect x="250" y="88" width="140" height="12" class="sl-mono"/><rect x="40" y="60" width="330" height="28" class="sl-plate"/><circle cx="330" cy="74" r="8" class="sl-plug"/><circle cx="300" cy="74" r="8" class="sl-void2"/><rect x="250" y="56" width="0" height="0"/>' +
      '<line x1="250" y1="40" x2="370" y2="40" class="lv-dim"/><text x="310" y="34" class="lv-s" text-anchor="middle">опирание ≥ 120 мм</text>' +
      '<text x="400" y="96" class="lv-s">армопояс / постель из раствора 10–20 мм</text><text x="400" y="70" class="lv-s">пустоты на опоре заделаны вкладышами</text><text x="60" y="110" class="lv-s">плита</text><text x="400" y="150" class="lv-s">несущая стена</text></svg>';
  }
  const SLESSONS = [
    { t: "Какие бывают пустотные плиты", h: () => '<table class="data lv-t2"><thead><tr><th>Тип</th><th>Как делают</th><th>Что важно</th></tr></thead><tbody><tr><td><b>ПК</b> — круглопустотные</td><td>В опалубке, по стандартной номенклатуре</td><td>Длины с шагом 300 мм (2,4–9 м), ширина 1,0 / 1,2 / 1,5 / 1,8 м. <b>Резать поперёк нельзя</b> — перерезается напряжённая арматура.</td></tr><tr><td><b>ПБ</b> — безопалубочного формования</td><td>Непрерывная лента на стенде, режется пилой</td><td>Любая длина с шагом 100 мм до 9–12 м, ровный потолок. Ширина обычно 1,2 м.</td></tr><tr><td><b>ПНО</b> — облегчённые 160 мм</td><td>Как ПК, но тоньше</td><td>Для лёгких домов и мансард, меньше вес и высота.</td></tr></tbody></table><p>Все пустотные плиты работают как <b>балка на двух опорах</b>: внизу — напряжённая арматура, сверху её почти нет. Отсюда все правила раскладки.</p>' },
    { t: "Как читать маркировку", h: () => markSVG() + "<p>Номинальная длина и ширина — в дециметрах; фактический размер на 10–20 мм меньше, чтобы между плитами остался шов. Последнее число — <b>расчётная нагрузка без собственного веса</b> в кПа: 8 кПа ≈ 800 кг/м². Для жилого дома (пол, стяжка, перегородки, мебель, люди) хватает 8 кПа с запасом. 12,5 кПа берут под тяжёлое оборудование, гаражи, зимние сады с грунтом.</p><p>У ПБ в маркировке ещё и толщина: <b>ПБ 60.12.22-8</b> — 6 м × 1,2 м × 220 мм.</p>" },
    { t: "Опирание", h: () => supportSVG() + '<ul class="rules"><li><b>Только по двум коротким сторонам.</b> Продольную кромку на стену не заводят: плита начинает работать на три опоры, появляются трещины вдоль.</li><li><b>Глубина опирания:</b> на кирпич — не меньше 120 мм, на газобетон — только через монолитный армопояс и не меньше 150 мм, на ж/б ригель или монолит — не меньше 100 мм. Больше 200–250 мм заводить не нужно: плита «защемляется» и трескается сверху над опорой.</li><li><b>Промежуточную опору</b> под середину пустотной плиты не делают: сверху арматуры нет, над стенкой появится трещина. Если стена посередине — раскладывают две короткие плиты.</li><li>Плиту кладут на <b>постель из раствора</b> 10–20 мм, а не «насухо»: иначе она опирается точками.</li></ul>' + slabPlanSVG() },
    { t: "Раскладка: как не ошибиться", h: () => '<ol class="steps"><li><b>Определите пролёт</b> — по короткой стороне помещения между несущими стенами. Плиты всегда перекрывают короткий пролёт.</li><li><b>Длина плиты</b> = пролёт в свету + 2 × опирание. Для ПК округляйте вверх до шага 300 мм и проверьте, что опирание не стало больше 250 мм.</li><li><b>Набор ширин</b> вдоль длины: сочетайте 1,5 / 1,2 / 1,0 м так, чтобы остаток был минимальным.</li><li><b>Остаток до 300 мм</b> — монолитный участок по месту: опалубка снизу, арматурный каркас, бетон B20. Шире — считать как монолитную плиту.</li><li><b>Место монолита</b> выбирайте там, где идут вентканалы, стояки, дымоход: через пустотную плиту их не проводят.</li><li><b>Лестничный проём</b> — монолит или металлические балки, укороченные плиты на них по расчёту.</li></ol><p>Всё это делает калькулятор: ' + goBtn("slabs", "Раскладка пустотных плит") + "</p>" },
    { t: "Монтаж и анкеровка", h: () => '<ul class="rules"><li><b>Кран:</b> плита ПК 60.15 весит около 2,2–2,5 т. Грузоподъёмность выбирают по самой тяжёлой плите и вылету стрелы — обычно 16–25 т для частного дома.</li><li><b>Пустоты на опорах</b> заделывают бетонными вкладышами или бетоном на глубину 120 мм — особенно под стенами следующего этажа, иначе стенки пустот раздавит.</li><li><b>Швы между плитами</b> заполняют раствором М150 или мелкозернистым бетоном — плиты начинают работать вместе, потолок не трескается по швам.</li><li><b>Анкеры:</b> Г-образные стержни Ø 10–12 мм за монтажные петли — соседние плиты между собой и с кладкой. Поверх кирпичной стены или на газобетоне — кольцевой армопояс.</li><li>Разница отметок соседних плит — не больше 5–8 мм, иначе ступенька на потолке.</li></ul>' },
    { t: "Отверстия и коммуникации", h: () => '<ul class="rules"><li>Сверлить можно <b>только по пустоте</b>, не задевая продольные рёбра — в них арматура.</li><li>Отверстие — не шире одной пустоты (≈ 120–160 мм). Под канализационный стояк Ø 110 — коронкой точно по оси пустоты.</li><li>Штробить плиту поперёк для труб нельзя.</li><li>Большие отверстия — только в монолитном участке, поэтому монолит ставят под стояки и вентканалы.</li></ul>' },
    { t: "Частые ошибки", h: () => '<ol class="steps"><li>Плиты на газобетон без армопояса.</li><li>Продольная кромка заведена на стену — опора по трём сторонам.</li><li>Перегородка под серединой плиты как «доп. опора».</li><li>Укороченная ПК — разрезанная поперёк.</li><li>Пустоты на опорах не заделаны, сверху — тяжёлая стена.</li><li>Монолитный участок без опалубки и арматуры, «залили между плитами».</li><li>Плиты положены без раствора — точечное опирание.</li><li>Опирание 50–70 мм «потому что плиты не хватило».</li></ol>' }
  ];
  const SQUIZ = [
    ["На сколько сторон опирается пустотная плита?", ["На три — так надёжнее", "На две короткие", "На все четыре"], 1, "Плита рассчитана как балка на двух опорах."],
    ["Что означает «8» в ПК 60.15-8?", ["Толщину 8 см", "Расчётную нагрузку 8 кПа (≈ 800 кг/м²)", "Количество пустот"], 1, "Без учёта собственного веса плиты."],
    ["Минимальное опирание ПК на кирпич?", ["70 мм", "120 мм", "300 мм"], 1, "На газобетон — через армопояс и от 150 мм."],
    ["Можно отрезать ПК, чтобы попасть в размер?", ["Да, болгаркой", "Нет — перерезается напряжённая арматура; нужна ПБ под размер", "Только вдоль"], 1, "Под точный размер заказывают ПБ."],
    ["Остался зазор 250 мм между плитами. Что делать?", ["Оставить пустым", "Монолитный участок: опалубка, каркас, бетон", "Завести плиту на боковую стену"], 1, "До 300 мм — монолит по месту."],
    ["Где можно сверлить отверстие под стояк?", ["В любом месте", "По оси пустоты, не задевая рёбер", "Только у опоры"], 1, "Рёбра с арматурой повреждать нельзя."]
  ];
  add({
    id: "slabguide", cat: "learn", custom: true, mark: "обучалка", name: "Раскладка пустотных плит", kw: "обучение плиты перекрытия пустотные пк пб раскладка опирание маркировка монтаж анкеровка ошибки урок",
    desc: "7 уроков: виды плит, маркировка, опирание, раскладка, монтаж, отверстия, ошибки — и тест",
    render(panel, api) {
      let step = Math.min(store.get("sg:step") || 0, SLESSONS.length);
      const answers = {};
      const draw = () => {
        store.set("sg:step", step);
        const navH = '<div class="lv-nav">' + SLESSONS.map((l, i) => '<button type="button" data-step="' + i + '" class="' + (i === step ? "on" : i < step ? "done" : "") + '"><span>' + (i + 1) + "</span>" + esc(l.t) + "</button>").join("") + '<button type="button" data-step="' + SLESSONS.length + '" class="' + (step === SLESSONS.length ? "on" : "") + '"><span>✓</span>Тест</button></div>';
        let body;
        if (step < SLESSONS.length) {
          const l = SLESSONS[step];
          body = '<div class="lv-prog"><span style="width:' + Math.round(step / SLESSONS.length * 100) + '%"></span></div><div class="eyebrow">Урок ' + (step + 1) + " из " + SLESSONS.length + '</div><h3 class="lv-h">' + esc(l.t) + '</h3><div class="lv-body">' + l.h() + '</div><div class="lv-btns">' + (step > 0 ? '<button type="button" class="btn sm ghost" data-step="' + (step - 1) + '">← Назад</button>' : "") + '<button type="button" class="btn sm" data-step="' + (step + 1) + '">' + (step === SLESSONS.length - 1 ? "К тесту →" : "Дальше →") + "</button></div>";
        } else {
          body = '<div class="eyebrow">Проверьте себя</div><h3 class="lv-h">Тест: ' + SQUIZ.length + " вопросов</h3>" + SQUIZ.map((q, i) => '<div class="qz" data-q="' + i + '"><p><b>' + (i + 1) + ". " + esc(q[0]) + "</b></p>" + q[1].map((o, k) => '<button type="button" class="qz-o" data-q="' + i + '" data-a="' + k + '">' + esc(o) + "</button>").join("") + '<p class="qz-f"></p></div>').join("") + '<div class="qz-total" data-o="total"></div><div class="lv-btns"><button type="button" class="btn sm ghost" data-step="0">Пройти заново</button><button type="button" class="btn sm" data-open="slabs">Разложить плиты для своего дома →</button></div>';
        }
        panel.innerHTML = '<section class="card lv">' + navH + '<div class="lv-main">' + body + "</div></section>";
      };
      panel.addEventListener("click", e => {
        const op = e.target.closest("[data-open]");
        if (op) { api.open(op.dataset.open); return; }
        const s = e.target.closest("[data-step]");
        if (s) { step = +s.dataset.step; draw(); panel.scrollIntoView({ block: "start", behavior: "smooth" }); return; }
        const o = e.target.closest(".qz-o");
        if (o) {
          const qi = +o.dataset.q, a = +o.dataset.a; answers[qi] = a;
          const box = panel.querySelector('.qz[data-q="' + qi + '"]'), q = SQUIZ[qi];
          box.querySelectorAll(".qz-o").forEach(b => b.classList.remove("right", "wrong"));
          o.classList.add(a === q[2] ? "right" : "wrong");
          if (a !== q[2]) box.querySelector('.qz-o[data-a="' + q[2] + '"]').classList.add("right");
          box.querySelector(".qz-f").textContent = (a === q[2] ? "Верно. " : "Не совсем. ") + q[3];
          const done = Object.keys(answers).length, ok = Object.entries(answers).filter(([i, x]) => SQUIZ[i][2] === x).length;
          panel.querySelector('[data-o="total"]').textContent = done === SQUIZ.length ? "Результат: " + ok + " из " + SQUIZ.length + (ok === SQUIZ.length ? " — все ответы верны." : ok >= 4 ? " — хороший результат. Перечитайте урок об опирании." : " — рекомендуем пройти уроки ещё раз.") : "";
        }
      });
      draw();
    }
  });
