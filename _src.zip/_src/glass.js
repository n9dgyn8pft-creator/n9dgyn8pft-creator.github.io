  // ====================================================================
  //  ОСТЕКЛЕНИЕ
  // ====================================================================
  // СП 20.13330: нормативное давление ветра по районам, k(z) и ζ(z) для типов местности A/B/C
  const W0 = [["Ia", 0.17], ["I", 0.23], ["II", 0.30], ["III", 0.38], ["IV", 0.48], ["V", 0.60], ["VI", 0.73], ["VII", 0.85]];
  const KZ = { A: [[5, 0.75], [10, 1.0], [20, 1.25], [40, 1.5], [60, 1.7], [100, 2.0]], B: [[5, 0.5], [10, 0.65], [20, 0.85], [40, 1.1], [60, 1.3], [100, 1.6]], C: [[5, 0.4], [10, 0.4], [20, 0.55], [40, 0.8], [60, 1.0], [100, 1.25]] };
  const ZT = { A: [[5, 0.85], [10, 0.76], [20, 0.69], [40, 0.62], [60, 0.58], [100, 0.54]], B: [[5, 1.22], [10, 1.06], [20, 0.92], [40, 0.80], [60, 0.74], [100, 0.67]], C: [[5, 1.78], [10, 1.78], [20, 1.50], [40, 1.26], [60, 1.14], [100, 1.02]] };
  const interp = (tab, z) => { if (z <= tab[0][0]) return tab[0][1]; for (let i = 1; i < tab.length; i++) if (z <= tab[i][0]) { const [a, x] = tab[i - 1], [b, y] = tab[i]; return x + (y - x) * (z - a) / (b - a); } return tab[tab.length - 1][1]; };
  const windKPa = (reg, z, terr) => { const w0 = W0.find(r => r[0] === reg)[1]; return 1.4 * w0 * interp(KZ[terr], z) * (1 + interp(ZT[terr], z)) * 1.2; };
  const glassSigma = (wkpa, H, t) => 0.75 * wkpa * 1e-3 * H * H / (t * t); // МПа, полоса с опорами сверху и снизу


  // ---------- Безрамное стационарное остекление ----------
  const GL = {
    t10: ["Закалённое 10 мм", "mono", 10, 10, 5.7], t12: ["Закалённое 12 мм", "mono", 12, 12, 5.7], t15: ["Закалённое 15 мм", "mono", 15, 15, 5.6], t19: ["Закалённое 19 мм", "mono", 19, 19, 5.5],
    l55: ["Триплекс закалённый 5+5", "lam", 5, 10.8, 5.6], l66: ["Триплекс закалённый 6+6", "lam", 6, 12.8, 5.6], l88: ["Триплекс закалённый 8+8", "lam", 8, 16.8, 5.5], l1010: ["Триплекс закалённый 10+10", "lam", 10, 20.8, 5.4],
    i6: ["Стеклопакет 6–16–6 (i-стекло, аргон)", "igu", 6, 28, 1.1], i8: ["Стеклопакет 8–16–8 (i-стекло, аргон)", "igu", 8, 32, 1.1], i10: ["Стеклопакет 10–14–10 (i-стекло, аргон)", "igu", 10, 34, 1.2], i66: ["Стеклопакет 6.6.2–16–8 (триплекс внутри)", "igu", 7, 31, 1.1]
  };
  const FAM = { mono: ["t10", "t12", "t15", "t19"], lam: ["l55", "l66", "l88", "l1010"], igu: ["i6", "i8", "i66", "i10"] };
  const tEff = (g, kind) => { const t = g[2]; if (g[1] === "mono") return t; return kind === "s" ? t * Math.SQRT2 : t * Math.cbrt(2); }; // 2 слоя без учёта сдвиговой связи — в запас
  const PLATE = [[1, 0.2874, 0.0444], [1.5, 0.4872, 0.0843], [2, 0.6102, 0.1106], [3, 0.7134, 0.1335], [5, 0.7476, 0.1404], [100, 0.75, 0.1422]];
  function glassCheck(g, w, H, Wp, fins) {
    const q = w * 1e-3, E = 70000, ts = tEff(g, "s"), td = tEff(g, "d");
    let sig, f, span;
    if (!fins) { span = H; sig = 0.75 * q * H * H / (ts * ts); f = 0.15625 * q * Math.pow(H, 4) / (E * td * td * td); }
    else { const a = Math.max(H, Wp), b = Math.min(H, Wp), r = a / b; const beta = interp(PLATE.map(p => [p[0], p[1]]), r), alpha = interp(PLATE.map(p => [p[0], p[2]]), r); span = b; sig = beta * q * b * b / (ts * ts); f = alpha * q * Math.pow(b, 4) / (E * td * td * td); }
    const fLim = Math.min(span / 65, 50);
    return { sig, f, fLim, ok: sig <= 50 && f <= fLim };
  }
  function nodeSVG(kind, g) {
    const tg = g[3], igu = g[1] === "igu", s = 2.2;
    const W = 310, H = 200, cx = 110;
    let p = '<svg viewBox="0 0 ' + W + " " + H + '" class="node-svg" role="img" aria-label="Узел">';
    const glass = (x, y, w, h) => igu ? '<rect x="' + x + '" y="' + y + '" width="' + (g[2] * s) + '" height="' + h + '" class="nd-gl"/><rect x="' + (x + w - g[2] * s) + '" y="' + y + '" width="' + (g[2] * s) + '" height="' + h + '" class="nd-gl"/><rect x="' + (x + g[2] * s) + '" y="' + (kind === "bottom" ? y + h - 30 : y) + '" width="' + (w - 2 * g[2] * s) + '" height="30" class="nd-spacer"/>' : '<rect x="' + x + '" y="' + y + '" width="' + w + '" height="' + h + '" class="nd-gl"/>' + (g[1] === "lam" ? '<line x1="' + (x + w / 2) + '" x2="' + (x + w / 2) + '" y1="' + y + '" y2="' + (y + h) + '" class="nd-pvb"/>' : "");
    const glassH = (x, y, len, th) => igu ? '<rect x="' + x + '" y="' + y + '" width="' + len + '" height="' + (g[2] * s) + '" class="nd-gl"/><rect x="' + x + '" y="' + (y + th - g[2] * s) + '" width="' + len + '" height="' + (g[2] * s) + '" class="nd-gl"/>' : '<rect x="' + x + '" y="' + y + '" width="' + len + '" height="' + th + '" class="nd-gl"/>' + (g[1] === "lam" ? '<line x1="' + x + '" x2="' + (x + len) + '" y1="' + (y + th / 2) + '" y2="' + (y + th / 2) + '" class="nd-pvb"/>' : "");
    const lab = (x, y, t, anchor) => '<text x="' + x + '" y="' + y + '" class="nd-l" text-anchor="' + (anchor || "start") + '">' + t + "</text>";
    const gw = tg * s;
    if (kind === "bottom") {
      const chW = gw + 40, chH = 90, y0 = 150;
      p += '<rect x="10" y="' + y0 + '" width="' + (W - 20) + '" height="40" class="nd-slab"/>' + lab(14, y0 + 30, "перекрытие / пол");
      p += '<path d="M' + (cx - chW / 2) + " " + (y0 - chH) + " v" + chH + " h" + chW + " v-" + chH + " h-8 v" + (chH - 8) + " h-" + (chW - 16) + " v-" + (chH - 8) + ' z" class="nd-al"/>';
      p += '<rect x="' + (cx - gw / 2 - 2) + '" y="' + (y0 - 8 - 6) + '" width="' + (gw + 4) + '" height="6" class="nd-block"/>';
      p += glass(cx - gw / 2, 8, gw, y0 - 8 - 6 - 8);
      p += '<path d="M' + (cx - chW / 2 + 8) + " " + (y0 - chH + 4) + " l" + (chW / 2 - gw / 2 - 8) + " 0 l0 30 z" + '" class="nd-wedge"/><path d="M' + (cx + chW / 2 - 8) + " " + (y0 - chH + 4) + " l-" + (chW / 2 - gw / 2 - 8) + " 0 l0 30 z" + '" class="nd-wedge"/>';
      p += '<line x1="' + (cx - chW / 2 + 4 + 12) + '" x2="' + (cx - chW / 2 + 4 + 12) + '" y1="' + (y0 - 6) + '" y2="' + (y0 + 34) + '" class="nd-anchor"/>';
      p += lab(cx + chW / 2 + 6, y0 - chH + 18, "клин EPDM / зажим") + lab(cx + chW / 2 + 6, y0 - 10, "подкладка 2 шт.") + lab(cx - chW / 2 - 6, y0 - chH / 2, "U-профиль", "end") + lab(cx - chW / 2 - 6, y0 - chH / 2 + 13, "≈ 100 мм", "end") + lab(cx - chW / 2 - 6, y0 + 4, "анкер", "end") + lab(cx + gw / 2 + 6, 30, igu ? "стеклопакет" : g[1] === "lam" ? "триплекс" : "стекло");
    } else if (kind === "top") {
      const chW = gw + 28, chH = 60, y0 = 40;
      p += '<rect x="10" y="10" width="' + (W - 20) + '" height="30" class="nd-slab"/>' + lab(14, 30, "балка / перекрытие");
      p += '<path d="M' + (cx - chW / 2) + " " + (y0 + chH) + " v-" + chH + " h" + chW + " v" + chH + " h-8 v-" + (chH - 8) + " h-" + (chW - 16) + " v" + (chH - 8) + ' z" class="nd-al"/>';
      p += glass(cx - gw / 2, y0 + 22, gw, H - y0 - 30);
      p += '<line x1="' + (cx - 30) + '" x2="' + (cx + 30) + '" y1="' + (y0 + 14) + '" y2="' + (y0 + 14) + '" class="nd-dim"/>' + lab(cx + chW / 2 + 6, y0 + 18, "зазор на прогиб") + lab(cx + chW / 2 + 6, y0 + 32, "балки ≥ прогиб + 10 мм") + lab(cx + chW / 2 + 6, y0 + 54, "уплотнитель EPDM");
    } else if (kind === "joint") {
      const y = 70, gl = 90;
      p += glassH(cx - 4 - gl, y, gl, gw) + glassH(cx + 4, y, gl, gw);
      p += '<rect x="' + (cx - 4) + '" y="' + y + '" width="8" height="' + gw + '" class="nd-sil"/>';
      p += lab(cx, y - 14, "шов 6–8 мм — прозрачный силикон", "middle") + lab(cx, y + gw + 22, "или поликарбонатный H-профиль", "middle") + lab(cx, y + gw + 38, "вид сверху", "middle");
    } else {
      const x0 = 40, y0 = 50, L = 120;
      p += glassH(x0, y0, L, gw) + glass(x0 + L - gw, y0 + gw + 6, gw, L - 10);
      p += '<rect x="' + (x0 + L - gw) + '" y="' + (y0 + gw) + '" width="' + gw + '" height="6" class="nd-sil"/>';
      p += lab(x0, y0 - 10, "угол 90° стекло–стекло") + lab(x0 + L + 8, y0 + gw + 30, "торец одного стекла") + lab(x0 + L + 8, y0 + gw + 44, "закрыт другим,") + lab(x0 + L + 8, y0 + gw + 58, "шов — силикон") + lab(x0, y0 + gw + 80, "вид сверху");
    }
    return p + "</svg>";
  }
  add({
    id: "glazing", cat: "glass", mark: "ветер + узлы", name: "Безрамное остекление (стационарное)", kw: "безрамное остекление стационарное панорамное глухое неоткрывающееся стекло в пол зажимной профиль триплекс закалённое стеклопакет структурное стеклянные рёбра стык стекло стекло силикон терраса витраж ветровая нагрузка",
    desc: "Глухое остекление без рам: раскрой стёкол, толщина по ветру, рёбра, узлы, тепло и конденсат, монтаж и спецификация",
    inputs: [
      { k: "shape", label: "Форма в плане", type: "sel", def: "line", opts: [["line", "Прямая"], ["L", "Угловая (2 стороны)"], ["U", "П-образная (3 стороны)"]] },
      { k: "W1", label: v => v.shape === "line" ? "Ширина проёма, мм" : "Сторона 1, мм", def: 6000 },
      { k: "W2", label: "Сторона 2, мм", def: 4000, show: v => v.shape !== "line" },
      { k: "W3", label: "Сторона 3, мм", def: 4000, show: v => v.shape === "U" },
      { k: "H", label: "Высота проёма от чистого пола до балки, мм", def: 2700 },
      { k: "fam", label: "Стекло", type: "sel", def: "lam", opts: [["mono", "Закалённое монолитное (холодное)"], ["lam", "Закалённый триплекс (холодное, безопасное)"], ["igu", "Безрамный стеклопакет (тёплое)"]] },
      { k: "g", label: "Толщина", type: "sel", def: "auto", opts: [["auto", "Подобрать по ветру"]].concat(Object.entries(GL).map(([k, g]) => [k, g[0]])) },
      { k: "maxW", label: "Наибольшая ширина одного стекла, мм", def: 1500, hint: "Ограничение — вес, доставка, подъём; производство закаляет до ≈ 2400×4800" },
      { k: "joint", label: "Вертикальные стыки", type: "sel", def: "sil", opts: [["sil", "Прозрачный силикон 6–8 мм"], ["h", "Поликарбонатный H-профиль"]] },
      { k: "fins", label: "Стеклянные рёбра жёсткости на стыках", type: "check", def: false },
      { k: "bot", label: "Нижний профиль", type: "sel", def: "floor", opts: [["floor", "Утоплен в пол (профиль не виден)"], ["on", "На чистовом полу"]] },
      { k: "defl", label: "Прогиб верхней балки под снегом, мм", def: 5, hint: "Из расчёта балки; под него оставляют зазор в верхнем профиле" },
      { k: "drop", label: "Снаружи перепад высоты (2-й этаж, балкон, обрыв)", type: "check", def: false },
      { k: "reg", label: "Ветровой район (СП 20)", type: "sel", def: "I", opts: W0.map(r => [r[0], r[0] + " — " + nf(r[1], 2) + " кПа" + (r[0] === "I" ? " (Москва, Н. Новгород)" : r[0] === "II" ? " (С.-Петербург)" : "")]) },
      { k: "z", label: "Высота верха остекления над землёй, м", def: 4 },
      { k: "terr", label: "Местность", type: "sel", def: "B", opts: [["A", "Открытая: поле, берег, степь"], ["B", "Пригород, посёлок, лес"], ["C", "Город с застройкой выше 25 м"]] },
      { k: "heat", label: "Помещение зимой", type: "sel", def: "cold", opts: [["warm", "Отапливается"], ["cold", "Не отапливается"]] },
      { k: "tout", label: "Расчётная зимняя температура, °C", def: -25, show: v => v.heat === "warm" }
    ],
    run(v) {
      const sides = [v.W1].concat(v.shape !== "line" ? [v.W2] : []).concat(v.shape === "U" ? [v.W3] : []).filter(x => x > 0);
      const Wtot = sides.reduce((s, x) => s + x, 0), j = v.joint === "sil" ? 7 : 4, wallGap = 8;
      const topGap = Math.max(10, v.defl + 10), bottomIn = 90, topIn = 25;
      const Hg = v.H + (v.bot === "floor" ? bottomIn - 5 : -10) + topIn - topGap - (v.bot === "on" ? 0 : 0);
      const Hvis = v.H - (v.bot === "floor" ? 0 : 100) - (topGap + topIn + 15);
      const w = windKPa(v.reg, v.z, v.terr);
      // раскрой
      const sideRes = sides.map((Ws, si) => {
        const ends = (v.shape === "line" ? 2 : si === 0 || si === sides.length - 1 ? 1 : 0);
        const corners = 2 - ends;
        const net = Ws - ends * wallGap - corners * 0; // угол стекло-стекло учтён в длине стороны
        const n = Math.max(1, ceil((net + j) / (v.maxW + j)));
        const pw = (net - (n - 1) * j) / n;
        return { Ws, n, pw };
      });
      const panes = sideRes.reduce((s, r) => s + r.n, 0), pwMax = Math.max(...sideRes.map(r => r.pw));
      // подбор стекла
      const fam = v.fam, list = FAM[fam];
      let gk = v.g !== "auto" ? v.g : list.find(k => glassCheck(GL[k], w, Hg, pwMax, v.fins).ok) || list[list.length - 1];
      const g = GL[gk], chk = glassCheck(g, w, Hg, pwMax, v.fins);
      const warn = [], notes = [];
      if (!chk.ok) warn.push((v.g === "auto" ? "Даже самое толстое стекло этой группы" : "Выбранное стекло") + " не проходит: σ = " + nf(chk.sig, 0) + " МПа (≤ 50), прогиб " + nint(chk.f) + " мм (≤ " + nint(chk.fLim) + "). " + (v.fins ? "Уменьшите ширину стёкол или высоту." : "Поставьте стеклянные рёбра на стыках — стекло начнёт работать на 4 опорах."));
      if (v.drop && fam === "mono") warn.push("Остекление в пол при перепаде снаружи выполняет роль ограждения — нужно ламинированное стекло (триплекс): при разрушении монолитное закалённое осыпается целиком.");
      if (Hg > 4800) warn.push("Стекло выше 4,8 м — у большинства заводов не закалить; нужна горизонтальная балка-ригель или спецзаказ.");
      if (v.fam !== "igu" && v.heat === "warm") warn.push("Одинарное стекло в отапливаемом помещении: большие теплопотери и конденсат зимой (см. ниже). Для жилого — безрамный стеклопакет.");
      const kgm2 = 2.5 * (g[1] === "igu" ? g[2] * 2 : g[1] === "lam" ? g[2] * 2 : g[2]);
      const area = sideRes.reduce((s, r) => s + r.n * r.pw * Hg, 0) / 1e6;
      const pm = pwMax / 1000 * Hg / 1000 * kgm2;
      if (pm > 150) notes.push("Стекло " + nint(pm) + " кг — монтаж краном или манипулятором с вакуумной траверсой.");
      else if (pm > 60) notes.push("Стекло " + nint(pm) + " кг — нужны вакуумные присоски и 3–4 монтажника.");
      // тепло
      let thermal = "";
      const ti = 20, to = v.tout, dew = (() => { const a = 17.62, b = 243.12, rh = 0.5; const gm = Math.log(rh) + a * ti / (b + ti); return b * gm / (a - gm); })();
      if (v.heat === "warm") {
        const U = g[4], tsi = ti - U * (ti - to) * 0.13, Q = U * area * (ti - to) / 1000;
        const cond = tsi < dew;
        thermal = '<div class="th-row"><div><b>' + nf(U, 1) + '</b> Вт/(м²·°C)<span>коэффициент теплопередачи</span></div><div><b>' + nf(Q, 1) + '</b> кВт<span>теплопотери при ' + to + ' °C</span></div><div class="' + (cond ? "bad" : "good") + '"><b>' + nf(tsi, 1) + ' °C</b><span>стекло изнутри · точка росы ' + nf(dew, 1) + " °C</span></div></div><p>" + (cond ? "Внутренняя поверхность холоднее точки росы — зимой стекло будет запотевать и обмерзать. Нужен стеклопакет с i-стеклом и тёплой дистанционной рамкой, конвектор в полу вдоль остекления." : "Конденсата при влажности 50% не будет. Вдоль остекления в пол всё равно ставят внутрипольный конвектор — он отсекает холодный нисходящий поток от стекла.") + "</p>";
      } else thermal = "<p>Холодное остекление защищает от ветра и осадков, но не держит тепло. Предусмотрите проветривание (щели 5–10 мм у потолка или клапан) — иначе зимой стёкла покроются инеем изнутри.</p>";
      // фасад
      const Wsvg = 860, pL = 10, gapS = 140, sc = Math.min((Wsvg - pL - 70) / (Wtot + (sides.length - 1) * gapS), 230 / v.H);
      const Hs = v.H * sc, top = 16, Ht = top + Hs + 44;
      let svg = '<svg viewBox="0 0 ' + Wsvg + " " + Ht + '" class="gl-svg" role="img" aria-label="Раскрой остекления"><defs><linearGradient id="glg" x1="0" x2="1" y1="0" y2="1"><stop offset="0" stop-color="#bfe0f2" stop-opacity=".55"/><stop offset="1" stop-color="#8fc7e8" stop-opacity=".25"/></linearGradient></defs>';
      let x = pL;
      sideRes.forEach((r, si) => {
        svg += '<rect x="' + x + '" y="' + top + '" width="' + r.Ws * sc + '" height="' + Hs + '" class="gl-open"/>';
        let px = x + (v.shape === "line" || si === 0 ? wallGap * sc : 0);
        for (let i = 0; i < r.n; i++) {
          svg += '<rect x="' + px + '" y="' + (top + 2) + '" width="' + Math.max(1, r.pw * sc) + '" height="' + (Hs - 4) + '" fill="url(#glg)" class="gl-pane2"/><path d="M' + (px + r.pw * sc * 0.15) + " " + (top + Hs * 0.25) + " l" + r.pw * sc * 0.18 + " -" + Hs * 0.12 + '" class="gl-shine"/>';
          svg += '<text x="' + (px + r.pw * sc / 2) + '" y="' + (top + Hs / 2) + '" class="gl-tr" text-anchor="middle">' + nint(r.pw) + "</text>";
          px += r.pw * sc;
          if (i < r.n - 1) { svg += v.fins ? '<rect x="' + (px - 1) + '" y="' + top + '" width="' + (j * sc + 2) + '" height="' + Hs + '" class="gl-fin"/>' : '<rect x="' + px + '" y="' + top + '" width="' + Math.max(1, j * sc) + '" height="' + Hs + '" class="gl-joint"/>'; px += j * sc; }
        }
        svg += '<rect x="' + x + '" y="' + (top + Hs - 3) + '" width="' + r.Ws * sc + '" height="3" class="gl-prof"/><rect x="' + x + '" y="' + top + '" width="' + r.Ws * sc + '" height="4" class="gl-prof"/>';
        svg += '<text x="' + (x + r.Ws * sc / 2) + '" y="' + (top + Hs + 20) + '" class="axis" text-anchor="middle">сторона ' + (si + 1) + ": " + nint(r.Ws) + " мм · " + r.n + " ст.</text>";
        if (si < sides.length - 1) svg += '<text x="' + (x + r.Ws * sc + gapS * sc / 2) + '" y="' + (top + Hs / 2) + '" class="axis" text-anchor="middle">угол</text>';
        x += r.Ws * sc + gapS * sc;
      });
      svg += '<text x="' + (Wsvg - 8) + '" y="' + (top + Hs / 2) + '" class="axis" text-anchor="end">' + nint(v.H) + "</text></svg>";
      // спецификация
      const L = Wtot / 1000, joints = sideRes.reduce((s, r) => s + r.n - 1, 0), corners = sides.length - 1, wallJ = v.shape === "line" ? 2 : 2;
      const silV = (v.joint === "sil" ? joints * j * g[3] * Hg : 0) + corners * 8 * g[3] * Hg + wallJ * 10 * g[3] * Hg + 4 * 36 * Wtot; // мм³
      const tubes = ceil(silV / 1e3 / 280);
      const items = [[g[0] + ", полированная кромка" + (g[1] !== "igu" ? ", закалка + Heat Soak" : ""), Math.round(area * 1.02 * 100) / 100, "м²"], ["Профиль зажимной нижний", Math.round(L * 1.03 * 10) / 10, "м"], ["Профиль верхний (с зазором " + topGap + " мм)", Math.round(L * 1.03 * 10) / 10, "м"], ["Подкладки под стекло", panes * 2, "шт."], ["Клин / уплотнитель EPDM", Math.round(L * 4 * 1.05), "м"], ["Силикон нейтральный прозрачный, 310 мл", tubes, "шт."]];
      if (v.joint === "h") items.push(["H-профиль поликарбонатный", Math.round(joints * Hg / 1000 * 10) / 10, "м"]);
      if (v.fins) { const fd = Math.max(150, Math.round(Hg / 12 / 10) * 10); items.push(["Рёбра — триплекс 12+12, глубина " + fd + " мм", Math.round(joints * fd * Hg / 1e6 * 100) / 100, "м²"]); notes.push("Рёбра жёсткости: " + joints + " шт., глубина ≈ " + Math.max(150, Math.round(Hg / 12 / 10) * 10) + " мм (≈ H/12), крепление — силикон структурный или фитинги."); }
      items.push(["Монтаж остекления", Math.round(area * 10) / 10, "м²"]);
      const rows = [["Расчётное давление ветра (пиковое)", nf(w, 2) + " кПа (≈ " + nint(w * 100) + " кг/м²)"], ["Схема опирания стекла", v.fins ? "4 стороны (низ, верх, рёбра)" : "2 стороны — низ и верх, боковые кромки свободны"], ["Напряжение в стекле", nf(chk.sig, 1) + " МПа из ≈ 50"], ["Прогиб при ветре", nint(chk.f) + " мм из " + nint(chk.fLim)], ["Высота стекла (полная / видимая)", nint(Hg) + " / " + nint(Hvis) + " мм"], ["Ширина стёкол", sideRes.map(r => nint(r.pw)).join(" / ") + " мм"], ["Масса 1 м² / самого тяжёлого стекла", nf(kgm2, 1) + " кг / " + nint(pm) + " кг"], ["Верхний профиль", "заглубление стекла " + topIn + " мм + зазор " + topGap + " мм"]];
      const montage = '<ol class="steps"><li><b>Проверка проёма.</b> Перепад основания по всей длине — не более ±2 мм, иначе выравнивают стяжкой. Верхняя балка — прогиб под снегом известен и ≤ ' + nint(topGap - 10) + " мм.</li><li><b>Нижний профиль.</b> Анкеры через 250–300 мм, выставить по нивелиру; при утоплении в пол — гидроизоляция штрабы и отвод воды наружу.</li><li><b>Верхний профиль</b> — строго над нижним (отвес/лазер), допуск ±1 мм.</li><li><b>Подкладки</b> — по 2 шт. на L/4 от краёв: стекло никогда не ставят на металл.</li><li><b>Установка стекла</b> вакуумными присосками: заводят в верхний профиль, опускают на подкладки, выставляют швы.</li><li><b>Фиксация</b> клиньями EPDM или зажимной системой с двух сторон, момент затяжки — по паспорту профиля.</li><li><b>Швы</b> — нейтральный прозрачный силикон после обезжиривания кромок, шов " + j + " мм; наружные примыкания — герметик и отлив.</li><li><b>Защитная плёнка и маркировка</b> — наклейки на уровне глаз, пока люди не привыкли к «невидимому» стеклу.</li></ol>";
      const rules = "<ul class=\"rules\"><li>Резка, сверление и обработка кромок — <b>только до закалки</b>, после закалки стекло не режут.</li><li>Для крупных закалённых стёкол заказывайте <b>Heat Soak Test</b> — снижает риск самопроизвольного разрушения из-за включений сульфида никеля.</li><li>Кромки — шлифованные или полированные: сколы на кромке — главная причина трещин.</li><li>Зазор между стеклом и стеной, колонной, соседним стеклом — <b>не меньше 5–8 мм</b>, заполняется силиконом: стекло не должно касаться твёрдого.</li><li>Над стеклом — только жёсткая балка или ригель: если верх «играет», стекло лопнет.</li><li>Если остекление в пол граничит с перепадом высоты — стекло работает как ограждение: <b>только триплекс</b>, нижняя граница — по нагрузке на ограждение.</li></ul>";
      return {
        stats: [S("Стёкол", nint(panes), "шт.", "ширина ≈ " + sideRes.map(r => nint(r.pw)).join(" / ") + " мм"), S("Стекло", g[0].replace(/ \(.*\)/, ""), "", v.g === "auto" ? "подобрано по ветру" : "задано", true), S("Площадь", nf(area, 2), "м²", "масса ≈ " + nint(area * kgm2) + " кг"), S("Самое тяжёлое стекло", nint(pm), "кг", nint(pwMax) + " × " + nint(Hg) + " мм"), S("Проверка стекла", chk.ok ? "проходит" : "не проходит", "", "σ " + nf(chk.sig, 0) + " МПа · прогиб " + nint(chk.f) + " мм")],
        warn: warn.join(" "), note: notes.join(" "),
        blocks: [
          { title: "Раскрой стёкол (развёртка)", html: '<div class="chart-scroll">' + svg + '</div><p class="hint">Цифры — ширина стекла, мм. ' + (v.fins ? "Тёмные полосы — стеклянные рёбра." : "Тонкие линии — швы " + j + " мм.") + "</p>" },
          { title: "Узлы", html: '<div class="nodes"><figure>' + nodeSVG("bottom", g) + "<figcaption>Низ: зажимной профиль</figcaption></figure><figure>" + nodeSVG("top", g) + "<figcaption>Верх: профиль с зазором на прогиб</figcaption></figure><figure>" + nodeSVG("joint", g) + "<figcaption>Стык стекло–стекло</figcaption></figure><figure>" + nodeSVG("corner", g) + "<figcaption>Угол без стойки</figcaption></figure></div>" },
          { title: v.heat === "warm" ? "Тепло и конденсат" : "Холодное остекление", html: thermal },
          { title: "Порядок монтажа", html: montage },
          { cls: "method", title: "Правила, которые нельзя нарушать", html: rules }
        ],
        table: { head: ["Параметр", "Значение"], rows },
        extra: items.map(i => [i[0], (typeof i[1] === "number" ? i[1].toLocaleString("ru-RU") : i[1]) + " " + i[2]]),
        items
      };
    },
    info: "Стационарное безрамное остекление — стекло вставлено в зажимной профиль снизу и в профиль с зазором сверху, боковые кромки соединены прозрачным швом. Ветер — по СП 20.13330 (пиковое давление с пульсациями и краевыми зонами). Стекло на двух опорах считается как полоса пролётом H, с рёбрами — как пластина, опёртая по контуру (коэффициенты Тимошенко). Двухслойные стёкла (триплекс, стеклопакет) — без учёта совместной работы слоёв, в запас. Допускаемое напряжение для закалённого стекла ≈ 50 МПа, прогиб — не более L/65 и 50 мм. Это предварительный подбор: финальную толщину и узлы подтверждает производитель профильной системы."
  });
