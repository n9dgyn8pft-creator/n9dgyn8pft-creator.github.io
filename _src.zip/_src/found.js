  // ====================================================================
  //  УЧАСТОК И ФУНДАМЕНТ
  // ====================================================================
  const bar = (pct, cls) => '<div class="meter"><span class="' + (cls || "") + '" style="width:' + Math.max(0, Math.min(100, pct)).toFixed(0) + '%"></span></div>';
  const goBtn = (id, label) => '<button type="button" class="chip" data-open="' + id + '">' + esc(label) + " →</button>";

  // ---------- Подбор типа фундамента ----------
  const F_SOILS = [["rock", "Скальный, крупнообломочный"], ["sandC", "Песок гравелистый, крупный, средний"], ["sandF", "Песок мелкий или пылеватый"], ["sandy", "Супесь"], ["loam", "Суглинок"], ["clay", "Глина"], ["peat", "Торф, ил, насыпной (слабый)"]];
  add({
    id: "fselect", cat: "found", mark: "подбор", name: "Какой фундамент выбрать", kw: "фундамент выбор подбор какой тип ушп плита лента мзлф сваи винтовые буронабивные тисэ столбчатый пучение грунт",
    desc: "Опишите участок и дом — получите типы фундамента по убыванию пригодности с причинами",
    inputs: [
      { k: "soil", label: "Грунт под подошвой", type: "sel", def: "loam", opts: F_SOILS, hint: "По геологии; если её нет — по шурфу глубиной 1,5–2 м" },
      { k: "gw", label: "Уровень грунтовых вод весной, м", def: 2.5, hint: "Глубина от поверхности. Смотрите в колодцах и шурфах в апреле" },
      { k: "df", label: "Глубина промерзания, м", def: () => { const f = store.get("lastFrost"); return f ? Math.round(f.dfn * 100) / 100 : 1.4; }, hint: "Посчитайте в калькуляторе «Промерзание» — подставится сама" },
      { k: "relief", label: "Рельеф участка", type: "sel", def: "flat", opts: [["flat", "Ровный (перепад до 0,5 м)"], ["mid", "Небольшой уклон (0,5–1,5 м)"], ["steep", "Сильный уклон (больше 1,5 м)"]] },
      { k: "walls", label: "Стены", type: "sel", def: "aer", opts: [["light", "Каркас, брус, бревно, СИП"], ["aer", "Газобетон, пеноблок, керамоблок"], ["brick", "Кирпич, керамзитоблок"], ["mono", "Монолит, камень"]] },
      { k: "floors", label: "Этажей", type: "sel", def: "2", opts: [["1", "1"], ["2", "2 (или 1 + мансарда)"], ["3", "3"]] },
      { k: "base", label: "Подвал", type: "sel", def: "none", opts: [["none", "Не нужен"], ["tech", "Техподполье / цоколь"], ["basement", "Жилой подвал"]] },
      { k: "live", label: "Проживание", type: "sel", def: "perm", opts: [["perm", "Круглый год, дом отапливается"], ["season", "Сезонно, зимой без отопления"]] },
      { k: "prio", label: "Что важнее", type: "sel", def: "bal", opts: [["cost", "Подешевле и быстрее"], ["bal", "Баланс цены и надёжности"], ["rel", "Максимальная надёжность"]] },
      { k: "wf", label: "Хочу тёплый пол на первом этаже", type: "check", def: true }
    ],
    run(v) {
      const df = v.df > 0 ? v.df : 1.4;
      const heavingSoil = ["sandF", "sandy", "loam", "clay"].includes(v.soil);
      const wet = v.gw <= df + 2;
      const heave = v.soil === "peat" ? "weak" : !heavingSoil ? "none" : (v.soil === "loam" || v.soil === "clay") ? (v.gw <= df + 1 ? "strong" : wet ? "mid" : "low") : (wet ? "mid" : "low");
      const HEAVE_T = { none: "непучинистый", low: "слабопучинистый", mid: "среднепучинистый", strong: "сильнопучинистый", weak: "слабый (сжимаемый)" };
      const heavy = v.walls === "brick" || v.walls === "mono", floors = +v.floors;
      const W = { light: 1, aer: 2, brick: 3, mono: 4 }[v.walls] + (floors - 1) * 0.6;
      const wTxt = W < 1.8 ? "лёгкий" : W < 3 ? "средний" : "тяжёлый";
      const O = [];
      const opt = (id, name, base) => { const o = { id, name, s: base, pros: [], cons: [], excl: null, depth: "", links: [] }; O.push(o); return o; };
      const P = (o, d, t) => { o.s += d; if (t) (d >= 0 ? o.pros : o.cons).push(t); };
      const X = (o, t) => { if (!o.excl) o.excl = t; };

      // УШП
      let o = opt("ushp", "Утеплённая шведская плита (УШП)", 68);
      o.pros.push("Плита, утепление и тёплый пол в одной конструкции", "Мелкое заложение: мало земляных работ, 2–3 недели работ");
      if (v.base !== "none") X(o, "Подвал или техподполье с УШП не сделать");
      if (v.relief === "steep") X(o, "На сильном уклоне нужна огромная подсыпка или подпорные стенки");
      if (v.relief === "mid") P(o, -18, "Уклон: подсыпка и подпорные стенки удорожают");
      if (v.live === "season") P(o, -35, "Без отопления зимой грунт под плитой промерзает — защита от пучения пропадает");
      if (v.walls === "light" || v.walls === "aer") P(o, 14, "Хорошо работает под лёгкий и средний дом");
      if (v.walls === "brick") P(o, floors > 1 ? -22 : -6, "Тяжёлые стены — усиленные рёбра и расчёт");
      if (v.walls === "mono") P(o, -35, "Монолитный дом слишком тяжёл для УШП");
      if (heave === "strong" || heave === "mid") P(o, 10, "Утеплённая «юбка» не даёт грунту промерзать — пучение не страшно");
      if (v.soil === "peat") P(o, -40, "Слабый грунт: только с заменой грунта и расчётом осадок");
      if (v.gw < 1) P(o, 4, "Мелкое заложение не уходит в воду (дренаж всё равно нужен)");
      if (v.wf) P(o, 10, "Тёплый пол уже встроен в плиту");
      if (v.prio === "cost") P(o, 2);
      o.depth = "Заглубление 0,3–0,5 м, песчано-щебёночная подушка 300–500 мм, ЭППС 100–200 мм под плитой и «юбка» по периметру.";
      o.links = [["volume", "Объём бетона"], ["rebar", "Арматура плиты"], ["insul", "Утеплитель"]];

      // Монолитная плита
      o = opt("slab", "Монолитная плита (мелкозаглублённая)", 58);
      o.pros.push("Распределяет вес на всю площадь — прощает неоднородный грунт");
      if (v.base === "basement") P(o, -8, "Под подвал — как днище со стенами в монолите, это уже другой бюджет");
      if (v.base === "tech") P(o, -12, "Техподполье с плитой неудобно — нужен цоколь");
      if (v.relief === "steep") P(o, -30, "На уклоне — подсыпка или ступенчатая конструкция");
      if (v.relief === "mid") P(o, -10);
      if (heavy) P(o, 14, "Хорошо держит тяжёлый каменный дом");
      if (floors === 3) P(o, 8);
      if (v.walls === "light") P(o, -10, "Для лёгкого дома избыточна по деньгам");
      if (heave === "strong") P(o, 10, "Работает на пучинистых грунтах (дом «плавает» вместе с плитой)");
      if (v.soil === "peat") P(o, 4, "Лучше других мелких вариантов на слабом грунте — но нужен расчёт осадок");
      if (v.gw < 1.5) P(o, 10, "Подходит при высоком уровне грунтовых вод");
      if (v.prio === "cost") P(o, -14, "Много бетона и арматуры — один из самых дорогих вариантов");
      if (v.prio === "rel") P(o, 10);
      if (v.live === "season") P(o, -8, "Без отопления — утеплять плиту по периметру");
      o.depth = "Заглубление 0,3–0,6 м, подушка 300–500 мм, плита 200–300 мм с двумя сетками.";
      o.links = [["volume", "Объём бетона"], ["rebar", "Арматура плиты"], ["loads", "Нагрузка на грунт"]];

      // МЗЛФ
      o = opt("mzlf", "Мелкозаглублённая лента (МЗЛФ)", 58);
      o.pros.push("Дешевле заглублённой ленты в 1,5–2 раза");
      if (v.base === "basement") X(o, "Для подвала нужна лента ниже промерзания");
      if (v.soil === "peat") X(o, "На слабом грунте мелкая лента даст неравномерную осадку");
      if (v.base === "tech") P(o, -8, "Только невысокое техподполье");
      if (v.relief === "steep") P(o, -25, "На сильном уклоне — высокий цоколь, лучше сваи");
      if (v.relief === "mid") P(o, -8);
      if (v.walls === "light" || v.walls === "aer") P(o, 10, "Подходит под лёгкий и средний дом");
      if (v.walls === "brick" && floors > 1) P(o, -15, "Двухэтажный кирпич — нагрузка велика для мелкой ленты");
      if (v.walls === "mono") P(o, -30);
      if (heave === "strong") P(o, -25, "Сильное пучение: обязательно утепление, песчаная подушка и дренаж — есть риск трещин");
      if (heave === "mid") P(o, -10, "Пучинистый грунт: утеплённая отмостка, подушка и дренаж обязательны");
      if (heave === "none") P(o, 12, "На непучинистом грунте — надёжный и экономичный вариант");
      if (v.live === "season" && heave !== "none") P(o, -20, "Неотапливаемый дом на пучинистом грунте лента может поднять");
      if (v.gw < 1) P(o, -15, "Высокие воды — подушка будет мокнуть и пучить");
      if (v.prio === "cost") P(o, 14);
      o.depth = "Заглубление 0,5–0,7 м (≈ " + nf(Math.min(0.7, Math.max(0.5, df * 0.4)), 1) + " м), подушка 300–600 мм, утеплённая отмостка 1–1,2 м.";
      o.links = [["volume", "Объём бетона"], ["rebar", "Арматура ленты"], ["loads", "Ширина ленты"]];

      // Заглублённая лента
      o = opt("strip", "Ленточный ниже промерзания (монолит или ФБС)", 55);
      o.pros.push("Классика под каменный дом, позволяет сделать подвал");
      if (v.base === "basement") P(o, 30, "Подвал — самый естественный вариант");
      if (v.base === "tech") P(o, 15, "Удобно сделать техподполье");
      if (v.gw < df + 0.5) P(o, -25, "Подошва попадает в грунтовые воды: водопонижение, гидроизоляция, дренаж");
      else if (v.gw < df + 1) P(o, -8, "Воды близко к подошве — обязателен дренаж");
      if (heavy) P(o, 14, "Хорошо держит тяжёлый каменный дом");
      if (v.walls === "aer") P(o, 5);
      if (v.walls === "light") P(o, -20, "Лёгкий дом не удержит ленту от касательных сил пучения — её может поднять");
      if (heave === "strong" || heave === "mid") P(o, v.walls === "light" ? -10 : -4, "Пучение по боковым стенкам: обратная засыпка песком, утепление");
      if (heave === "none") P(o, 5);
      if (v.relief === "steep") P(o, -8, "Лента ступенями — сложнее, но возможно");
      if (v.soil === "peat") P(o, -40, "Опирать ленту на торф нельзя — менять грунт или сваи");
      if (v.prio === "cost") P(o, df > 1.5 ? -16 : -8, "Глубокая траншея, много бетона и гидроизоляции");
      if (v.prio === "rel") P(o, 6);
      o.depth = "Подошва ниже промерзания: ≥ " + nf(df, 2) + " м (или глубже под подвал), подушка 200–300 мм; монолит или ФБС на ленточных плитах ФЛ.";
      o.links = [["fbs", "Раскладка ФБС"], ["loads", "Ширина подошвы"], ["volume", "Объём бетона"]];

      // Буронабивные / ТИСЭ
      o = opt("bored", "Буронабивные сваи (ТИСЭ) с ростверком", 58);
      o.pros.push("Опираются ниже промерзания — пучение и отопление не важны", "Мало земляных работ");
      if (v.base === "basement") X(o, "С подвалом не сочетается");
      if (v.base === "tech") P(o, -4, "Техподполье — за счёт высокого ростверка");
      if (v.relief === "steep") P(o, 16, "Уклон не проблема — разная высота свай");
      if (v.relief === "mid") P(o, 10);
      if (heave === "strong") P(o, 14, "Один из лучших вариантов на сильнопучинистом грунте");
      if (heave === "mid") P(o, 10);
      if (v.gw < 1) P(o, -15, "Бурение в воде: обсадные трубы, бетон сложно залить качественно");
      if (v.walls === "aer") P(o, 8);
      if (v.walls === "light") P(o, 4);
      if (v.walls === "mono") P(o, -6, "Тяжёлый дом — много свай и мощный ростверк по расчёту");
      if (v.soil === "peat") P(o, 4, "Если сваи пройдут торф до плотного слоя — нужны изыскания");
      if (v.live === "season") P(o, 10, "Не зависит от отопления зимой");
      if (v.soil === "rock") P(o, -20, "Скальный грунт сложно бурить — и сваи не нужны");
      if (v.prio === "cost") P(o, 6);
      if (v.wf) P(o, -3, "Тёплый пол — по перекрытию или по грунту с утеплением");
      o.depth = "Сваи Ø 250–400 мм с уширением, низ ≥ " + nf(df + 0.3, 2) + " м, шаг 1,5–2 м; монолитный ростверк (под каменные стены — висячий, с зазором от грунта).";
      o.links = [["loads", "Количество свай"], ["volume", "Объём бетона"], ["rebar", "Арматура ростверка"]];

      // Винтовые
      o = opt("screw", "Винтовые сваи", 52);
      o.pros.push("Монтаж за 1–2 дня в любое время года, без бетона");
      if (v.soil === "rock") X(o, "В скальный и крупнообломочный грунт сваи не завинтить");
      if (v.base !== "none") X(o, "С подвалом и техподпольем не сочетается");
      if (v.walls === "mono") X(o, "Монолитный или каменный дом на винтовых сваях — нет");
      if (v.walls === "brick") P(o, -40, "Кирпич — только с массивным ж/б ростверком и по расчёту");
      if (v.walls === "light") P(o, 26, "Идеально для каркаса, бруса, бани");
      if (v.walls === "aer") P(o, floors > 1 ? -25 : -12, "Газобетон боится перекосов — нужен жёсткий монолитный ростверк");
      if (v.relief === "steep") P(o, 24, "Лучший вариант на сильном уклоне");
      if (v.relief === "mid") P(o, 14);
      if (v.gw < 1.5) P(o, 10, "Не боятся высоких грунтовых вод");
      if (v.soil === "peat") P(o, 14, "Длинными сваями проходят слабый слой до плотного");
      if (heave !== "none") P(o, 4);
      if (v.live === "season") P(o, 10);
      if (v.prio === "cost") P(o, 14);
      if (v.prio === "rel") P(o, -8, "Ресурс ограничен коррозией: толщина ствола ≥ 4 мм, бетонирование ствола");
      if (v.wf) P(o, -4, "Пол по перекрытию — продумать утепление снизу");
      o.depth = "Лопасть ниже промерзания (≥ " + nf(df + 0.2, 2) + " м) в плотном слое; длину уточняет пробная завинчивка. Ø 108–133 мм, стенка ≥ 4 мм.";
      o.links = [["loads", "Количество свай"], ["metal", "Масса обвязки"]];

      // Столбчатый
      o = opt("column", "Столбчатый", 40);
      o.pros.push("Самый дешёвый вариант для лёгких строений");
      if (v.walls === "brick" || v.walls === "mono") X(o, "Только для лёгких домов, бань и хозпостроек");
      if (v.base !== "none") X(o, "Без подвала");
      if (v.soil === "peat") X(o, "На слабом грунте столбы просядут неравномерно");
      if (v.walls === "aer") P(o, -40, "Газобетон на столбах трескается — нужен жёсткий ростверк");
      if (v.walls === "light") P(o, 20, "Хватит для каркасного дома и бани");
      if (heave === "strong") P(o, -25, "Пучение выталкивает столбы — нужно уширение и засыпка песком");
      if (heave === "mid") P(o, -10);
      if (v.relief === "steep") P(o, 4);
      if (v.prio === "cost") P(o, 18);
      if (v.prio === "rel") P(o, -10);
      o.depth = "Столбы ниже промерзания (" + nf(df, 2) + " м) с уширением подошвы, на непучинистых грунтах — на подушке 0,5–0,8 м.";
      o.links = [["volume", "Объём бетона"]];

      O.forEach(o => o.s = Math.max(3, Math.min(98, Math.round(o.s))));
      O.sort((a, b) => (a.excl ? 1 : 0) - (b.excl ? 1 : 0) || b.s - a.s);
      const verdict = o => o.excl ? ["Не подходит", "bad"] : o.s >= 75 ? ["Рекомендуется", "good"] : o.s >= 60 ? ["Хороший вариант", "good"] : o.s >= 45 ? ["Возможен, с оговорками", "mid"] : ["Не рекомендуется", "bad"];
      const top = O.filter(o => !o.excl).slice(0, 2);
      const cards = O.map((o, i) => {
        const [vt, vc] = verdict(o);
        return '<div class="opt ' + vc + (o.excl ? " off" : "") + '"><div class="opt-h"><span class="opt-n">' + (i + 1) + '</span><div class="opt-t"><b>' + esc(o.name) + '</b><span class="tag-v ' + vc + '">' + vt + "</span></div>" + (o.excl ? "" : '<span class="opt-s">' + o.s + "</span>") + "</div>" +
          (o.excl ? "" : bar(o.s, vc)) +
          (o.excl ? '<p class="opt-x">' + esc(o.excl) + "</p>" :
            '<ul class="pc">' + o.pros.map(t => '<li class="p">' + esc(t) + "</li>").join("") + o.cons.map(t => '<li class="c">' + esc(t) + "</li>").join("") + "</ul>" +
            '<p class="opt-d">' + esc(o.depth) + "</p>" + '<div class="chips">' + o.links.map(l => goBtn(l[0], l[1])).join("") + "</div>") + "</div>";
      }).join("");
      return {
        stats: [S("Грунт", HEAVE_T[heave], "", v.gw <= df + 2 ? "воды близко к зоне промерзания" : "воды глубоко"), S("Дом", wTxt, "", floors + " эт. · " + { light: "лёгкие стены", aer: "блоки", brick: "кирпич", mono: "монолит" }[v.walls]), S("Лучший вариант", top[0] ? top[0].name.replace(/ \(.*\)/, "") : "—", "", top[1] ? "далее: " + top[1].name.replace(/ \(.*\)/, "") : "", true)],
        blocks: [{ title: "Варианты по убыванию пригодности", html: '<div class="opts">' + cards + "</div>" }, { cls: "method", html: "<p><strong>Перед выбором обязательно:</strong> инженерно-геологические изыскания — минимум 3 скважины на глубину 5–6 м под пятном дома. Они покажут слои грунта, его несущую способность и реальный уровень вод. Подбор здесь — экспертная оценка по типовым правилам, а не проект. Окончательное решение — за проектировщиком.</p>" }],
        warn: v.soil === "peat" ? "Торф и насыпной грунт: без изысканий фундамент не выбирать — возможно, слабый слой проще заменить." : ""
      };
    }
  });

  // ---------- Глубина промерзания ----------
  const D0 = { rock: 0.34, sandC: 0.30, sandF: 0.28, sandy: 0.28, loam: 0.23, clay: 0.23 };
  const KH = { slab: [0.9, 0.8, 0.7, 0.6, 0.5], lags: [1.0, 0.9, 0.8, 0.7, 0.6], ins: [1.0, 1.0, 0.9, 0.8, 0.7], base: [0.8, 0.7, 0.6, 0.5, 0.4] };
  const MON = ["янв", "фев", "мар", "апр", "май", "июн", "июл", "авг", "сен", "окт", "ноя", "дек"];
  async function loadClimate(p) {
    const key = "clim:" + p.latitude.toFixed(2) + "," + p.longitude.toFixed(2);
    const c = store.get(key);
    if (c && c.v === 3) return c;
    const y2 = new Date().getFullYear() - 1, y1 = y2 - 14;
    const r = await fetch("https://archive-api.open-meteo.com/v1/archive?latitude=" + p.latitude + "&longitude=" + p.longitude + "&start_date=" + y1 + "-01-01&end_date=" + y2 + "-12-31&daily=temperature_2m_mean,temperature_2m_min&timezone=auto");
    if (!r.ok) throw new Error("HTTP " + r.status);
    const j = await r.json();
    const t = j.daily.time, T = j.daily.temperature_2m_mean, Tn = j.daily.temperature_2m_min || [];
    const ym = {}; // "YYYY-MM" -> [sum, n]
    t.forEach((d, i) => { if (T[i] == null) return; const k = d.slice(0, 7); (ym[k] = ym[k] || [0, 0]); ym[k][0] += T[i]; ym[k][1]++; });
    const sums = Array(12).fill(0), cnt = Array(12).fill(0);
    Object.entries(ym).forEach(([k, [s, n]]) => { const m = +k.slice(5) - 1; sums[m] += s / n; cnt[m]++; });
    const mon = sums.map((s, i) => cnt[i] ? s / cnt[i] : 0);
    // зимы: июль–июнь
    const winters = [];
    for (let y = y1; y < y2; y++) {
      let mt = 0, ok = true;
      for (let m = 7; m <= 18; m++) { const yy = m > 12 ? y + 1 : y, mm = m > 12 ? m - 12 : m; const v = ym[yy + "-" + String(mm).padStart(2, "0")]; if (!v) { ok = false; break; } const avg = v[0] / v[1]; if (avg < 0) mt -= avg; }
      if (ok) winters.push({ y, mt });
    }
    // отопительный период (дни ≤ +8 °C), в среднем за год
    let hd = 0, hs = 0;
    t.forEach((d, i) => { if (T[i] != null && T[i] <= 8) { hd++; hs += T[i]; } });
    const years = y2 - y1 + 1;
    // абсолютный минимум года, последние весенние и первые осенние заморозки (по минимальной температуре воздуха)
    const yr = {};
    t.forEach((d, i) => {
      const x = Tn[i]; if (x == null) return;
      const y = +d.slice(0, 4), doy = Math.round((Date.UTC(y, +d.slice(5, 7) - 1, +d.slice(8, 10)) - Date.UTC(y, 0, 1)) / 864e5) + 1;
      const o = yr[y] = yr[y] || { min: 99, last: 0, first: 400 };
      if (x < o.min) o.min = x;
      if (x <= 0 && doy < 183 && doy > o.last) o.last = doy;
      if (x <= 0 && doy >= 183 && doy < o.first) o.first = doy;
    });
    const ys = Object.values(yr).filter(o => o.min < 99);
    const avg = a => a.length ? a.reduce((s, x) => s + x, 0) / a.length : null;
    const tmin = avg(ys.map(o => o.min)), last = avg(ys.filter(o => o.last).map(o => o.last)), first = avg(ys.filter(o => o.first < 400).map(o => o.first));
    const lastMax = ys.length ? Math.max(...ys.map(o => o.last)) : null;
    const res = { v: 3, y1, y2, mon, winters, hsDays: hd / years, hsT: hd ? hs / hd : 0, tmin, last, first, lastMax };
    store.set(key, res);
    return res;
  }
  function monthChart(mon) {
    const W = 600, H = 170, pL = 30, pB = 22, pT = 14, pw = W - pL - 6, ph = H - pT - pB;
    const lo = Math.min(-15, Math.floor(Math.min(...mon) / 5) * 5), hi = Math.max(25, Math.ceil(Math.max(...mon) / 5) * 5);
    const y = v => pT + ph - (v - lo) / (hi - lo) * ph, slot = pw / 12;
    let s = '<svg viewBox="0 0 ' + W + " " + H + '" class="mini-chart" role="img" aria-label="Среднемесячные температуры">';
    for (let v = lo; v <= hi; v += 10) s += '<line x1="' + pL + '" x2="' + (W - 6) + '" y1="' + y(v) + '" y2="' + y(v) + '" class="' + (v === 0 ? "zero" : "grid") + '"/><text x="' + (pL - 6) + '" y="' + (y(v) + 3) + '" class="axis" text-anchor="end">' + v + "</text>";
    if (lo < 0 && hi > 0) s += '<line x1="' + pL + '" x2="' + (W - 6) + '" y1="' + y(0) + '" y2="' + y(0) + '" class="zero"/>';
    mon.forEach((m, i) => {
      const x = pL + i * slot + 4, top = Math.min(y(m), y(0)), h = Math.max(2, Math.abs(y(m) - y(0)));
      s += '<rect x="' + x + '" y="' + top + '" width="' + (slot - 8) + '" height="' + h + '" rx="2" fill="' + (m < 0 ? "var(--str)" : "var(--temp)") + '"><title>' + MON[i] + ": " + nf(m, 1) + ' °C</title></rect>';
      s += '<text x="' + (x + (slot - 8) / 2) + '" y="' + (m < 0 ? top + h + 11 : top - 4) + '" class="axis" text-anchor="middle">' + nf(m, 1) + "</text>";
      s += '<text x="' + (x + (slot - 8) / 2) + '" y="' + (H - 6) + '" class="axis" text-anchor="middle">' + MON[i] + "</text>";
    });
    return s + "</svg>";
  }
  add({
    id: "frost", cat: "found", mark: "по погоде", name: "Промерзание и глубина труб", kw: "глубина промерзания заложения фундамента водопровод канализация трубы сп 22 сп 131 мороз нулевой цикл",
    desc: "Промерзание по реальной погоде за 15 лет, глубина фундамента по СП 22, водопровода и канализации",
    inputs: [
      { k: "place", label: "Населённый пункт", type: "place" },
      { k: "soil", label: "Грунт", type: "sel", def: "loam", opts: F_SOILS.filter(s => s[0] !== "peat") },
      { k: "state", label: "Состояние глинистого грунта", type: "sel", def: "plastic", opts: [["firm", "Твёрдый, тугопластичный (комком не мнётся)"], ["plastic", "Мягкопластичный, влажный"]], show: v => ["sandy", "loam", "clay"].includes(v.soil) },
      { k: "gw", label: "Уровень грунтовых вод, м", def: 2.5 },
      { k: "floor", label: "Пол первого этажа", type: "sel", def: "lags", opts: [["slab", "По грунту (плита, бетонный пол)"], ["lags", "На лагах по грунту"], ["ins", "По утеплённому цокольному перекрытию"], ["base", "Есть подвал или техподполье"], ["cold", "Дом не отапливается"]] },
      { k: "tin", label: "Температура в доме зимой", type: "sel", def: "4", opts: [["0", "0 °C"], ["1", "+5 °C"], ["2", "+10 °C"], ["3", "+15 °C"], ["4", "+20 °C и выше"]], show: v => v.floor !== "cold" },
      { k: "src", label: "Данные о морозах", type: "sel", def: "auto", opts: [["auto", "Погода за 15 лет (автоматически)"], ["manual", "Ввести сумму морозов вручную"]] },
      { k: "mt", label: "Сумма среднемесячных отрицательных температур, °C", def: 25, show: v => v.src === "manual", hint: "Mt по СП 131 для вашего города, без знака минус" },
      { k: "pd", label: "Диаметр канализационной трубы, мм", def: 110 }
    ],
    loadKey: v => v.src === "auto" ? v.place.latitude.toFixed(2) + "," + v.place.longitude.toFixed(2) : "manual",
    load: v => v.src === "auto" ? loadClimate(v.place) : Promise.resolve(null),
    run(v, data, loading) {
      let mt = v.mt, note = "", blocks = [];
      if (v.src === "auto") {
        if (loading) return { note: "Загружаю погоду за 15 лет для " + v.place.name + "…" };
        if (!data || data.error) return { warn: "Не удалось загрузить погоду (на этой странице сетевые запросы закрыты или нет интернета). Выберите «Ввести сумму морозов вручную» — Mt для вашего города есть в СП 131.13330, таблица 5.1." };
        mt = data.mon.filter(m => m < 0).reduce((s, m) => s - m, 0);
        const ws = data.winters.slice().sort((a, b) => b.mt - a.mt);
        note = "Погода " + data.y1 + "–" + data.y2 + " гг., " + placeLabel(v.place) + ".";
        const hard = ws[0];
        blocks.push({ title: "Среднемесячные температуры, °C", html: monthChart(data.mon) + (hard ? '<p class="hint" style="margin-top:8px">Самая холодная зима: ' + hard.y + "/" + String(hard.y + 1).slice(2) + " — Mt = " + nf(hard.mt, 1) + ", промерзание суглинка тогда ≈ " + nf(0.23 * Math.sqrt(hard.mt), 2) + " м. Отопительный период ≈ " + nint(data.hsDays) + " сут при средней " + nf(data.hsT, 1) + " °C (ГСОП ≈ " + nint((20 - data.hsT) * data.hsDays) + ").</p>" : "") });
      }
      const d0 = D0[v.soil], dfn = d0 * Math.sqrt(Math.max(0, mt));
      const kh = v.floor === "cold" ? 1.1 : KH[v.floor][+v.tin];
      const df = kh * dfn;
      // СП 22, табл. 5.3
      let minD, rule;
      const far = v.gw > df + 2;
      if (v.soil === "rock" || v.soil === "sandC") { minD = null; rule = "Грунт непучинистый: глубина заложения не зависит от промерзания"; }
      else if (v.soil === "sandF") { minD = far ? null : df; rule = far ? "Воды глубже df + 2 м — не зависит от промерзания" : "Воды выше df + 2 м — не менее df"; }
      else if (v.state === "plastic") { minD = df; rule = "Пластичный глинистый грунт — не менее df при любом уровне вод"; }
      else if (v.soil === "sandy") { minD = far ? null : df; rule = far ? "Твёрдая супесь, воды глубоко — не зависит от промерзания" : "Воды выше df + 2 м — не менее df"; }
      else { minD = far ? 0.5 * df : df; rule = far ? "Тугопластичный грунт, воды глубоко — не менее 0,5·df" : "Воды выше df + 2 м — не менее df"; }
      const fd = minD == null ? 0.5 : Math.max(0.5, minD);
      const water = dfn + 0.5;
      const sewTop = Math.max(dfn - 0.3, 0.7), sew = sewTop + v.pd / 1000;
      store.set("lastFrost", { dfn, df, place: v.place && v.place.name });
      return {
        note,
        stats: [S("Сумма морозов Mt", nf(mt, 1), "°C·мес"), S("Нормативное промерзание dfn", nf(dfn, 2), "м", "открытая площадка без снега"), S("Расчётное у дома df", nf(df, 2), "м", "kh = " + nf(kh, 1)), S("Минимальная глубина подошвы", nf(fd, 2), "м", minD == null ? "конструктивно, от поверхности" : "по СП 22.13330", true), S("Водопровод (низ трубы)", nf(water, 2), "м", "dfn + 0,5 м по СП 31"), S("Канализация (лоток)", nf(sew, 2), "м", "верх трубы ≥ " + nf(sewTop, 2) + " м по СП 32")],
        blocks,
        table: { head: ["Параметр", "Значение"], rows: [["Коэффициент для грунта d0", nf(d0, 2) + " м"], ["Правило СП 22 (табл. 5.3)", rule], ["Уровень вод относительно df + 2 м", nf(v.gw, 2) + " м " + (far ? ">" : "≤") + " " + nf(df + 2, 2) + " м"]] }
      };
    },
    info: "dfn = d0·√Mt (СП 22.13330, формула 5.3), где Mt — сумма абсолютных значений среднемесячных отрицательных температур, d0 — 0,23 м для суглинков и глин, 0,28 м для супесей и мелких песков, 0,30 м для крупных песков, 0,34 м для крупнообломочных. df = kh·dfn — тепло дома уменьшает промерзание у фундамента (табл. 5.2). Mt считается по фактической погоде последних 15 лет — зимы теплеют, поэтому значение обычно меньше, чем в старых таблицах СП 131. Для ответственных решений сверяйтесь с СП 131 и берите больший результат. Под расчищенным от снега проездом грунт промерзает глубже — там трубы утепляют ЭППС."
  });

  // ---------- Нагрузка на фундамент ----------
  const WALL_M = { aer5: ["Газобетон D500", 600, 300], aer4: ["Газобетон D400", 500, 375], kblock: ["Керамоблок", 900, 380], keramz: ["Керамзитобетонный блок", 1200, 390], brickH: ["Кирпич керамический пустотелый", 1400, 380], brickS: ["Кирпич силикатный", 1900, 380], brickC: ["Кирпич керамический полнотелый", 1800, 380], wood: ["Брус, бревно", 600, 200], frame: ["Каркас с утеплителем", 0, 200], mono: ["Монолит ж/б", 2500, 200] };
  const R_SOIL = { sandC: ["Песок крупный, средний", 450, 0.125], sandF: ["Песок мелкий маловлажный", 300, 0.125], sandFw: ["Песок мелкий влажный", 200, 0.125], silt: ["Песок пылеватый влажный", 150, 0.05], sandy: ["Супесь", 250, 0.05], loamF: ["Суглинок тугопластичный", 220, 0.05], loamS: ["Суглинок мягкопластичный", 150, 0.05], clayF: ["Глина тугопластичная", 300, 0.05], clayS: ["Глина мягкопластичная", 180, 0.05], fill: ["Насыпной, слежавшийся", 100, 0.05] };
  add({
    id: "loads", cat: "found", mark: "вес дома", name: "Нагрузка на фундамент и ширина ленты", kw: "нагрузка вес дома сбор нагрузок ширина подошвы ленты давление на грунт несущая способность сваи количество свай винтовые снеговая",
    desc: "Сколько весит дом, давление на грунт, минимальная ширина подошвы и число свай",
    inputs: [
      { k: "L", label: "Длина дома по осям, м", def: 10 }, { k: "B", label: "Ширина дома по осям, м", def: 9 },
      { k: "fl", label: "Этажей", def: 2 }, { k: "h", label: "Высота этажа, м", def: 3 },
      { k: "wm", label: "Материал стен", type: "sel", def: "aer5", opts: Object.entries(WALL_M).map(([k, w]) => [k, w[0]]) },
      { k: "wt", label: "Толщина наружных стен, мм", def: v => WALL_M[v.wm] ? WALL_M[v.wm][2] : 300, dep: "wm" },
      { k: "clad", label: "Облицовка фасада", type: "sel", def: "40", opts: [["0", "Нет"], ["25", "Сайдинг, вентфасад (25 кг/м²)"], ["40", "Штукатурка (40 кг/м²)"], ["230", "Облицовочный кирпич 120 мм (230 кг/м²)"]] },
      { k: "il", label: "Внутренние несущие стены, м", def: 9, hint: "Длина на этаж, толщина 200–250 мм" },
      { k: "ft", label: "Перекрытия", type: "sel", def: "wood", opts: [["150", "Деревянные балки"], ["420", "Пустотные плиты + стяжка"], ["600", "Монолит 200 мм + стяжка"]] },
      { k: "p1", label: "Пол 1-го этажа", type: "sel", def: "grnd", opts: [["grnd", "По грунту (на ленту не давит)"], ["slab", "Перекрытие, опёртое на фундамент"]] },
      { k: "rf", label: "Кровля", type: "sel", def: "50", opts: [["50", "Металлочерепица, профнастил"], ["70", "Гибкая черепица"], ["120", "Керамическая, цементно-песчаная черепица"]] },
      { k: "snow", label: "Снеговой район", type: "sel", def: "1.5", opts: [["0.5", "I (0,5 кПа)"], ["1", "II (1,0 кПа)"], ["1.5", "III (1,5 кПа) — Москва, Нижний Новгород"], ["2", "IV (2,0 кПа)"], ["2.5", "V (2,5 кПа)"], ["3", "VI (3,0 кПа)"], ["3.5", "VII (3,5 кПа)"], ["4", "VIII (4,0 кПа)"]] },
      { k: "soil", label: "Грунт под подошвой", type: "sel", def: "loamF", opts: Object.entries(R_SOIL).map(([k, s]) => [k, s[0] + " (R0 ≈ " + s[1] + " кПа)"]) },
      { k: "fd", label: "Глубина подошвы от земли, м", def: 1.5 }, { k: "fc", label: "Высота цоколя над землёй, м", def: 0.4 },
      { k: "fb", label: "Ширина подошвы, м", def: 0.4 },
      { k: "pile", label: "Несущая способность одной сваи, т", def: 3, hint: "Винтовая Ø108 ≈ 2–4 т, буронабивная Ø300 ≈ 3–6 т — по грунту" }
    ],
    run(v) {
      const w = WALL_M[v.wm], A = v.L * v.B, P = 2 * (v.L + v.B), Hw = v.fl * v.h;
      const wallArea = P * Hw * 0.85; // 15% проёмы
      const wallKg = w[1] ? wallArea * v.wt / 1000 * w[1] : wallArea * 60;
      const cladKg = wallArea * num(v.clad);
      const intKg = v.il * Hw * (w[1] ? 0.22 * w[1] : 50) * 0.9;
      const nFl = v.fl + (v.p1 === "slab" ? 1 : 0);
      const floorKg = A * nFl * num(v.ft);
      const liveKg = A * ((v.fl - 1 + (v.p1 === "slab" ? 1 : 0)) * (150 + 50) + 70);
      const roofKg = A * 1.3 * num(v.rf), snowKg = A * num(v.snow) * 100;
      const total = (wallKg + cladKg + intKg + floorKg + liveKg + roofKg + snowKg) / 1000; // т
      const Lb = P + v.il, q = Lb > 0 ? total / Lb : 0, qmax = q * 1.25;
      const Hf = v.fd + v.fc, selfq = v.fb * Hf * 2.4;
      const s = R_SOIL[v.soil], d = Math.min(v.fd, 2);
      const R = s[1] * (1 + s[2] * (v.fb - 1)) * (d + 2) / 4;
      const p = v.fb > 0 ? (qmax + selfq) * 9.81 / v.fb : 0;
      const den = R - Hf * 2.4 * 9.81, bmin = den > 0 ? qmax * 9.81 / den : 0;
      const piles = Math.max(v.pile > 0 ? ceil(total * 1.1 / v.pile) : 0, ceil(P / 2.5) + ceil(v.il / 2.5) + 4);
      const ok = p <= R;
      const rows = [["Наружные стены", wallKg], ["Облицовка", cladKg], ["Внутренние стены", intKg], ["Перекрытия (" + nFl + " шт.)", floorKg], ["Полезная нагрузка и перегородки", liveKg], ["Кровля", roofKg], ["Снег", snowKg]].map(r => [r[0], nf(r[1] / 1000, 1) + " т", nint(r[1] / total / 10) + "%"]);
      return {
        stats: [S("Вес дома с нагрузками", nf(total, 0), "т", "без фундамента"), S("На 1 м ленты", nf(q, 2), "т/м", "самая нагруженная ≈ " + nf(qmax, 2) + " т/м"), S("Давление под подошвой", nint(p), "кПа", "допустимо R ≈ " + nint(R) + " кПа", ok), S("Минимальная ширина подошвы", bmin > 0 ? nf(Math.max(bmin, 0.3), 2) : "—", "м", bmin > v.fb ? "сейчас " + nf(v.fb, 2) + " м — мало" : "текущая " + nf(v.fb, 2) + " м — хватает", true), S("Если на сваях", nint(piles), "шт.", "по нагрузке и шагу ≤ 2,5 м")],
        warn: ok ? "" : "Давление " + nint(p) + " кПа больше расчётного сопротивления грунта " + nint(R) + " кПа — расширьте подошву минимум до " + nf(bmin, 2) + " м (ленточная плита ФЛ или уширение).",
        table: { cap: "Из чего складывается вес", head: ["Нагрузка", "Вес", "Доля"], rows },
        extra: [["Фундамент (на 1 м)", nf(selfq, 2) + " т/м"], ["Несущих стен всего", nf(Lb, 1) + " м"], ["Расчётное сопротивление R", nint(R) + " кПа (R0 = " + s[1] + " кПа с поправкой на ширину и глубину)"]]
      };
    },
    info: "Упрощённый сбор нагрузок (нормативные значения, без коэффициентов надёжности): вес стен с проёмами 15%, перекрытий, кровли (площадь ×1,3), снега по СП 20, полезной нагрузки 1,5 кПа + перегородки 0,5 кПа. Нагрузка распределяется по всем несущим стенам; наиболее нагруженная принята с коэффициентом 1,25. R0 — ориентировочно по таблицам приложения Б СП 22, с пересчётом на ширину и глубину подошвы. Это оценка для выбора — для проекта нужен расчёт по данным изысканий."
  });

  // ---------- Раскладчик ФБС ----------
  const FBS = [[2380, "24"], [1180, "12"], [880, "9"]];
  function fbsCombo(S, j, prefix) {
    const pre = prefix && S > 1180 + j ? 1 : 0;
    const S2 = S - (pre ? 1180 + j : 0);
    let best = null;
    for (let n12 = 0; n12 <= 2; n12++) for (let n9 = 0; n9 <= 3; n9++) {
      const base = n12 * (1180 + j) + n9 * (880 + j);
      if (base > S2 + j) continue;
      const n24 = Math.max(0, Math.floor((S2 - base + j) / (2380 + j)));
      const cnt = n24 + n12 + n9;
      const used = n24 * (2380 + j) + base - (cnt ? j : 0);
      const r = S2 - used, mono = r > 2 * j ? r - j : 0;
      const score = (mono > 0 && mono < 150 ? 1e5 : 0) + mono * 10 + cnt;
      if (!best || score < best.score) best = { score, n24, n12, n9, mono, pre };
    }
    return best;
  }
  function fbsOrders(c) {
    const P = (len, t) => ({ len, t });
    const big = Array.from({ length: c.n24 }, () => P(2380, "24"));
    const small = [...Array.from({ length: c.n12 }, () => P(1180, "12")), ...Array.from({ length: c.n9 }, () => P(880, "9"))];
    const hb = Math.ceil(big.length / 2), hs = Math.ceil(small.length / 2);
    const bases = [big.concat(small), small.concat(big), small.slice(0, hs).concat(big, small.slice(hs)), big.slice(0, hb).concat(small, big.slice(hb)), small.slice().reverse().concat(big)];
    const out = [];
    bases.forEach(b => {
      if (!c.mono) { out.push(b); return; }
      const pos = [...new Set([Math.floor(b.length / 2), 1, Math.max(0, b.length - 1), 0, b.length])];
      pos.forEach(p => { const x = b.slice(); x.splice(Math.min(p, x.length), 0, P(c.mono, "M")); out.push(x); });
    });
    return out.map(o => (c.pre ? [P(1180, "12")] : []).concat(o));
  }
  const fbsJoints = (row, j) => { const xs = []; let x = row.start; row.pcs.forEach((p, i) => { x += p.len; if (i < row.pcs.length - 1) xs.push(x + j / 2); x += j; }); return xs; };
  function fbsRow(len, start, j, prefix, prev) {
    const c = fbsCombo(len, j, prefix);
    const pj = prev ? fbsJoints(prev, j) : [];
    let best = null;
    fbsOrders(c).forEach((pcs, i) => {
      const row = { start, len, pcs };
      const weak = prev ? fbsJoints(row, j).filter(x => pj.some(y => Math.abs(y - x) < 240)).length : 0;
      if (!best || weak < best.weak) best = { weak, row };
    });
    return best.row;
  }
  function fbsSVG(title, wallLen, rows, t, j) {
    const W = 860, rowH = 34, pL = 46, pR = 10, pT = 8, n = rows.length, H = pT + n * rowH + 26;
    const k = (W - pL - pR) / wallLen;
    let s = '<svg viewBox="0 0 ' + W + " " + H + '" class="fbs-svg" role="img" aria-label="' + esc(title) + '">';
    rows.forEach((row, ri) => {
      const y = pT + (n - 1 - ri) * rowH;
      s += '<text x="' + (pL - 8) + '" y="' + (y + rowH / 2 + 3) + '" class="axis" text-anchor="end">ряд ' + (ri + 1) + "</text>";
      if (row.start > 0) s += '<rect x="' + pL + '" y="' + (y + 2) + '" width="' + (row.start * k) + '" height="' + (rowH - 4) + '" class="fb-corner"/>';
      const endStart = row.start + row.len;
      if (endStart < wallLen) s += '<rect x="' + (pL + endStart * k) + '" y="' + (y + 2) + '" width="' + ((wallLen - endStart) * k) + '" height="' + (rowH - 4) + '" class="fb-corner"/>';
      let x = row.start;
      row.pcs.forEach(p => {
        const px = pL + x * k, pw = Math.max(1, p.len * k);
        s += '<rect x="' + px + '" y="' + (y + 2) + '" width="' + pw + '" height="' + (rowH - 4) + '" rx="2" class="fb-' + p.t + '"><title>' + (p.t === "M" ? "Монолитный добор " + p.len + " мм" : "ФБС " + p.t + "." + t / 100 + ".6") + "</title></rect>";
        if (pw > 22) s += '<text x="' + (px + pw / 2) + '" y="' + (y + rowH / 2 + 4) + '" class="fb-l" text-anchor="middle">' + (p.t === "M" ? (pw > 46 ? "М " + p.len : "М") : p.t) + "</text>";
        x += p.len + j;
      });
    });
    const yb = pT + n * rowH + 16;
    s += '<line x1="' + pL + '" x2="' + (W - pR) + '" y1="' + (yb - 8) + '" y2="' + (yb - 8) + '" class="dim"/><text x="' + (pL + (W - pL - pR) / 2) + '" y="' + yb + '" class="axis" text-anchor="middle">' + nint(wallLen) + " мм</text>";
    return s + "</svg>";
  }
  add({
    id: "fbs", cat: "found", mark: "чертёж рядов", name: "Раскладка блоков ФБС", kw: "фбс блоки фундаментные раскладка схема ряды перевязка фл плиты ленточные подвал сборный фундамент 24.4.6 12.4.6 9.4.6",
    desc: "Схема каждого ряда с перевязкой, спецификация ФБС 24/12/9, доборы, масса и плиты ФЛ",
    inputs: [
      { k: "L", label: "Длина фундамента по наружным граням, мм", def: 10000 },
      { k: "B", label: "Ширина по наружным граням, мм", def: 8000 },
      { k: "t", label: "Ширина блока", type: "sel", def: "400", opts: [["300", "300 мм (ФБС ..3.6)"], ["400", "400 мм (ФБС ..4.6)"], ["500", "500 мм (ФБС ..5.6)"], ["600", "600 мм (ФБС ..6.6)"]] },
      { k: "rows", label: "Рядов (по 600 мм)", def: 4 },
      { k: "j", label: "Вертикальный шов, мм", def: 20 },
      { k: "inner", label: "Внутренняя стена поперёк дома", type: "check", def: true },
      { k: "fl", label: "Ленточные плиты ФЛ под блоки", type: "sel", def: "12", opts: [["0", "Нет (монолитная подушка)"], ["8", "ФЛ 8 (800 мм)"], ["10", "ФЛ 10 (1000 мм)"], ["12", "ФЛ 12 (1200 мм)"], ["14", "ФЛ 14 (1400 мм)"], ["16", "ФЛ 16 (1600 мм)"], ["20", "ФЛ 20 (2000 мм)"]] }
    ],
    run(v) {
      const t = +v.t, j = Math.max(0, v.j), L = v.L, B = v.B, R = Math.max(1, Math.min(12, Math.round(v.rows)));
      if (L < 2 * t + 1000 || B < 2 * t + 1000) return { warn: "Слишком маленькие размеры." };
      const A = [], Bw = [], I = [];
      for (let r = 0; r < R; r++) {
        const odd = r % 2 === 0;
        A.push(odd ? fbsRow(L, 0, j, false, A[r - 1]) : fbsRow(L - 2 * t - 2 * j, t + j, j, false, A[r - 1]));
        Bw.push(odd ? fbsRow(B - 2 * t - 2 * j, t + j, j, false, Bw[r - 1]) : fbsRow(B, 0, j, false, Bw[r - 1]));
        if (v.inner) I.push(fbsRow(B - 2 * t - 2 * j, t + j, j, r % 2 === 1, I[r - 1]));
      }
      // перевязка: соседние ряды — расстояние между вертикальными швами
      const joints = row => fbsJoints(row, j);
      let weak = 0;
      [A, Bw, I].forEach(rs => { for (let r = 1; r < rs.length; r++) { const a = joints(rs[r - 1]), b = joints(rs[r]); b.forEach(x => { if (a.some(y => Math.abs(y - x) < 240)) weak++; }); } });
      const cnt = { "24": 0, "12": 0, "9": 0 }; let monoN = 0, monoL = 0;
      const tally = (rs, mult) => rs.forEach(row => row.pcs.forEach(p => { if (p.t === "M") { monoN += mult; monoL += p.len * mult; } else cnt[p.t] += mult; }));
      tally(A, 2); tally(Bw, 2); tally(I, 1);
      const w = t / 100, massOne = { "24": 2.38, "12": 1.18, "9": 0.88 };
      const mass = Object.keys(cnt).reduce((s, k) => s + cnt[k] * massOne[k] * t / 1000 * 0.58 * 2.4 * 0.98, 0);
      const monoV = monoL / 1000 * t / 1000 * 0.58;
      const wallLenRow = 2 * L + 2 * (B - 2 * t) + (v.inner ? B - 2 * t : 0);
      const mortar = wallLenRow / 1000 * t / 1000 * 0.02 * R * 1.15;
      const items = [["ФБС 24." + w + ".6", cnt["24"], "шт."], ["ФБС 12." + w + ".6", cnt["12"], "шт."], ["ФБС 9." + w + ".6", cnt["9"], "шт."]].filter(i => i[1] > 0);
      if (monoV > 0) items.push(["Бетон B15 на монолитные доборы", Math.round(monoV * 1.05 * 100) / 100, "м³"]);
      items.push(["Раствор М100 для швов", Math.round(mortar * 100) / 100, "м³"]);
      const extra = [];
      if (v.fl !== "0") {
        const flW = +v.fl * 100, flLen = 2 * L + 2 * (B - 2 * flW) + (v.inner ? B - 2 * flW : 0);
        const n24 = Math.floor(flLen / 2380), rem = flLen - n24 * 2380, n12 = rem >= 1180 ? 1 : 0;
        const flH = +v.fl >= 20 ? 500 : 300;
        items.push(["Плита ФЛ " + v.fl + ".24", n24, "шт."]); if (n12) items.push(["Плита ФЛ " + v.fl + ".12", n12, "шт."]);
        extra.push(["Плиты ФЛ " + v.fl + " (" + flW + "×" + flH + ")", n24 + " × 24 + " + n12 + " × 12, остаток " + nint(rem - n12 * 1180) + " мм — монолитом или разрывом"]);
      }
      const leg = '<div class="legend fb-leg"><span class="legend-item"><span class="sw fb-24"></span>ФБС 24</span><span class="legend-item"><span class="sw fb-12"></span>ФБС 12</span><span class="legend-item"><span class="sw fb-9"></span>ФБС 9</span><span class="legend-item"><span class="sw fb-M"></span>монолит</span><span class="legend-item"><span class="sw fb-corner"></span>блок поперечной стены</span></div>';
      const blocks = [
        { title: "Продольные стены (2 шт.) · " + nint(L) + " мм", aside: leg, html: '<div class="chart-scroll">' + fbsSVG("Продольная стена", L, A, t, j) + "</div>" },
        { title: "Торцевые стены (2 шт.) · " + nint(B) + " мм", html: '<div class="chart-scroll">' + fbsSVG("Торцевая стена", B, Bw, t, j) + "</div>" }
      ];
      if (v.inner) blocks.push({ title: "Внутренняя стена (1 шт.) · " + nint(B - 2 * t - 2 * j) + " мм между наружными", html: '<div class="chart-scroll">' + fbsSVG("Внутренняя стена", B, I, t, j) + '</div><p class="hint">Внутренняя стена примыкает к наружным — в местах примыкания уложите в шов арматурную сетку или Г-образные стержни.</p>' });
      return {
        stats: [S("ФБС 24 / 12 / 9", cnt["24"] + " / " + cnt["12"] + " / " + cnt["9"], "шт.", "", true), S("Монолитные доборы", nint(monoN), "шт.", nf(monoV, 2) + " м³ бетона"), S("Масса блоков", nf(mass, 1), "т", "≈ " + ceil(mass / 10) + " рейсов манипулятора по 10 т"), S("Высота стены", nint(R * 600), "мм", R + " рядов по 580 + шов 20"), S("Слабая перевязка", nint(weak), "мест", weak ? "сдвиг швов < 240 мм" : "перевязка в норме")],
        warn: weak > 0 ? "В " + weak + " местах вертикальные швы соседних рядов ближе 240 мм (0,4 высоты блока). Положите в эти швы арматурную сетку или поменяйте местами блоки в ряду." : "",
        blocks, table: { head: ["Позиция", "Количество"], rows: items.map(i => [i[0], (typeof i[1] === "number" ? i[1].toLocaleString("ru-RU") : i[1]) + " " + i[2]]) }, extra: extra.length ? extra : undefined,
        items
      };
    },
    info: "Углы перевязываются чередованием: в нечётных рядах продольные стены идут на всю длину, а торцевые встают между ними; в чётных — наоборот. Внутренняя стена в чётных рядах начинается с ФБС 12 для перевязки. Доборы из монолита ставятся в середину ряда — там удобно оставить проём для ввода коммуникаций или продуха. Рядность по высоте — 600 мм (блок 580 + шов 20)."
  });
