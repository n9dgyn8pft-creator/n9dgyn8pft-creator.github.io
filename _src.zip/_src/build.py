b=open('base.html').read()
a=open('app.js').read()
m='  // ====================================================================\n  //  UI: sidebar'
parts=[open(f).read() for f in ['found.js','land.js','green.js','glass.js','learn.js','learn2.js']]
a=a.replace(m, '\n'.join(parts)+'\n'+m)
s=b+a
open('body.html','w').write(s)
open('beton.html','w').write('<!doctype html>\n<html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">\n</head><body>\n'+s+'\n</body></html>\n')
