  // ====================================================================
  //  БЛАГОУСТРОЙСТВО И СЕТИ
  // ====================================================================
  // kind: unit (м²), bulk (насыпной, kc — уплотнение, rho т/м³), conc, cps, xps, asph, sheet
  const MAT = {
    tile: { kind: "unit", cls: "m-tile", name: "Тротуарная плитка" },
    cps: { kind: "cps", cls: "m-cps", name: "ЦПС (сухая смесь)" },
    sand: { kind: "bulk", cls: "m-sand", rho: 1.5, kc: 1.2, name: "Песок" },
    gravel: { kind: "bulk", cls: "m-gravel", rho: 1.37, kc: 1.3, name: "Щебень 20–40" },
    gravelB: { kind: "bulk", cls: "m-gravel", rho: 1.38, kc: 1.3, name: "Щебень 40–70" },
    deco: { kind: "bulk", cls: "m-deco", rho: 1.37, kc: 1.15, name: "Щебень 5–20" },
    soil: { kind: "bulk", cls: "m-soil", rho: 1.2, kc: 1.2, name: "Растительный грунт" },
    conc: { kind: "conc", cls: "m-conc", name: "Бетон" },
    xps: { kind: "xps", cls: "m-xps", name: "ЭППС" },
    asph: { kind: "asph", cls: "m-asph", name: "Асфальтобетон" },
    geo: { kind: "sheet", cls: "m-geo", name: "Геотекстиль" },
    memb: { kind: "sheet", cls: "m-memb", name: "Профилированная мембрана" },
    lawn: { kind: "unit", cls: "m-lawn", name: "Газон" }
  };
  const PIES = {
    walk: ["Пешеходная дорожка из плитки", [["tile", "Тротуарная плитка 60 мм", 60], ["cps", "ЦПС 1:5", 40], ["sand", "Песок", 100], ["gravel", "Щебень 20–40", 150], ["geo", "Геотекстиль", 0]]],
    car: ["Площадка под легковой автомобиль", [["tile", "Тротуарная плитка 80 мм", 80], ["cps", "ЦПС 1:4", 40], ["gravel", "Щебень 20–40", 200], ["sand", "Песок", 150], ["geo", "Геотекстиль", 0]]],
    truck: ["Въезд для грузовой техники", [["tile", "Плитка 80 мм", 80], ["cps", "ЦПС 1:4", 40], ["conc", "Бетон B20 с сеткой", 150], ["gravel", "Щебень 20–40", 200], ["sand", "Песок", 200], ["geo", "Геотекстиль", 0]]],
    asphalt: ["Асфальтовый проезд", [["asph", "Асфальтобетон", 50], ["gravelB", "Щебень 40–70", 200], ["sand", "Песок", 200], ["geo", "Геотекстиль", 0]]],
    gravel: ["Щебёночная площадка или дорожка", [["deco", "Щебень 5–20, верхний слой", 50], ["gravel", "Щебень 20–40", 150], ["sand", "Песок", 100], ["geo", "Геотекстиль", 0]]],
    otm: ["Отмостка бетонная утеплённая", [["conc", "Бетон B15 с сеткой", 100], ["xps", "ЭППС", 50], ["sand", "Песок", 150], ["memb", "Мембрана / геомембрана", 0]]],
    lawn: ["Газон", [["lawn", "Рулонный или посевной газон", 20], ["soil", "Растительный грунт", 150], ["sand", "Песок дренажный", 100], ["geo", "Геотекстиль", 0]]]
  };
  function pieSVG(layers) {
    const W = 640, x0 = 20, wB = 330, labX = x0 + wB + 18, pT = 12;
    const vis = layers.map(l => ({ ...l, hh: l.kind === "sheet" ? 4 : Math.max(16, l.t * 0.55) }));
    const H = pT + vis.reduce((s, l) => s + l.hh, 0) + 30;
    let y = pT, s = '<svg viewBox="0 0 ' + W + " " + H + '" class="pie-svg" role="img" aria-label="Разрез пирога"><defs>' +
      '<pattern id="p-sand" width="8" height="8" patternUnits="userSpaceOnUse"><rect width="8" height="8" class="pf-sand"/><circle cx="2" cy="2" r=".9" class="pd"/><circle cx="6" cy="5" r=".7" class="pd"/></pattern>' +
      '<pattern id="p-gravel" width="16" height="12" patternUnits="userSpaceOnUse"><rect width="16" height="12" class="pf-gravel"/><ellipse cx="4" cy="4" rx="3" ry="2.2" class="pg"/><ellipse cx="12" cy="9" rx="3.4" ry="2.4" class="pg"/></pattern>' +
      '<pattern id="p-deco" width="8" height="8" patternUnits="userSpaceOnUse"><rect width="8" height="8" class="pf-deco"/><circle cx="2" cy="3" r="1.6" class="pg"/><circle cx="6" cy="6" r="1.4" class="pg"/></pattern>' +
      '<pattern id="p-soil" width="10" height="10" patternUnits="userSpaceOnUse"><rect width="10" height="10" class="pf-soil"/><path d="M1 8 L4 5 M6 9 L9 6" class="ps"/></pattern>' +
      '<pattern id="p-conc" width="12" height="12" patternUnits="userSpaceOnUse"><rect width="12" height="12" class="pf-conc"/><path d="M2 3 l2 2 M8 8 l2 -1" class="ps"/></pattern>' +
      '<pattern id="p-xps" width="10" height="10" patternUnits="userSpaceOnUse"><rect width="10" height="10" class="pf-xps"/><path d="M0 10 L10 0" class="ps"/></pattern>' +
      '<pattern id="p-tile" width="40" height="20" patternUnits="userSpaceOnUse"><rect width="40" height="20" class="pf-tile"/><path d="M0 0 H40 M20 0 V20" class="pt"/></pattern>' +
      '<pattern id="p-lawn" width="6" height="10" patternUnits="userSpaceOnUse"><rect width="6" height="10" class="pf-lawn"/><path d="M3 10 L2 2 M3 10 L5 3" class="pl"/></pattern></defs>';
    const fill = { unit: null, cps: "url(#p-sand)", bulk: null, conc: "url(#p-conc)", xps: "url(#p-xps)", asph: "var(--ink-2)", sheet: null };
    vis.forEach(l => {
      let f = fill[l.kind];
      if (l.m === "tile") f = "url(#p-tile)"; if (l.m === "lawn") f = "url(#p-lawn)";
      if (l.kind === "bulk") f = l.m === "sand" ? "url(#p-sand)" : l.m === "soil" ? "url(#p-soil)" : l.m === "deco" ? "url(#p-deco)" : "url(#p-gravel)";
      if (l.kind === "sheet") s += '<line x1="' + x0 + '" x2="' + (x0 + wB) + '" y1="' + (y + 2) + '" y2="' + (y + 2) + '" class="p-sheet"/>';
      else s += '<rect x="' + x0 + '" y="' + y + '" width="' + wB + '" height="' + l.hh + '" fill="' + f + '" class="p-lay"/>' + (l.m === "conc" && /сетк/.test(l.label) ? '<line x1="' + (x0 + 6) + '" x2="' + (x0 + wB - 6) + '" y1="' + (y + l.hh * 0.45) + '" y2="' + (y + l.hh * 0.45) + '" class="p-mesh"/>' : "");
      s += '<line x1="' + (x0 + wB + 4) + '" x2="' + (labX - 4) + '" y1="' + (y + l.hh / 2) + '" y2="' + (y + l.hh / 2) + '" class="dim"/><text x="' + labX + '" y="' + (y + l.hh / 2 + 4) + '" class="p-lab">' + esc(l.label) + (l.kind === "sheet" ? "" : " — " + l.t + " мм") + "</text>";
      y += l.hh;
    });
    s += '<rect x="' + x0 + '" y="' + y + '" width="' + wB + '" height="14" fill="url(#p-soil)" opacity=".55"/><text x="' + labX + '" y="' + (y + 11) + '" class="axis">уплотнённое основание</text>';
    return s + "</svg>";
  }
  const pieInputs = [
    { k: "type", label: "Покрытие", type: "sel", def: "walk", opts: Object.entries(PIES).map(([k, p]) => [k, p[0]]) },
    { k: "A", label: "Площадь, м²", def: 40 },
    { k: "edge", label: "Длина бордюров, м", def: 30 },
    { k: "ek", label: "Бордюр", type: "sel", def: "garden", opts: [["garden", "Садовый 1000×200×80"], ["road", "Дорожный 1000×300×150"], ["none", "Без бордюра"]] }
  ];
  for (let i = 0; i < 6; i++) pieInputs.push({
    k: "t" + i, dep: "type",
    label: v => { const l = PIES[v.type][1][i]; return l ? l[1].replace(/ \d+ мм$/, "") + ", мм" : ""; },
    def: v => { const l = PIES[v.type][1][i]; return l ? l[2] : 0; },
    show: v => { const l = PIES[v.type][1][i]; return !!l && MAT[l[0]].kind !== "sheet"; }
  });
  add({
    id: "pie", cat: "land", mark: "разрез + материалы", name: "Пироги дорожек и площадок", kw: "пирог дорожка площадка плитка парковка отмостка газон асфальт щебень бордюр геотекстиль благоустройство мощение основание",
    desc: "Типовые пироги с разрезом: объём каждого слоя, выемка грунта, бордюры — всё в смету",
    inputs: pieInputs,
    run(v) {
      const P = PIES[v.type], A = v.A;
      const layers = P[1].map((l, i) => ({ m: l[0], label: l[1], t: MAT[l[0]].kind === "sheet" ? 0 : Math.max(0, v["t" + i]), kind: MAT[l[0]].kind }));
      const rows = [], items = [];
      let depth = 0;
      layers.forEach(l => {
        const M = MAT[l.m], V = A * l.t / 1000; depth += l.t;
        if (l.kind === "unit") { if (l.m === "lawn") { rows.push([l.label, nf(A * 1.05, 1) + " м²", "рулонов 0,8 м² ≈ " + nint(ceil(A * 1.05 / 0.8)) + " или семян " + nf(A * 0.04, 1) + " кг"]); items.push(["Газон рулонный", ceil(A * 1.05 / 0.8), "рул."]); } else { rows.push([l.label, nf(A * 1.05, 1) + " м²", "+5% на подрезку"]); items.push([l.label, Math.round(A * 1.05 * 10) / 10, "м²"]); } }
        else if (l.kind === "bulk") { const Vl = V * M.kc, T = Vl * M.rho; rows.push([l.label + " " + l.t + " мм", nf(Vl, 2) + " м³", nf(T, 1) + " т (уплотнение ×" + nf(M.kc, 2) + ")"]); items.push([l.label, Math.round(T * 10) / 10, "т"]); }
        else if (l.kind === "cps") { const Vl = V * 1.25, ratio = /1:4/.test(l.label) ? 4 : 5, cem = Vl / (ratio + 1) * 1.3 * 1000 / 1.1, sand = Vl * ratio / (ratio + 1) * 1.1; rows.push([l.label + " " + l.t + " мм", nf(Vl, 2) + " м³", "цемент " + nint(cem) + " кг · песок " + nf(sand, 2) + " м³"]); items.push(["Цемент ПЦ М500, 50 кг", ceil(cem / 50), "меш."], ["Песок для ЦПС", Math.round(sand * 100) / 100, "м³"]); }
        else if (l.kind === "conc") { rows.push([l.label + " " + l.t + " мм", nf(V * 1.03, 2) + " м³", /сетк/.test(l.label) ? "сетка ВР 5 100×100: " + nf(A * 1.1, 0) + " м²" : ""]); items.push([l.label.replace(" с сеткой", ""), Math.round(V * 1.03 * 100) / 100, "м³"]); if (/сетк/.test(l.label)) items.push(["Сетка кладочная ВР 5, 100×100", Math.round(A * 1.1), "м²"]); }
        else if (l.kind === "xps") { rows.push([l.label + " " + l.t + " мм", nf(A * 1.05, 1) + " м²", nf(V, 2) + " м³"]); items.push(["ЭППС " + l.t + " мм", Math.round(A * 1.05 * 10) / 10, "м²"]); }
        else if (l.kind === "asph") { const T = V * 2.35; rows.push([l.label + " " + l.t + " мм", nf(T, 1) + " т", "≈ " + nf(V, 2) + " м³ в плотном теле"]); items.push(["Асфальтобетонная смесь", Math.round(T * 10) / 10, "т"]); }
        else { rows.push([l.label, nf(A * 1.15, 1) + " м²", "с нахлёстом 15%"]); items.push([l.label, Math.round(A * 1.15), "м²"]); }
      });
      const exc = A * depth / 1000, loose = exc * 1.25;
      if (v.ek !== "none" && v.edge > 0) { const road = v.ek === "road"; const n = ceil(v.edge * 1.02); const c = v.edge * (road ? 0.06 : 0.03); rows.push([road ? "Бордюр дорожный 1000×300×150" : "Бордюр садовый 1000×200×80", nint(n) + " шт.", "бетон на замок ≈ " + nf(c, 2) + " м³"]); items.push([road ? "Бордюр дорожный 1000×300×150" : "Бордюр садовый 1000×200×80", n, "шт."], ["Бетон B15 под бордюр", Math.round(c * 100) / 100, "м³"]); }
      return {
        stats: [S("Толщина пирога", nint(depth), "мм"), S("Выемка грунта", nf(exc, 1), "м³", "вывоз ≈ " + nf(loose, 1) + " м³ в разрыхлении"), S("Площадь", nf(A, 1), "м²"), S("Позиций материалов", nint(items.length), "", "кнопка «+ В смету» сверху", true)],
        blocks: [{ title: "Разрез: " + P[0], html: '<div class="chart-scroll">' + pieSVG(layers) + "</div>" }],
        table: { head: ["Слой", "Количество", "Примечание"], rows }, items
      };
    },
    info: "Пироги — типовые для средней полосы на непучинистом или осушенном основании. Насыпные слои: объём к закупке = площадь × толщина × коэффициент уплотнения (песок 1,2, щебень 1,3). На глинах и при высоких водах добавьте дренаж и увеличьте песчаный слой; под проезд грузовой техники основание считается по нагрузке."
  });

  // ---------- Септик ----------
  add({
    id: "septic", cat: "land", name: "Септик из колец", kw: "септик канализация кольца кс жб выгребная яма автономная станция очистки объем отстойник фильтрующий колодец",
    desc: "Объём по СП 32, число камер и колец, плиты днища и перекрытия",
    inputs: [
      { k: "n", label: "Проживает человек", def: 4 },
      { k: "q", label: "Расход на человека, л/сут", def: 200, hint: "С ванной и стиралкой — 200, без ванны — 150" },
      { k: "d", label: "Кольца", type: "sel", def: "1.5", opts: [["1", "КС 10.9 (Ø 1,0 м)"], ["1.5", "КС 15.9 (Ø 1,5 м)"], ["2", "КС 20.9 (Ø 2,0 м)"]] },
      { k: "ch", label: "Камер-отстойников", type: "sel", def: "2", opts: [["1", "1"], ["2", "2"], ["3", "3"]] },
      { k: "inlet", label: "Глубина ввода трубы, м", def: 1.2, hint: "Лоток трубы на входе в септик" },
      { k: "filt", label: "Последним — фильтрующий колодец", type: "check", def: true }
    ],
    run(v) {
      const Q = v.n * v.q / 1000, V = Q <= 5 ? 3 * Q : 2.5 * Q;
      const d = num(v.d), area = Math.PI * d * d / 4, nc = +v.ch;
      const share = nc === 1 ? [1] : nc === 2 ? [0.75, 0.25] : [0.5, 0.25, 0.25];
      const ringCode = { 1: "КС 10.9", 1.5: "КС 15.9", 2: "КС 20.9" }[d];
      const rows = [];
      const h = Math.max(1, V * share[0] / area); // глубина жидкости по первой камере, остальные — такой же высоты
      const r1 = Math.max(2, ceil((v.inlet + h + 0.05) / 0.9));
      let rings = 0, Vact = 0;
      share.forEach((s, i) => {
        const r = i === 0 ? r1 : Math.max(2, r1 - 1);
        const hh = i === 0 ? h : Math.max(0.6, h - 0.9 + 0.05 * i);
        rings += r; Vact += area * hh;
        rows.push(["Камера " + (i + 1), nf(area * hh, 2) + " м³", nf(hh, 2) + " м жидкости", nint(r) + " колец " + ringCode]);
      });
      let filtR = 0;
      if (v.filt) { filtR = Math.max(2, ceil((v.inlet + 1.2) / 0.9)); rows.push(["Фильтрующий колодец", "—", "дно — щебень 0,5 м", nint(filtR) + " колец " + ringCode + " (перфорированных)"]); }
      const wells = nc + (v.filt ? 1 : 0);
      const items = [["Кольцо " + ringCode, rings + filtR, "шт."], ["Плита днища ПН " + Math.round(d * 10), nc, "шт."], ["Плита перекрытия с люком 1ПП " + Math.round(d * 10), wells, "шт."], ["Люк полимерный", wells, "шт."], ["Труба ПВХ 110 для переливов", 6 * wells, "м"]];
      if (v.filt) items.push(["Щебень 20–40 на дно фильтрующего колодца", Math.round(area * 0.5 * 1.37 * 10) / 10, "т"]);
      return {
        stats: [S("Суточный приток", nf(Q, 2), "м³/сут"), S("Объём септика по СП 32", nf(V, 2), "м³", Q <= 5 ? "трёхсуточный приток" : "2,5-кратный приток", true), S("Колец всего", nint(rings + filtR), "шт.", ringCode + " · рабочий объём " + nf(Vact, 1) + " м³"), S("Колодцев", nint(wells), "шт.")],
        table: { head: ["Камера", "Объём", "Слой жидкости", "Колец"], rows },
        warn: v.filt ? "Фильтрующий колодец работает только на песках и супесях при уровне вод ниже дна на 1 м и более. На глине и при высоких водах нужна станция биоочистки или поле фильтрации с дренажом." : "",
        items
      };
    },
    info: "СП 32.13330: полный объём септика при притоке до 5 м³/сут — не менее трёхсуточного, свыше — 2,5-суточного. В двухкамерном первая камера — 75% объёма, в трёхкамерном — 50%. Расстояния: от дома не менее 5 м, от колодца или скважины — не менее 50 м (по СанПиН зависит от грунта)."
  });

  // ---------- Дренаж ----------
  add({
    id: "drain", cat: "land", name: "Дренаж вокруг дома", kw: "дренаж кольцевой пристенный труба дренажная геотекстиль щебень колодцы уклон грунтовые воды водоотвод",
    desc: "Длина трубы, уклон и перепад, щебень, геотекстиль, колодцы, объём траншеи",
    inputs: [
      { k: "L", label: "Длина дома, м", def: 10 }, { k: "B", label: "Ширина дома, м", def: 9 },
      { k: "off", label: "Отступ от стены, м", def: 1, hint: "Кольцевой дренаж — 1–3 м от фундамента" },
      { k: "sole", label: "Глубина подошвы фундамента, м", def: 1.5 },
      { k: "sl", label: "Уклон, %", def: 0.5, hint: "Не менее 0,2% в глинах и 0,3% в песках, удобно 0,5–1%" },
      { k: "gw", label: "Ширина траншеи по дну, м", def: 0.4 },
      { k: "gh", label: "Высота щебёночной обсыпки, м", def: 0.4 },
      { k: "out", label: "Отвод до сборного колодца, м", def: 8 }
    ],
    run(v) {
      const Lr = 2 * (v.L + 2 * v.off + v.B + 2 * v.off);
      const pipe = (Lr + v.out) * 1.05;
      const half = Lr / 2, fall = half * v.sl / 100;
      const top = v.sole + 0.3, bot = top + fall;
      const avgD = (top + bot) / 2 + 0.1;
      const trench = Lr * (v.gw + 0.3) * avgD + v.out * 0.6 * bot;
      const grav = Lr * v.gw * v.gh - Lr * 0.0095;
      const geo = Lr * (2 * (v.gw + v.gh) + 0.3);
      const wells = 4 + Math.floor(Lr / 25) + 1;
      return {
        stats: [S("Труба дренажная Ø110", nf(pipe, 0), "м", "в геотекстиле, с запасом 5%"), S("Перепад по кольцу", nint(fall * 1000), "мм", "от верхней точки до сборного колодца"), S("Глубина лотка", nf(top, 2) + "–" + nf(bot, 2), "м", "на 0,3 м ниже подошвы"), S("Щебень 20–40", nf(grav * 1.37 * 1.1, 1), "т", nf(grav, 1) + " м³"), S("Колодцев", nint(wells), "шт.", "на углах + сборный")],
        table: { head: ["Позиция", "Количество"], rows: [["Длина кольца по оси трубы", nf(Lr, 1) + " м"], ["Геотекстиль 200 г/м² (обёртка щебня)", nf(geo, 0) + " м²"], ["Объём траншеи", nf(trench, 1) + " м³"], ["Песок для обратной засыпки (≈ 60% траншеи)", nf(trench * 0.6, 1) + " м³"]] },
        items: [["Труба дренажная ПНД 110 в геотекстиле", Math.round(pipe), "м"], ["Щебень гранитный 20–40", Math.round(grav * 1.37 * 1.1 * 10) / 10, "т"], ["Геотекстиль 200 г/м²", Math.round(geo), "м²"], ["Колодец дренажный Ø315", wells - 1, "шт."], ["Колодец сборный Ø400–630", 1, "шт."]]
      };
    },
    info: "Две ветки кольца сходятся к сборному колодцу в нижней точке участка — поэтому перепад считается на половину длины кольца. Ревизионные колодцы — на углах и через каждые 25 м. Сборный колодец откачивается насосом или имеет перелив в канаву."
  });
