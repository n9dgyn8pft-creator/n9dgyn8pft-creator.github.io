import os, sys
sys.path.insert(0,'.')
from marks import FAVICON
from playwright.sync_api import sync_playwright
F=os.path.abspath('site_assets/fonts')
mark_dark='<svg viewBox="0 0 120 120" width="300" height="300"><g fill="#ECEEEE"><rect x="32" y="88" width="78" height="22"/><rect x="88" y="58" width="22" height="52"/><rect x="58" y="58" width="52" height="20"/></g><g fill="#3BB3C4"><rect x="10" y="10" width="22" height="22"/><rect x="36" y="10" width="22" height="22"/><rect x="62" y="10" width="22" height="22"/><rect x="10" y="36" width="22" height="22"/><rect x="10" y="62" width="22" height="22"/><rect x="10" y="88" width="22" height="22"/><circle cx="99" cy="21" r="10"/></g></svg>'
og=f'''<html><head><style>
@font-face{{font-family:M;font-weight:800;src:url(file://{F}/montserrat-latin-800-normal.woff2)}}
@font-face{{font-family:M;font-weight:500;src:url(file://{F}/montserrat-cyrillic-500-normal.woff2)}}
body{{margin:0;width:1200px;height:630px;background:#1E2226;display:flex;align-items:center;gap:72px;padding:0 120px;box-sizing:border-box;font-family:M}}
.n{{color:#ECEEEE;font-weight:800;font-size:110px;letter-spacing:.12em}} .s{{color:#9AA1A6;font-weight:500;font-size:40px;margin-top:6px}}
</style></head><body>{mark_dark}<div><div class="n">SPUTNIK</div><div class="s">помощник строителя</div></div></body></html>'''
with sync_playwright() as pw:
    b=pw.chromium.launch()
    open('og_tmp.html','w').write(og); p=b.new_page(viewport={'width':1200,'height':630}); p.goto('file://'+os.path.abspath('og_tmp.html')); p.wait_for_timeout(600); p.screenshot(path='site/assets/og.png')
    p=b.new_page(viewport={'width':180,'height':180}); p.set_content('<html><body style="margin:0;background:transparent">'+FAVICON.replace('<svg ','<svg width="180" height="180" ')+'</body></html>'); p.screenshot(path='site/apple-touch-icon.png', omit_background=True)
    p=b.new_page(viewport={'width':32,'height':32}); p.set_content('<html><body style="margin:0">'+FAVICON.replace('<svg ','<svg width="32" height="32" ')+'</body></html>'); p.screenshot(path='site/favicon-32.png', omit_background=True)
    b.close()
from PIL import Image
Image.open('site/favicon-32.png').save('site/favicon.ico', sizes=[(32,32)]); os.remove('site/favicon-32.png')
print('ok')
