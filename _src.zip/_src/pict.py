# -*- coding: utf-8 -*-
# Пиктограммы калькуляторов SPUTNIK: сетка 32×32, линия 1.6, графит + бирюзовый акцент. Без градиентов и теней.
L = 'class="l"'   # линия графитом
A = 'class="a"'   # линия акцентом
F = 'class="f"'   # заливка акцентом
I = {
 "strength": f'<path {L} d="M5 26h16V12H5z"/><path {L} d="M5 12l4-4h16l-4 4M21 26l4-4V8"/><path {A} d="M27 9v11"/><circle {F} cx="27" cy="23" r="2.4"/>',
 "volume": f'<path {L} d="M6 24V12l10-5 10 5v12l-10 5z"/><path {L} d="M6 12l10 5 10-5M16 17v12"/><path {A} d="M3 14v9M29 14v9"/>',
 "mix": f'<path {L} d="M8 10h16l-2 17H10z"/><path {L} d="M8 10c0-3 16-3 16 0"/><path {A} d="M12 16h8M11.5 21h9"/>',
 "rebar": f'<path {L} d="M6 10h20M6 16h20M6 22h20"/><path {A} d="M10 6v20M16 6v20M22 6v20"/>',
 "brick": f'<path {L} d="M4 8h24v16H4zM4 13.3h24M4 18.6h24M12 8v5.3M20 8v5.3M8 13.3v5.3M16 13.3v5.3M24 13.3v5.3M12 18.6V24M20 18.6V24"/><path {A} d="M4 27h24"/>',
 "block": f'<path {L} d="M4 9h24v15H4zM4 16.5h24M14 9v7.5M10 16.5V24M22 16.5V24"/><path {A} d="M4 27h24"/>',
 "lintel": f'<path {L} d="M4 6v22M28 6v22M4 6h24"/><path {F} d="M6 11h20v3.5H6z"/><path {L} d="M9 14.5V28M23 14.5V28"/>',
 "slabs": f'<path {L} d="M3 12h26v8H3z"/><circle {A} cx="8" cy="16" r="1.8"/><circle {A} cx="13.3" cy="16" r="1.8"/><circle {A} cx="18.6" cy="16" r="1.8"/><circle {A} cx="24" cy="16" r="1.8"/><path {L} d="M5 20v7M27 20v7"/>',
 "roof": f'<path {L} d="M3 18L16 6l13 12"/><path {A} d="M9 12.5v10M16 6v16.5M23 12.5v10"/><path {L} d="M6 22.5h20"/>',
 "stairs": f'<path {L} d="M4 27h6v-5h6v-5h6v-5h6"/><path {A} d="M4 23L26 8"/>',
 "lumber": f'<rect {L} x="4" y="9" width="10" height="6"/><rect {L} x="4" y="17" width="10" height="6"/><rect {L} x="16" y="17" width="10" height="6"/><path {A} d="M18 9h10v6H18z"/>',
 "plaster": f'<path {L} d="M5 5v22"/><path {A} d="M9 5v22"/><path {L} d="M14 12h12l-2 6H14zM20 18v8"/>',
 "screed": f'<path {L} d="M3 24h26M3 20h26"/><path {A} d="M3 14h26" stroke-dasharray="3 2"/><path {L} d="M8 14v6M24 14v6"/>',
 "tile": f'<path {L} d="M5 5h10v10H5zM17 5h10v10H17zM5 17h10v10H5z"/><path {F} d="M17 17h10v10H17z"/>',
 "wallpaper": f'<path {L} d="M6 6h14v20H6z"/><path {A} d="M20 6a3 3 0 0 1 0 6"/><path {L} d="M20 12h6v14"/><path {A} d="M10 11h6M10 16h6M10 21h6"/>',
 "paint": f'<path {L} d="M6 6h18v6H6zM24 9h3v6h-11v4"/><path {F} d="M14 19h4v8h-4z"/>',
 "floor": f'<path {L} d="M4 8h24v16H4z"/><path {A} d="M4 13.3h24M4 18.6h24"/><path {L} d="M14 8v5.3M9 13.3v5.3M20 13.3v5.3M16 18.6V24"/>',
 "gkl": f'<path {L} d="M5 5h22v22H5z"/><path {A} d="M11 5v22M16 5v22M21 5v22"/>',
 "insul": f'<path {L} d="M6 5v22M26 5v22"/><path {A} d="M10 7l4 3-4 3 4 3-4 3 4 3-4 3M18 7l4 3-4 3 4 3-4 3 4 3-4 3"/>',
 "glazing": f'<path {L} d="M4 5h24M4 27h24"/><path {L} d="M6 7h9v18H6zM17 7h9v18h-9z"/><path {A} d="M8.5 13l4-4M19.5 13l4-4M8.5 17l2-2"/>',
 "pie": f'<path {F} d="M4 8h24v3H4z"/><path {L} d="M4 11h24v5H4zM4 16h24v5H4z"/><path {A} d="M4 24h24" stroke-dasharray="3 2"/>',
 "septic": f'<ellipse {L} cx="11" cy="9" rx="6" ry="2"/><path {L} d="M5 9v15c0 1 2.7 2 6 2s6-1 6-2V9"/><path {A} d="M17 14h6M23 14v-2M5 17h12"/><ellipse {L} cx="25" cy="11" rx="3" ry="1"/><path {L} d="M22 11v12c0 .6 1.3 1 3 1s3-.4 3-1V11"/>',
 "drain": f'<path {L} d="M4 6v16h10"/><path {A} d="M18 22h10" stroke-width="3"/><circle {L} cx="21" cy="26" r=".9"/><circle {L} cx="25" cy="26" r=".9"/><circle {L} cx="23" cy="18.5" r=".9"/><path {L} d="M14 22h4"/>',
 "plants": f'<path {L} d="M16 28V16"/><path {A} d="M16 18c-6 0-9-4-9-8a9 9 0 0 1 18 0c0 4-3 8-9 8z"/><path {L} d="M10 28h12"/>',
 "planting": f'<path {L} d="M4 22h24"/><path {L} d="M11 22c0 3 2 5 5 5s5-2 5-5"/><path {A} d="M16 22V10M16 14c-3 0-5-2-5-5 3 0 5 2 5 5zM16 12c3 0 5-2 5-5-3 0-5 2-5 5z"/>',
 "border": f'<path {L} d="M3 27h26M8 27v-9M16 27V12M24 27v-7"/><circle {F} cx="8" cy="16" r="2.6"/><circle {A} cx="16" cy="9.5" r="3"/><circle {F} cx="24" cy="18" r="2.2"/>',
 "beam": f'<path {L} d="M3 18h26v4H3zM5 22l-2 5h4zM27 22l-2 5h4z"/><path {A} d="M9 6v8M16 6v8M23 6v8M7 12l2 2 2-2M14 12l2 2 2-2M21 12l2 2 2-2"/>',
 "slope": f'<path {L} d="M4 26h24V10z"/><path {A} d="M10 26a6 6 0 0 0-.6-3"/>',
 "metal": f'<path {L} d="M8 6h16M8 26h16M16 6v20"/><path {A} d="M8 6v3M24 6v3M8 26v-3M24 26v-3"/>',
 "bulk": f'<path {L} d="M3 26c3-9 7-14 13-14s10 5 13 14z"/><circle {F} cx="12" cy="21" r="1.3"/><circle {F} cx="18" cy="19" r="1.3"/><circle {F} cx="21" cy="23" r="1.3"/><circle {F} cx="15" cy="24" r="1.3"/>',
 "concref": f'<path {L} d="M6 5h20v22H6z"/><path {L} d="M6 11h20M6 17h20M6 22h20M13 5v22"/><path {A} d="M8.5 8h2"/>',
 "vent": f'<path {L} d="M4 16L16 6l12 10M7 14v13h18V14"/><path {L} d="M21 6h4v8"/><path {A} d="M23 13V2M21 4l2-2 2 2M11 22c2-2 4 2 6 0"/>',
 "fselect": f'<path {L} d="M6 15L16 7l10 8v6H6z"/><path {F} d="M4 21h24v3H4z"/><path {A} d="M8 24v4M16 24v4M24 24v4"/>',
 "frost": f'<path {L} d="M3 12h26"/><path {A} d="M16 3v6M13.4 4.5l5.2 3M18.6 4.5l-5.2 3"/><path {L} d="M3 12v15h26V12"/><path {A} d="M3 20h26" stroke-dasharray="3 2"/>',
 "loads": f'<path {L} d="M6 18l10-8 10 8v8H6z"/><path {A} d="M10 3v5M16 2v5M22 3v5M8.5 6.5 10 8l1.5-1.5M14.5 5.5 16 7l1.5-1.5M20.5 6.5 22 8l1.5-1.5"/><path {L} d="M4 28h24"/>',
 "fbs": f'<path {L} d="M3 9h12v5H3zM17 9h12v5H17zM3 16h7v5H3zM12 16h12v5H12zM26 16h3v5h-3zM3 23h12v5H3zM17 23h12v5H17z"/><path {F} d="M26 16h3v5h-3z"/>',
 "earth": f'<path {L} d="M2 10h7l4 14h6l4-14h7"/><path {A} d="M13 24h6" stroke-width="2.4"/><path {L} d="M4 14l2 0M26 14h2"/>',
 "ventguide": f'<path {L} d="M4 6h10c1.5 0 2 1 2 2v19c0-1-.5-2-2-2H4zM28 6H18c-1.5 0-2 1-2 2v19c0-1 .5-2 2-2h10z"/><path {A} d="M22 21V11M20 13l2-2 2 2"/>',
 "slabguide": f'<path {L} d="M4 6h10c1.5 0 2 1 2 2v19c0-1-.5-2-2-2H4zM28 6H18c-1.5 0-2 1-2 2v19c0-1 .5-2 2-2h10z"/><path {A} d="M19 14h7v4h-7z"/>',
 "estimate": f'<path {L} d="M7 4h14l4 4v20H7z"/><path {A} d="M11 12h10M11 17h10M11 22h6"/>',
}
CAT_ICON = {"found": "fselect", "struct": "brick", "finish": "plaster", "glass": "glazing", "land": "pie", "green": "plants", "tech": "beam", "learn": "ventguide"}

def icon(cid, size=32, cls="pict"):
    body = I.get(cid, I["estimate"])
    return '<svg class="%s" viewBox="0 0 32 32" width="%d" height="%d" aria-hidden="true" focusable="false">%s</svg>' % (cls, size, size, body)

PICT_CSS = """
  .pict { flex: 0 0 auto; display: block; }
  .pict .l { fill: none; stroke: var(--ink); stroke-width: 1.6; stroke-linecap: round; stroke-linejoin: round; }
  .pict .a { fill: none; stroke: var(--accent); stroke-width: 1.6; stroke-linecap: round; stroke-linejoin: round; }
  .pict .f { fill: var(--accent); stroke: none; }
  .ccard .pict { width: 44px; height: 44px; margin-bottom: 4px; }
  .ccard-top { display: flex; justify-content: space-between; align-items: flex-start; gap: 8px; }
  .head-ic { display: flex; gap: 16px; align-items: flex-start; }
  .head-ic .pict { width: 48px; height: 48px; padding: 8px; box-sizing: content-box; border: 1px solid var(--line); border-radius: 10px; background: var(--surface); }
  @media (max-width: 560px) { .head-ic .pict { width: 36px; height: 36px; padding: 6px; } }
  .hero-ill { width: 100%; height: auto; display: block; }
  .hero-ill .hl { fill: none; stroke: var(--ink); stroke-width: 2; stroke-linejoin: round; stroke-linecap: round; }
  .hero-ill .hm { fill: none; stroke: var(--muted); stroke-width: 1.2; }
  .hero-ill .ha { fill: none; stroke: var(--accent); stroke-width: 2; stroke-linecap: round; stroke-linejoin: round; }
  .hero-ill .hf { fill: var(--accent); }
  .hero-ill .hg { fill: color-mix(in srgb, var(--accent) 14%, var(--surface)); stroke: var(--accent); stroke-width: 1.4; }
  .hero-ill .hs { fill: var(--line); }
  .hero-ill .hb { fill: var(--surface); stroke: var(--ink); stroke-width: 1.6; }
  .hero-ill a text { font: 600 11px var(--font-body); letter-spacing: .14em; text-transform: uppercase; fill: var(--ink); }
  .hero-ill a:hover text { fill: var(--accent); }
  .hero-ill a .dot { fill: var(--accent); }
  .hero-ill a .ld { stroke: var(--muted); stroke-width: 1; stroke-dasharray: 2 3; }
"""

def hero_svg(links):
    """Схема дома в разрезе с подписями-ссылками на разделы. links: {cat: href}"""
    def lab(cat, x, y, tx, ty, text, anchor="start"):
        return ('<a href="%s"><line class="ld" x1="%d" y1="%d" x2="%d" y2="%d"/><circle class="dot" cx="%d" cy="%d" r="4"/>'
                '<text x="%d" y="%d" text-anchor="%s">%s</text></a>') % (links[cat], x, y, tx, ty, x, y, tx + (6 if anchor == "start" else -6), ty + 4, anchor, text)
    s = ['<svg class="hero-ill" viewBox="0 0 880 340" role="img" aria-label="Схема дома: разделы калькуляторов">']
    # грунт и благоустройство
    s.append('<rect class="hs" x="0" y="250" width="880" height="90" opacity=".45"/>')
    s.append('<path class="hm" d="M0 250H880"/>')
    s.append('<path class="hm" d="M0 292H880" stroke-dasharray="6 5"/>')
    # фундамент ФБС
    for i, (x, w) in enumerate([(300, 70), (372, 70), (444, 70), (516, 70)]):
        s.append('<rect class="hb" x="%d" y="256" width="%d" height="16"/>' % (x, w))
    for x in (300, 336, 408, 480, 552):
        s.append('<rect class="hb" x="%d" y="274" width="%d" height="16"/>' % (x, 34 if x in (300, 552) else 70))
    # стены и перекрытие
    s.append('<path class="hl" d="M300 252V140M586 252V140"/>')
    s.append('<rect class="hb" x="296" y="134" width="294" height="10"/>')
    for x in range(306, 586, 24):
        s.append('<circle class="hm" cx="%d" cy="139" r="2.4"/>' % (x + 8))
    # остекление
    s.append('<rect class="hg" x="360" y="160" width="90" height="88"/><rect class="hg" x="452" y="160" width="90" height="88"/>')
    s.append('<path class="ha" d="M374 186l18-18M466 186l18-18M374 200l8-8"/>')
    # кровля
    s.append('<path class="hl" d="M276 140L443 52l167 88"/>')
    s.append('<path class="ha" d="M340 106v34M392 79v61M443 52v88M494 79v61M546 106v34"/>')
    # вентканал
    s.append('<rect class="hb" x="520" y="60" width="18" height="74"/><path class="ha" d="M529 56V30M523 36l6-6 6 6"/>')
    # дерево и дорожка
    s.append('<path class="hl" d="M150 250V200"/><circle class="hg" cx="150" cy="176" r="34"/><circle class="hg" cx="128" cy="196" r="20"/><circle class="hg" cx="174" cy="194" r="22"/>')
    s.append('<rect class="hf" x="180" y="246" width="110" height="6" rx="1"/><path class="hm" d="M180 254h110"/>')
    s.append('<path class="hl" d="M640 250v-22h50v22M640 228l25-18 25 18"/>')
    # подписи
    s.append(lab("glass", 405, 205, 405, 18, "Остекление"))
    s.append(lab("struct", 443, 90, 650, 76, "Конструктив"))
    s.append(lab("finish", 586, 200, 680, 160, "Отделка"))
    s.append(lab("tech", 529, 44, 640, 26, "Технические расчёты"))
    s.append(lab("found", 443, 282, 640, 318, "Участок и фундамент"))
    s.append(lab("land", 235, 249, 40, 310, "Благоустройство и сети"))
    s.append(lab("green", 150, 160, 40, 110, "Озеленение"))
    s.append("</svg>")
    return "".join(s)
