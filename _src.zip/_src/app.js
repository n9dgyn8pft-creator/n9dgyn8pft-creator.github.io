<script>
(function () {
  "use strict";
  const $ = id => document.getElementById(id);
  const num = v => { if (typeof v === "number") return v; const x = parseFloat(String(v == null ? "" : v).replace(/\s/g, "").replace(",", ".").replace("−", "-")); return isNaN(x) ? 0 : x; };
  const nf = (x, d = 2) => (isFinite(x) ? x : 0).toLocaleString("ru-RU", { minimumFractionDigits: d, maximumFractionDigits: d }).replace("-", "−");
  const nint = x => Math.round(isFinite(x) ? x : 0).toLocaleString("ru-RU");
  const ceil = x => Math.ceil(x - 1e-9);
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const store = {
    get(k) { try { return JSON.parse(localStorage.getItem("beton:" + k)); } catch (e) { return null; } },
    set(k, v) { try { localStorage.setItem("beton:" + k, JSON.stringify(v)); } catch (e) {} }
  };
  const norm = s => String(s).toLowerCase().replace(/ё/g, "е");
  // ---------- theme ----------
  function applyTheme(t) {
    if (t === "light" || t === "dark") document.documentElement.setAttribute("data-theme", t);
    else document.documentElement.removeAttribute("data-theme");
    document.querySelectorAll(".theme button").forEach(b => b.classList.toggle("on", b.dataset.t === t));
    store.set("theme", t);
  }
  document.querySelectorAll(".theme button").forEach(b => b.onclick = () => applyTheme(b.dataset.t));
  applyTheme(store.get("theme") || "auto");

  const S = (label, value, unit, sub, accent) => ({ label, value, unit, sub, accent });
  const deg = r => r * 180 / Math.PI, rad = d => d * Math.PI / 180;

  // ====================================================================
  //  CALCULATORS
  // ====================================================================
  const CATS = [["found", "Участок и фундамент"], ["struct", "Конструктив"], ["finish", "Отделка"], ["glass", "Остекление"], ["land", "Благоустройство и сети"], ["green", "Озеленение"], ["tech", "Технические расчёты"], ["learn", "Обучение"]];
  const CALCS = [];
  const add = c => CALCS.push(c);

  // ---------- legacy (already on the page) ----------
  add({ id: "strength", cat: "struct", legacy: true, mark: "по погоде", name: "Набор прочности бетона", kw: "прочность твердение распалубка опалубка погода температура зима мороз r28 созревание", desc: "Когда бетон наберёт 50, 70 и 100% — по реальной погоде в вашем городе" });
  add({ id: "volume", cat: "struct", legacy: true, name: "Объём бетона и миксеры", kw: "куб кубатура фундамент лента плита ростверк сваи столбы миксер бетон заказ", desc: "Кубы с запасом по элементам, сколько миксеров заказать" });
  add({ id: "mix", cat: "struct", legacy: true, name: "Состав бетона", kw: "пропорции цемент песок щебень вода замес бетономешалка ведра марка класс", desc: "Цемент, песок, щебень, вода по классу; в вёдрах и на замес" });
  add({ id: "rebar", cat: "struct", legacy: true, name: "Арматура плиты и ленты", kw: "арматура каркас сетка хомуты вязка проволока хлысты металл", desc: "Метры, хлысты и тонны по диаметрам, вязальная проволока" });
  add({ id: "brick", cat: "struct", legacy: true, name: "Кирпич и раствор", kw: "кирпич кладка стена раствор поддон силикатный керамический полуторный столб", desc: "Кирпич, поддоны, раствор, цемент и песок для кладки" });

  // ---------- Газобетон ----------
  add({
    id: "block", cat: "struct", name: "Газобетон и блоки", kw: "газобетон газоблок пеноблок блоки клей кладка армирование стена d500 d400 керамзитоблок",
    desc: "Блоки в штуках и кубах, поддоны, клей и армирование рядов",
    inputs: [
      { k: "L", label: "Длина стен, м", def: 40, hint: "Сумма всех стен по оси" },
      { k: "H", label: "Высота стен, м", def: 3 },
      { k: "o", label: "Проёмы, м²", def: 12, hint: "Окна + двери" },
      { k: "bl", label: "Длина блока, мм", def: 600 },
      { k: "bh", label: "Высота блока, мм", def: 250 },
      { k: "t", label: "Толщина стены, мм", type: "sel", def: "300", opts: [["100", "100"], ["150", "150"], ["200", "200"], ["250", "250"], ["300", "300"], ["375", "375"], ["400", "400"], ["500", "500"]] },
      { k: "pal", label: "Объём поддона, м³", def: 1.8, hint: "Уточните у поставщика" },
      { k: "glue", label: "Расход клея, кг/м³", def: 25, hint: "Шов 2–3 мм: 20–30 кг на м³" },
      { k: "every", label: "Армировать каждый N-й ряд", def: 4 },
      { k: "res", label: "Запас, %", def: 5 }
    ],
    run(v) {
      const area = Math.max(0, v.L * v.H - v.o), V = area * v.t / 1000, r = 1 + v.res / 100;
      const blockFace = (v.bl / 1000) * (v.bh / 1000);
      const n = blockFace > 0 ? ceil(area / blockFace * r) : 0;
      const Vr = V * r, pal = v.pal > 0 ? ceil(Vr / v.pal) : 0;
      const glue = V * v.glue, bags = ceil(glue / 25);
      const rows = v.bh > 0 ? Math.floor(v.H * 1000 / v.bh) : 0;
      const armRows = v.every > 0 && rows > 0 ? Math.floor((rows - 1) / v.every) + 1 : 0;
      const rebar = armRows * v.L * 2 * 1.05;
      return {
        stats: [S("Площадь кладки", nf(area, 1), "м²"), S("Блоков с запасом", nint(n), "шт.", nf(Vr, 2) + " м³", true), S("Поддонов", nint(pal), "шт."), S("Клей", nint(bags), "меш. 25 кг", "≈ " + nint(glue) + " кг")],
        table: { head: ["Позиция", "Значение"], rows: [["Рядов кладки", nint(rows)], ["Армируемых рядов (первый + каждый " + v.every + "-й)", nint(armRows)], ["Арматура Ø8 в штробы (2 прутка)", nf(rebar, 0) + " м · " + nf(rebar * 0.395, 0) + " кг"]] },
        items: [["Блок " + v.bl + "×" + v.bh + "×" + v.t, n, "шт."], ["Клей для блоков, мешок 25 кг", bags, "меш."], ["Арматура Ø8 А500", Math.round(rebar), "м"]]
      };
    },
    info: "Первый ряд кладётся на цементно-песчаный раствор — его клей не учитывает. Армопояс и перемычки считайте отдельно в «Объёме бетона» и «Арматуре»."
  });

  // ---------- Кровля ----------
  add({
    id: "roof", cat: "struct", name: "Двускатная кровля и стропила", kw: "кровля крыша стропила конек скат угол обрешетка металлочерепица профнастил мягкая черепица площадь",
    desc: "Высота конька, длина стропил, площадь кровли, обрешётка и покрытие",
    inputs: [
      { k: "B", label: "Ширина дома (пролёт), м", def: 8 },
      { k: "L", label: "Длина дома, м", def: 10 },
      { k: "mode", label: "Задать", type: "sel", def: "a", opts: [["a", "угол ската"], ["h", "высоту конька"]] },
      { k: "a", label: "Угол ската, °", def: 30, show: v => v.mode === "a" },
      { k: "h", label: "Высота конька над стенами, м", def: 2.3, show: v => v.mode === "h" },
      { k: "ov", label: "Свес по карнизу, м", def: 0.5, hint: "По горизонтали" },
      { k: "go", label: "Свес по фронтону, м", def: 0.3 },
      { k: "step", label: "Шаг стропил, мм", def: 600 },
      { k: "sb", label: "Сечение стропил: ширина, мм", def: 50 },
      { k: "sh", label: "Сечение стропил: высота, мм", def: 200 },
      { k: "bs", label: "Шаг обрешётки, мм", def: 350 },
      { k: "mat", label: "Покрытие", type: "sel", def: "mt", opts: [["mt", "Металлочерепица (+10%)"], ["pn", "Профнастил (+10%)"], ["soft", "Гибкая черепица (+15%, уп. 3 м²)"], ["falc", "Фальц (+7%)"]] }
    ],
    run(v) {
      const half = v.B / 2;
      let a = v.mode === "a" ? v.a : deg(Math.atan2(v.h, half));
      a = Math.min(Math.max(a, 1), 75);
      const h = half * Math.tan(rad(a));
      const slopeMain = half / Math.cos(rad(a));
      const slope = (half + v.ov) / Math.cos(rad(a));
      const roofL = v.L + 2 * v.go;
      const area = 2 * slope * roofL;
      const pairs = v.step > 0 ? ceil(v.L / (v.step / 1000)) + 1 : 0;
      const raf = pairs * 2, rafV = raf * slope * v.sb / 1000 * v.sh / 1000;
      const bRows = v.bs > 0 ? ceil(slope / (v.bs / 1000)) + 1 : 0, batten = bRows * 2 * roofL * 1.05;
      const kMat = { mt: 1.1, pn: 1.1, soft: 1.15, falc: 1.07 }[v.mat];
      const buy = area * kMat;
      const warn = [];
      if (v.mat === "mt" && a < 14) warn.push("Металлочерепицу обычно кладут при уклоне от 14°.");
      if (v.mat === "soft" && a < 12) warn.push("Гибкую черепицу обычно кладут при уклоне от 12° (с ковром — по инструкции производителя).");
      if (v.mat === "pn" && a < 8) warn.push("Профнастил при уклоне менее 8° требует герметизации нахлёстов.");
      const items = [["Стропила " + v.sb + "×" + v.sh + ", длина " + nf(slope, 2) + " м", raf, "шт."], ["Обрешётка", Math.round(batten), "м"]];
      if (v.mat === "soft") items.push(["Гибкая черепица, упаковка 3 м²", ceil(buy / 3), "уп."]); else items.push([{ mt: "Металлочерепица", pn: "Профнастил кровельный", falc: "Фальцевая кровля" }[v.mat], Math.round(buy * 10) / 10, "м²"]);
      items.push(["Коньковый элемент", Math.round(roofL * 1.05 * 10) / 10, "м"]);
      return {
        stats: [S("Угол / высота конька", nf(a, 1) + "° · " + nf(h, 2), "м"), S("Длина стропила со свесом", nf(slope, 2), "м", "без свеса " + nf(slopeMain, 2) + " м"), S("Площадь кровли", nf(area, 1), "м²", "к покупке ≈ " + nf(buy, 1) + " м²", true), S("Стропил", nint(raf), "шт.", nf(rafV, 2) + " м³ доски")],
        table: { head: ["Позиция", "Значение"], rows: [["Уклон", nf(Math.tan(rad(a)) * 100, 0) + "%"], ["Пар стропил", nint(pairs)], ["Рядов обрешётки на скат", nint(bRows)], ["Обрешётка (с запасом 5%)", nf(batten, 0) + " м"], ["Длина конька", nf(roofL, 2) + " м"], ["Карнизные свесы (2 стороны)", nf(roofL * 2, 1) + " м"], ["Фронтонные свесы (4 шт.)", nf(slope * 4, 1) + " м"]] },
        warn: warn.join(" "), items
      };
    },
    info: "Сечение стропил здесь не подбирается по прочности — его определяет снеговой район, пролёт и шаг. Для проверки воспользуйтесь калькулятором «Деревянная балка»."
  });

  // ---------- Лестница ----------
  add({
    id: "stairs", cat: "struct", mark: "проём + разметка", name: "Лестница прямая", kw: "лестница ступени подступенок проступь косоур тетива блондель проем перекрытие угол марш",
    desc: "Ступени по формуле удобства, угол, косоур, размер проёма и разметка",
    inputs: [
      { k: "H", label: "Высота от пола до пола, мм", def: 2900, hint: "Чистовой пол 1-го до чистового пола 2-го этажа" },
      { k: "hr", label: "Желаемая высота ступени, мм", def: 175, hint: "Удобно 150–190" },
      { k: "run", label: "Длина в плане, мм (0 — подобрать)", def: 0, hint: "Если место ограничено" },
      { k: "t", label: "Толщина перекрытия, мм", def: 250 },
      { k: "head", label: "Высота прохода, мм", def: 2000 },
      { k: "w", label: "Ширина марша, мм", def: 900 }
    ],
    run(v) {
      const n = Math.max(2, Math.round(v.H / Math.max(100, v.hr)));
      const h = v.H / n, treads = n - 1;
      const b = v.run > 0 ? v.run / treads : Math.min(320, Math.max(220, 630 - 2 * h));
      const run = b * treads, ang = deg(Math.atan2(h, b)), blond = 2 * h + b;
      const str = Math.hypot(run, v.H - h); // косоур от пола до верхней проступи
      const x0 = (v.H - v.t - v.head) * b / h; // где начинается проём
      const open = Math.max(0, run - x0);
      const warn = [];
      if (blond < 600 || blond > 650) warn.push("2h + b = " + nint(blond) + " мм — вне удобного диапазона 600–650 мм.");
      if (ang > 45) warn.push("Угол " + nf(ang, 0) + "° — крутая лестница, удобно 30–40°.");
      if (b < 250) warn.push("Проступь меньше 250 мм — стопа помещается не полностью.");
      const rows = [];
      for (let i = 1; i <= n; i++) rows.push([String(i), nint(h * i), i < n ? nint(b * (i - 1)) + "–" + nint(b * i) : "этаж", i < n ? "ступень" : "пол 2-го этажа"]);
      return {
        stats: [S("Подъёмов", nint(n), "шт.", "ступеней (проступей): " + treads), S("Высота ступени h", nf(h, 1), "мм"), S("Проступь b", nint(b), "мм", "2h + b = " + nint(blond) + " мм", true), S("Угол / длина в плане", nf(ang, 1) + "° · " + nf(run / 1000, 2), "м"), S("Проём в перекрытии, длина", "≥ " + nint(open), "мм", "косоур ≈ " + nf(str / 1000, 2) + " м")],
        table: { cap: "Разметка: высота каждой проступи от чистого пола и её положение по горизонтали от первой ступени", head: ["№", "Высота, мм", "По горизонтали, мм", ""], rows },
        extra: [["Длина косоура (по линии ступеней)", nf(str / 1000, 2) + " м"], ["Минимальная длина проёма в перекрытии", nint(open) + " мм"], ["Ширина проёма", "≥ " + nint(v.w + 100) + " мм"]],
        warn: warn.join(" "),
        items: [["Ступени (проступи) " + nint(b + 30) + "×" + nint(v.w), treads, "шт."], ["Косоур / тетива ≈ " + nf(str / 1000, 2) + " м", 2, "шт."]]
      };
    },
    info: "Формула Блонделя: 2h + b = 600–650 мм (шаг человека). Последний подъём выходит на пол второго этажа, поэтому проступей на одну меньше, чем подъёмов. Проём рассчитан так, чтобы над любой ступенью оставалась заданная высота прохода. Проступь к закупке — с нависанием 30 мм."
  });

  // ---------- Пиломатериал ----------
  add({
    id: "lumber", cat: "struct", name: "Пиломатериал: штуки ↔ кубы", kw: "доска брус куб кубометр штук в кубе пиломатериал лес цена вагонка",
    desc: "Сколько досок в кубе, объём партии и цена за штуку",
    inputs: [
      { k: "b", label: "Толщина, мм", def: 50 }, { k: "h", label: "Ширина, мм", def: 150 }, { k: "l", label: "Длина, м", def: 6 },
      { k: "mode", label: "Известно", type: "sel", def: "n", opts: [["n", "количество штук"], ["v", "объём, м³"]] },
      { k: "n", label: "Количество, шт.", def: 40, show: v => v.mode === "n" },
      { k: "v", label: "Объём, м³", def: 2, show: v => v.mode === "v" },
      { k: "price", label: "Цена за м³, ₽", def: 0, hint: "Необязательно" }
    ],
    run(v) {
      const one = v.b / 1000 * v.h / 1000 * v.l, perM3 = one > 0 ? 1 / one : 0;
      const n = v.mode === "n" ? v.n : Math.floor(v.v * perM3 + 1e-9);
      const V = n * one;
      const st = [S("Объём одной", nf(one, 4), "м³"), S("Штук в 1 м³", nf(perM3, 1), "шт."), S(v.mode === "n" ? "Объём партии" : "Штук в " + nf(v.v, 2) + " м³", v.mode === "n" ? nf(V, 3) : nint(n), v.mode === "n" ? "м³" : "шт.", v.mode === "n" ? "" : "= " + nf(V, 3) + " м³", true),
        S("Погонаж / площадь", nint(n * v.l), "м", "покрывает " + nf(n * v.l * v.h / 1000, 1) + " м²")];
      if (v.price > 0) st.push(S("Цена", nint(v.price * one), "₽/шт.", "партия " + nint(v.price * V) + " ₽"));
      return { stats: st, items: [["Пиломатериал " + v.b + "×" + v.h + "×" + nf(v.l, 1) + " м", n, "шт."]] };
    }
  });

  // ---------- Деревянная балка ----------
  add({
    id: "beam", cat: "tech", mark: "прочность + прогиб", name: "Деревянная балка перекрытия", kw: "балка лага перекрытие прогиб пролет сечение доска брус нагрузка несущая способность стропило",
    desc: "Проверка сечения по прочности и прогибу, подбор высоты",
    inputs: [
      { k: "L", label: "Пролёт в свету, м", def: 4.5 },
      { k: "s", label: "Шаг балок, мм", def: 600 },
      { k: "b", label: "Ширина сечения, мм", def: 50 },
      { k: "h", label: "Высота сечения, мм", def: 200 },
      { k: "use", label: "Назначение", type: "sel", def: "1.5", opts: [["1.5", "Жилое помещение (1,5 кПа)"], ["0.7", "Неэксплуатируемый чердак (0,7 кПа)"], ["2", "Терраса, балкон (2,0 кПа)"], ["3", "Офис, мастерская (3,0 кПа)"]] },
      { k: "g", label: "Собственный вес пола и потолка, кПа", def: 1.0, hint: "≈ 1 кПа = 100 кг/м² (утеплитель, полы, подшивка)" },
      { k: "R", label: "Древесина", type: "sel", def: "13", opts: [["14", "Сосна/ель 1 сорт"], ["13", "Сосна/ель 2 сорт"], ["8.5", "Сосна/ель 3 сорт"]] },
      { k: "lim", label: "Допустимый прогиб", type: "sel", def: "250", opts: [["200", "L/200"], ["250", "L/250"], ["300", "L/300 (под плитку)"]] }
    ],
    run(v) {
      const s = v.s / 1000, p = num(v.use), R = num(v.R), E = 10000;
      const qn = (v.g + p) * s, qd = (v.g * 1.1 + p * 1.3) * s; // кН/м
      const check = (b, h) => {
        const W = b * h * h / 6, I = b * h ** 3 / 12; // мм3, мм4
        const M = qd * v.L * v.L / 8 * 1e6; // Н·мм
        const sig = M / W;
        const f = 5 * qn * (v.L * 1000) ** 4 / (384 * E * I); // qn кН/м = Н/мм
        const fl = v.L * 1000 / num(v.lim);
        return { sig, f, fl, ks: sig / R, kf: f / fl };
      };
      const c = check(v.b, v.h);
      let hmin = null;
      for (let h = 100; h <= 400; h += 25) { const t = check(v.b, h); if (t.ks <= 1 && t.kf <= 1) { hmin = h; break; } }
      const ok = c.ks <= 1 && c.kf <= 1;
      return {
        stats: [S("Прочность", nint(c.ks * 100), "%", "σ = " + nf(c.sig, 1) + " из " + nf(R, 1) + " МПа", c.ks <= 1), S("Прогиб", nf(c.f, 1), "мм", "допустимо " + nf(c.fl, 1) + " мм · " + nint(c.kf * 100) + "%", c.kf <= 1), S("Вывод", ok ? "проходит" : "не проходит", ""), S("Мин. высота при b = " + v.b, hmin ? String(hmin) : "> 400", "мм")],
        warn: ok ? "" : "Сечение " + v.b + "×" + v.h + " не проходит" + (c.ks > 1 ? " по прочности" : "") + (c.kf > 1 ? (c.ks > 1 ? " и" : "") + " по прогибу" : "") + ". Увеличьте высоту, уменьшите шаг или поставьте опору.",
        table: { head: ["Параметр", "Значение"], rows: [["Нормативная погонная нагрузка", nf(qn, 2) + " кН/м (" + nint(qn * 100) + " кг/м)"], ["Расчётная погонная нагрузка", nf(qd, 2) + " кН/м"], ["Изгибающий момент", nf(qd * v.L * v.L / 8, 2) + " кН·м"]] }
      };
    },
    info: "Шарнирно опёртая балка, равномерная нагрузка. Коэффициенты надёжности: 1,1 для собственного веса и 1,3 для полезной нагрузки. Модуль упругости древесины 10 000 МПа, расчётное сопротивление изгибу — по сорту (СП 64.13330, без коэффициентов условий работы). Не учитываются сосредоточенные нагрузки (перегородки, ванна, печь), ослабления и влажная древесина. Для ответственных случаев — расчёт конструктора."
  });

  // ---------- Штукатурка ----------
  add({
    id: "plaster", cat: "finish", mark: "по замерам", name: "Штукатурка стен", kw: "штукатурка ротбанд гипсовая цементная маяки слой выравнивание стен смесь мешки",
    desc: "Средний слой по замерам отклонений, мешки смеси и маяки",
    inputs: [
      { k: "A", label: "Площадь стен, м²", def: 40 },
      { k: "H", label: "Высота стен, м", def: 2.7 },
      { k: "mode", label: "Толщина слоя", type: "sel", def: "avg", opts: [["avg", "знаю средний слой"], ["meas", "по замерам отклонений"]] },
      { k: "t", label: "Средний слой, мм", def: 15, show: v => v.mode === "avg" },
      { k: "m", label: "Замеры от шнура/правила до стены, мм", type: "list", def: "20 35 12 28 40 18 25", show: v => v.mode === "meas", hint: "Через пробел. Чем больше точек — тем точнее" },
      { k: "tmin", label: "Минимальный слой над выступом, мм", def: 6, show: v => v.mode === "meas", hint: "С учётом маяка 6 мм" },
      { k: "mix", label: "Смесь", type: "sel", def: "g", opts: [["g", "Гипсовая (≈ 8,5 кг/м²·мм, мешок 30 кг)"], ["c", "Цементная (≈ 17 кг/м²·мм, мешок 25 кг)"], ["ci", "Цементно-известковая (≈ 15 кг/м²·мм, мешок 25 кг)"]] },
      { k: "res", label: "Запас, %", def: 5 }
    ],
    run(v) {
      let t = v.t, extra = [];
      if (v.mode === "meas") {
        const m = v.m;
        if (!m.length) return { warn: "Введите замеры." };
        const mn = Math.min(...m), mx = Math.max(...m), avg = m.reduce((s, x) => s + x, 0) / m.length;
        t = avg - mn + v.tmin;
        extra = [["Замеров", nint(m.length)], ["Перепад стены", nint(mx - mn) + " мм"], ["Слой в самой глубокой точке", nint(mx - mn + v.tmin) + " мм"]];
      }
      const [rate, bag] = { g: [8.5, 30], c: [17, 25], ci: [15, 25] }[v.mix];
      const kg = v.A * t * rate * (1 + v.res / 100), bags = ceil(kg / bag);
      const beac = v.H > 0 ? ceil(v.A / v.H / 1.5) + 1 : 0, beacPcs = beac * ceil(v.H / 3);
      const warn = t > 50 ? "Слой больше 50 мм — нужна армирующая сетка или выравнивание в два захода, либо ГКЛ." : "";
      return {
        stats: [S("Средний слой", nf(t, 1), "мм"), S("Смеси", nint(kg), "кг", "", false), S("Мешков", nint(bags), "шт.", "по " + bag + " кг", true), S("Маяков по 3 м", nint(beacPcs), "шт.", "шаг ≈ 1,5 м")],
        table: extra.length ? { head: ["Параметр", "Значение"], rows: extra } : null, warn,
        items: [[{ g: "Штукатурка гипсовая", c: "Штукатурка цементная", ci: "Штукатурка цементно-известковая" }[v.mix] + ", мешок " + bag + " кг", bags, "меш."], ["Маяк штукатурный 6 мм, 3 м", beacPcs, "шт."]]
      };
    },
    info: "Как мерить: натяните шнур или приложите длинное правило, выставленное по отвесу, и замерьте расстояние до стены в 6–15 точках. Слой в каждой точке = замер − минимальный замер + минимальный слой. Средний слой умножается на площадь и расход смеси на 1 мм."
  });

  // ---------- Стяжка ----------
  add({
    id: "screed", cat: "finish", mark: "по замерам", name: "Стяжка пола", kw: "стяжка пол цпс пескобетон м150 полусухая фибра демпферная лента высыхание уровень нивелир толщина",
    desc: "Толщина по замерам нивелира, смесь, фибра, лента и время высыхания",
    inputs: [
      { k: "A", label: "Площадь пола, м²", def: 20 },
      { k: "P", label: "Периметр помещения, м", def: 18 },
      { k: "mode", label: "Толщина", type: "sel", def: "avg", opts: [["avg", "знаю среднюю толщину"], ["meas", "по замерам нивелира"]] },
      { k: "t", label: "Средняя толщина, мм", def: 50, show: v => v.mode === "avg" },
      { k: "m", label: "Замеры от линии лазера до пола, мм", type: "list", def: "1012 1025 1031 1018 1040 1022", show: v => v.mode === "meas", hint: "Чем больше число — тем ниже пол в этой точке" },
      { k: "tmin", label: "Минимальная толщина, мм", def: 30, show: v => v.mode === "meas", hint: "Над самой высокой точкой" },
      { k: "mix", label: "Материал", type: "sel", def: "dry", opts: [["dry", "Готовая смесь (пескобетон/ЦПС), ≈ 2 кг/м²·мм"], ["self", "Самозамес Ц:П = 1:3 на ПЦ М500"]] },
      { k: "bag", label: "Мешок смеси, кг", def: 40, show: v => v.mix === "dry" },
      { k: "fib", label: "Добавлять фибру", type: "check", def: true }
    ],
    run(v) {
      let t = v.t, extra = [];
      if (v.mode === "meas") {
        const m = v.m;
        if (!m.length) return { warn: "Введите замеры." };
        const mn = Math.min(...m), mx = Math.max(...m), avg = m.reduce((s, x) => s + x, 0) / m.length;
        t = avg - mn + v.tmin;
        extra = [["Перепад пола", nint(mx - mn) + " мм"], ["Толщина в самой низкой точке", nint(mx - mn + v.tmin) + " мм"], ["Отметка чистовой стяжки", "линия лазера − " + nint(mn - v.tmin) + " мм"]];
      }
      const V = v.A * t / 1000;
      const items = [], st = [S("Средняя толщина", nf(t, 0), "мм"), S("Объём раствора", nf(V, 2), "м³")];
      if (v.mix === "dry") {
        const kg = v.A * t * 2 * 1.05, bags = ceil(kg / v.bag);
        st.push(S("Смеси", nint(bags), "меш.", nint(kg) + " кг · по " + v.bag + " кг", true));
        items.push(["Пескобетон / ЦПС М150, мешок " + v.bag + " кг", bags, "меш."]);
      } else {
        const cem = V * 1.05 * 480, sand = V * 1.05 * 1.1;
        st.push(S("Цемент / песок", nint(ceil(cem / 50)) + " меш.", "", "≈ " + nint(cem) + " кг · песок " + nf(sand, 2) + " м³", true));
        items.push(["Цемент ПЦ М500, мешок 50 кг", ceil(cem / 50), "меш."], ["Песок", Math.round(sand * 100) / 100, "м³"]);
      }
      const days = Math.round(7 * Math.min(t, 40) / 10 + 14 * Math.max(0, t - 40) / 10);
      st.push(S("Высыхание до укладки покрытия", "≈ " + days, "сут", "при +20 °C, без сквозняков"));
      items.push(["Демпферная лента", Math.round(v.P * 1.05 * 10) / 10, "м"]);
      if (v.fib) { const f = Math.max(0.1, V * 0.8); items.push(["Фибра полипропиленовая", Math.round(f * 10) / 10, "кг"]); extra.push(["Фибра (0,6–0,9 кг/м³)", nf(f, 1) + " кг"]); }
      extra.push(["Демпферная лента", nf(v.P * 1.05, 1) + " м"]);
      return {
        stats: st, table: { head: ["Параметр", "Значение"], rows: extra },
        warn: t < 30 ? "Стяжка тоньше 30 мм по плёнке или утеплителю трескается — используйте наливной пол или сделайте ≥ 40 мм." : "",
        items
      };
    },
    info: "Высыхание: ориентир — неделя на каждый сантиметр до 4 см и около двух недель на каждый следующий сантиметр. Под паркет и ламинат проверяйте влажность основания (обычно не более 2–4%)."
  });

  // ---------- Плитка ----------
  add({
    id: "tile", cat: "finish", name: "Плитка, клей и затирка", kw: "плитка керамогранит кафель клей затирка шов шпатель раскладка диагональ ванная санузел",
    desc: "Плитка в штуках и коробках, клей по зубу шпателя, затирка по шву",
    inputs: [
      { k: "A", label: "Площадь, м²", def: 12 },
      { k: "a", label: "Плитка: длина, мм", def: 600 }, { k: "b", label: "Плитка: ширина, мм", def: 300 }, { k: "th", label: "Толщина плитки, мм", def: 9 },
      { k: "j", label: "Шов, мм", def: 2 },
      { k: "lay", label: "Раскладка", type: "sel", def: "10", opts: [["7", "Прямая (+7%)"], ["10", "Со смещением / кирпичик (+10%)"], ["15", "Диагональ, ёлочка (+15%)"]] },
      { k: "box", label: "В коробке, м²", def: 1.44 },
      { k: "notch", label: "Зуб шпателя, мм", type: "sel", def: "8", opts: [["6", "6 мм (мелкая плитка)"], ["8", "8 мм (до 30×30)"], ["10", "10 мм (до 60×60)"], ["12", "12 мм (крупный формат)"]] }
    ],
    run(v) {
      const k = 1 + num(v.lay) / 100, tile = v.a * v.b / 1e6;
      const n = tile > 0 ? ceil(v.A * k / tile) : 0, boxes = v.box > 0 ? ceil(v.A * k / v.box) : 0;
      const glueRate = { 6: 2.7, 8: 3.5, 10: 4.2, 12: 5.2 }[v.notch];
      const glue = v.A * glueRate * 1.05, gBags = ceil(glue / 25);
      const groutRate = v.a > 0 && v.b > 0 ? (v.a + v.b) / (v.a * v.b) * v.th * v.j * 1.6 : 0;
      const grout = v.A * groutRate * 1.1;
      return {
        stats: [S("Плиток", nint(n), "шт.", "с запасом " + v.lay + "%"), S("Коробок", nint(boxes), "шт.", nf(boxes * v.box, 2) + " м²", true), S("Клей", nint(gBags), "меш. 25 кг", "≈ " + nf(glueRate, 1) + " кг/м² · " + nint(glue) + " кг"), S("Затирка", nf(grout, 1), "кг", nf(groutRate, 2) + " кг/м²")],
        items: [["Плитка " + v.a + "×" + v.b, boxes, "кор."], ["Плиточный клей, мешок 25 кг", gBags, "меш."], ["Затирка", Math.round(grout * 10) / 10, "кг"]]
      };
    },
    info: "Затирка: (A + B) / (A × B) × толщина × шов × 1,6 кг/м² (+10%). Клей — для цементных клеёв при нанесении на основание; при двойном нанесении (основание + плитка, крупный формат) добавьте 30–50%."
  });

  // ---------- Обои ----------
  add({
    id: "wallpaper", cat: "finish", name: "Обои", kw: "обои рулоны раппорт полосы комната флизелин",
    desc: "Рулоны с учётом раппорта и высоты потолка",
    inputs: [
      { k: "a", label: "Длина комнаты, м", def: 5 }, { k: "b", label: "Ширина комнаты, м", def: 4 }, { k: "H", label: "Высота стен, м", def: 2.7 },
      { k: "doors", label: "Дверей (0,9 м)", def: 1 }, { k: "wins", label: "Окон (1,5 м)", def: 1 },
      { k: "w", label: "Ширина рулона, м", type: "sel", def: "1.06", opts: [["0.53", "0,53 м"], ["0.7", "0,70 м"], ["1.06", "1,06 м"]] },
      { k: "rl", label: "Длина рулона, м", def: 10.05 },
      { k: "rap", label: "Раппорт, см", def: 0, hint: "0 — без подбора рисунка" }
    ],
    run(v) {
      const w = num(v.w), P = 2 * (v.a + v.b);
      const free = Math.max(0, P - v.doors * 0.9 - v.wins * 1.5 * 0.6); // над/под окнами — короткие полосы
      const strips = w > 0 ? ceil(free / w) : 0;
      const r = v.rap / 100;
      const stripLen = r > 0 ? ceil((v.H + 0.05) / r) * r : v.H + 0.1;
      const per = stripLen > 0 ? Math.floor(v.rl / stripLen + 1e-9) : 0;
      const rolls = per > 0 ? ceil(strips / per) : 0;
      return {
        stats: [S("Полос", nint(strips), "шт.", "длиной " + nf(stripLen, 2) + " м"), S("Полос из рулона", nint(per), "шт.", per ? "отход " + nf(v.rl - per * stripLen, 2) + " м с рулона" : "рулон короче полосы"), S("Рулонов", nint(rolls), "шт.", "+1 в запас из той же партии", true), S("Площадь стен", nf(P * v.H, 1), "м²")],
        warn: per === 0 ? "Полоса длиннее рулона — проверьте высоту и длину рулона." : "",
        items: [["Обои " + nf(w, 2) + " × " + nf(v.rl, 2) + " м", rolls + 1, "рул."]]
      };
    },
    info: "Окна учтены частично (над и под ними клеятся короткие полосы), двери вычитаются целиком. Берите рулоны из одной партии — номер партии указан на этикетке."
  });

  // ---------- Краска ----------
  add({
    id: "paint", cat: "finish", mark: "подбор банок", name: "Краска и грунт", kw: "краска покраска грунт грунтовка банки литры расход слои потолок стены",
    desc: "Литры краски и оптимальный набор банок без лишних остатков",
    inputs: [
      { k: "A", label: "Площадь, м²", def: 60 }, { k: "c", label: "Слоёв", def: 2 },
      { k: "cov", label: "Расход: м² с 1 литра за слой", def: 8, hint: "На банке: «8–10 м²/л»" },
      { k: "cans", label: "Объёмы банок, л", def: "9 2,7 0,9", type: "text", hint: "Через пробел" },
      { k: "pr", label: "Считать грунт", type: "check", def: true }
    ],
    run(v) {
      const need = v.cov > 0 ? v.A * v.c / v.cov * 1.05 : 0;
      const sizes = String(v.cans).split(/[\s;]+/).map(num).filter(x => x > 0).sort((a, b) => b - a).slice(0, 4);
      let best = null;
      if (sizes.length) {
        const lim = sizes.map(s => ceil(need / s) + 1);
        const rec = (i, cur, vol, cnt) => {
          if (i === sizes.length) { if (vol >= need - 1e-9 && (!best || vol < best.vol - 1e-9 || (Math.abs(vol - best.vol) < 1e-9 && cnt < best.cnt))) best = { vol, cnt, combo: cur.slice() }; return; }
          for (let k = 0; k <= lim[i]; k++) { cur.push(k); rec(i + 1, cur, vol + k * sizes[i], cnt + k); cur.pop(); if (vol + k * sizes[i] >= need) break; }
        };
        rec(0, [], 0, 0);
      }
      const combo = best ? best.combo.map((k, i) => k ? k + " × " + nf(sizes[i], sizes[i] % 1 ? 1 : 0) + " л" : "").filter(Boolean).join(" + ") : "—";
      const primer = v.pr ? v.A * 0.12 : 0;
      const items = best ? best.combo.map((k, i) => k ? ["Краска, банка " + nf(sizes[i], sizes[i] % 1 ? 1 : 0) + " л", k, "шт."] : null).filter(Boolean) : [];
      if (v.pr) items.push(["Грунтовка", Math.round(primer * 10) / 10, "л"]);
      return {
        stats: [S("Краски нужно", nf(need, 1), "л", "с запасом 5%"), S("Купить", combo, "", best ? "всего " + nf(best.vol, 1) + " л, остаток " + nf(best.vol - need, 1) + " л" : "", true), ...(v.pr ? [S("Грунтовки", nf(primer, 1), "л", "≈ 0,1–0,15 л/м²")] : [])],
        items
      };
    },
    info: "Подбор банок перебирает все сочетания указанных объёмов и выбирает то, где меньше всего остаётся, а при равенстве — меньше банок. Первый слой по пористому основанию расходуется сильнее."
  });

  // ---------- Ламинат ----------
  add({
    id: "floor", cat: "finish", name: "Ламинат, плинтус, подложка", kw: "ламинат паркетная доска кварцвинил spc линолеум плинтус подложка пол упаковки порожек",
    desc: "Упаковки покрытия, плинтус в планках, подложка, порожки",
    inputs: [
      { k: "a", label: "Длина комнаты, м", def: 5 }, { k: "b", label: "Ширина комнаты, м", def: 4 },
      { k: "pack", label: "В упаковке, м²", def: 2.131 },
      { k: "lay", label: "Раскладка", type: "sel", def: "5", opts: [["5", "Прямая (+5%)"], ["10", "Сложная комната (+10%)"], ["15", "Диагональ, ёлочка (+15%)"]] },
      { k: "d", label: "Дверных проёмов", def: 1 }, { k: "dw", label: "Ширина проёма, м", def: 0.8 },
      { k: "pl", label: "Длина планки плинтуса, м", def: 2.5 }, { k: "ur", label: "Подложка в рулоне, м²", def: 10 }
    ],
    run(v) {
      const A = v.a * v.b, k = 1 + num(v.lay) / 100;
      const packs = v.pack > 0 ? ceil(A * k / v.pack) : 0;
      const plinth = Math.max(0, 2 * (v.a + v.b) - v.d * v.dw), pcs = v.pl > 0 ? ceil(plinth * 1.05 / v.pl) : 0;
      const under = v.ur > 0 ? ceil(A * 1.05 / v.ur) : 0;
      return {
        stats: [S("Площадь пола", nf(A, 2), "м²"), S("Упаковок", nint(packs), "шт.", nf(packs * v.pack, 2) + " м²", true), S("Плинтус", nint(pcs), "планок", nf(plinth, 1) + " м · углов ≈ " + 4), S("Подложка", nint(under), "рул.")],
        items: [["Напольное покрытие, упаковка " + nf(v.pack, 3) + " м²", packs, "уп."], ["Плинтус " + nf(v.pl, 1) + " м", pcs, "шт."], ["Подложка, рулон " + nf(v.ur, 0) + " м²", under, "рул."], ["Порожек", v.d, "шт."]]
      };
    },
    info: "Перед укладкой покрытие 48 часов акклиматизируется в помещении. Вдоль стен оставляйте компенсационный зазор 8–10 мм — его закрывает плинтус."
  });

  // ---------- ГКЛ перегородка ----------
  add({
    id: "gkl", cat: "finish", name: "Перегородка из гипсокартона", kw: "гипсокартон гкл перегородка профиль пн пс каркас саморезы серпянка knauf гвл",
    desc: "Листы, профили ПН/ПС, саморезы, дюбели, лента и шпаклёвка",
    inputs: [
      { k: "L", label: "Длина перегородки, м", def: 4 }, { k: "H", label: "Высота, м", def: 2.7 },
      { k: "lay", label: "Слоёв ГКЛ с каждой стороны", type: "sel", def: "1", opts: [["1", "1 слой"], ["2", "2 слоя"]] },
      { k: "sh", label: "Лист", type: "sel", def: "3", opts: [["2.5", "1200 × 2500"], ["2.7", "1200 × 2700"], ["3", "1200 × 3000"]] },
      { k: "st", label: "Шаг стоек, мм", type: "sel", def: "600", opts: [["600", "600"], ["400", "400 (под плитку)"]] },
      { k: "doors", label: "Дверных проёмов", def: 1 },
      { k: "ins", label: "Звукоизоляция минватой", type: "check", def: true }
    ],
    run(v) {
      const A = v.L * v.H, layers = num(v.lay), shA = 1.2 * num(v.sh);
      const sheets = ceil(A * 2 * layers / shA * 1.1);
      const studs = ceil(v.L / (num(v.st) / 1000)) + 1 + v.doors * 2;
      const studLen = studs * v.H, pn = 2 * v.L + v.doors * 1.2;
      const studPcs = ceil(studLen / 3 * (v.H > 3 ? 1.1 : 1)), pnPcs = ceil(pn / 3);
      const screws = ceil(A * 2 * layers * 25), dowels = ceil(pn / 0.5);
      const items = [["ГКЛ 1200×" + Math.round(num(v.sh) * 1000), sheets, "лист."], ["Профиль ПС 50/75/100, 3 м", studPcs, "шт."], ["Профиль ПН 50/75/100, 3 м", pnPcs, "шт."], ["Саморезы TN 25/35", screws, "шт."], ["Дюбель-гвоздь 6×40", dowels, "шт."], ["Лента серпянка", Math.round(A * 2 * 1.2), "м"], ["Шпаклёвка для швов", Math.round(A * 2 * 0.35), "кг"]];
      if (v.ins) items.push(["Минвата акустическая", Math.round(A * 1.05 * 10) / 10, "м²"]);
      return {
        stats: [S("Листов ГКЛ", nint(sheets), "шт.", "+10% на подрезку", true), S("Стоек ПС", nint(studs), "шт.", nint(studPcs) + " профилей по 3 м"), S("Направляющий ПН", nf(pn, 1), "м", nint(pnPcs) + " профилей по 3 м"), S("Саморезов", nint(screws), "шт.")],
        table: { head: ["Позиция", "Количество"], rows: items.map(i => [i[0], nint(i[1]) + " " + i[2]]) },
        items
      };
    },
    info: "Проёмы не вычитаются из листов (обрезки идут на подрезку). У дверей ставятся сдвоенные или усиленные стойки — учтены по 2 на проём. Перемычка над дверью — из ПН."
  });

  // ---------- Утеплитель ----------
  add({
    id: "insul", cat: "finish", name: "Утеплитель и мокрый фасад", kw: "утеплитель минвата пенопласт пеноплэкс эппс фасад мокрый дюбель грибок клей сетка теплоизоляция",
    desc: "Упаковки утеплителя, а для фасада — дюбели, клей и сетка",
    inputs: [
      { k: "A", label: "Площадь, м²", def: 100 },
      { k: "t", label: "Толщина утепления, мм", def: 100 },
      { k: "pt", label: "Толщина плиты в упаковке, мм", def: 50 },
      { k: "pa", label: "Площадь в упаковке, м²", def: 2.88, hint: "При этой толщине плит" },
      { k: "mat", label: "Материал", type: "sel", def: "mw", opts: [["mw", "Минвата"], ["eps", "Пенополистирол / ЭППС"]] },
      { k: "wet", label: "Мокрый фасад (дюбели, клей, сетка)", type: "check", def: false }
    ],
    run(v) {
      const layers = v.pt > 0 ? ceil(v.t / v.pt) : 0;
      const packs = v.pa > 0 ? ceil(v.A * layers / v.pa * 1.05) : 0;
      const V = v.A * v.t / 1000;
      const st = [S("Объём", nf(V, 2), "м³"), S("Слоёв по " + v.pt + " мм", nint(layers), ""), S("Упаковок", nint(packs), "шт.", "+5% на подрезку", true)];
      const items = [[(v.mat === "mw" ? "Минвата " : "ЭППС ") + v.pt + " мм, уп. " + nf(v.pa, 2) + " м²", packs, "уп."]];
      if (v.wet) {
        const dow = ceil(v.A * (v.mat === "mw" ? 6 : 5) * 1.05), glue = v.A * (v.mat === "mw" ? 5 : 4), base = v.A * 5, mesh = v.A * 1.15;
        st.push(S("Дюбелей-грибков", nint(dow), "шт.", "длина ≥ " + nint(v.t + 60) + " мм"));
        items.push(["Дюбель тарельчатый " + nint(v.t + 60) + " мм", dow, "шт."], ["Клей для утеплителя, 25 кг", ceil(glue / 25), "меш."], ["Базовый армирующий состав, 25 кг", ceil(base / 25), "меш."], ["Сетка фасадная 160 г/м²", Math.round(mesh), "м²"]);
      }
      return { stats: st, items, table: v.wet ? { head: ["Позиция", "Количество"], rows: items.map(i => [i[0], nint(i[1]) + " " + i[2]]) } : null };
    },
    info: "Слои ставят с разбежкой швов. Длина дюбеля = толщина утеплителя + клей + заглубление в основание (обычно ≥ 50 мм в кирпич и бетон, ≥ 90 мм в газобетон)."
  });

  // ---------- Уклон ----------
  add({
    id: "slope", cat: "tech", name: "Уклон: градусы, %, мм/м", kw: "уклон градусы проценты промилле перепад канализация отмостка пандус кровля мм на метр 1:n",
    desc: "Перевод уклона между единицами и перепад на длине",
    inputs: [
      { k: "u", label: "Единица", type: "sel", def: "pct", opts: [["pct", "проценты, %"], ["deg", "градусы, °"], ["mm", "мм на метр"], ["n", "1 : n"]] },
      { k: "x", label: "Значение", def: 2 },
      { k: "L", label: "Длина участка, м", def: 6 }
    ],
    run(v) {
      let t; // tan
      if (v.u === "pct") t = v.x / 100; else if (v.u === "deg") t = Math.tan(rad(v.x)); else if (v.u === "mm") t = v.x / 1000; else t = v.x > 0 ? 1 / v.x : 0;
      return {
        stats: [S("Проценты", nf(t * 100, 2), "%"), S("Градусы", nf(deg(Math.atan(t)), 2), "°"), S("На метр", nf(t * 1000, 1), "мм/м"), S("Перепад на " + nf(v.L, 1) + " м", nint(t * v.L * 1000), "мм", "соотношение 1 : " + (t ? nf(1 / t, 1) : "∞"), true)],
        table: { cap: "Частые нормы (проверяйте по проекту)", head: ["Где", "Уклон"], rows: [["Канализация Ø40–50 мм", "0,025–0,03 (25–30 мм/м)"], ["Канализация Ø100–110 мм", "0,02 (20 мм/м)"], ["Наружная канализация Ø110", "не менее 0,02"], ["Отмостка", "1–10% от стены"], ["Пандус для маломобильных", "не более 5% (1:20)"], ["Балкон, терраса", "1–2% от стены"]] }
      };
    }
  });

  // ---------- Металл ----------
  add({
    id: "metal", cat: "tech", name: "Масса металлопроката", kw: "вес металл масса труба профильная лист уголок полоса круг арматура швеллер кг метр погонный",
    desc: "Вес трубы, профтрубы, листа, уголка, полосы и круга",
    inputs: [
      { k: "type", label: "Прокат", type: "sel", def: "prof", opts: [["round", "Круг / арматура"], ["pipe", "Труба круглая"], ["prof", "Труба профильная"], ["angle", "Уголок равнополочный"], ["strip", "Полоса"], ["sheet", "Лист"]] },
      { k: "d", label: "Диаметр, мм", def: 12, show: v => v.type === "round" },
      { k: "D", label: "Наружный диаметр, мм", def: 57, show: v => v.type === "pipe" },
      { k: "a", label: v => v.type === "angle" ? "Полка, мм" : v.type === "strip" ? "Ширина, мм" : "Сторона A, мм", def: 60, show: v => ["prof", "angle", "strip"].includes(v.type) },
      { k: "b", label: "Сторона B, мм", def: 40, show: v => v.type === "prof" },
      { k: "s", label: "Толщина стенки, мм", def: 3, show: v => v.type !== "round" },
      { k: "sw", label: "Лист: ширина, м", def: 1.25, show: v => v.type === "sheet" },
      { k: "sl", label: "Лист: длина, м", def: 2.5, show: v => v.type === "sheet" },
      { k: "L", label: v => v.type === "sheet" ? "Листов, шт." : "Общая длина, м", def: 12 }
    ],
    run(v) {
      const r = 7.85e-3; let kgm = 0, note = "";
      if (v.type === "round") kgm = Math.PI * v.d * v.d / 4 * r;
      if (v.type === "pipe") kgm = Math.PI * (v.D - v.s) * v.s * r;
      if (v.type === "prof") { kgm = (2 * (v.a + v.b) - 4 * v.s) * v.s * r; note = "без учёта скругления углов (≈ −2%)"; }
      if (v.type === "angle") kgm = v.s * (2 * v.a - v.s) * r;
      if (v.type === "strip") kgm = v.a * v.s * r;
      if (v.type === "sheet") { const one = v.sw * v.sl * v.s * 7.85; return { stats: [S("Масса листа", nf(one, 1), "кг", nf(v.s * 7.85, 2) + " кг/м²"), S("Всего", nf(one * v.L, 1), "кг", nf(one * v.L / 1000, 3) + " т", true)] }; }
      return { stats: [S("Масса 1 м", nf(kgm, 3), "кг/м", note), S("Всего", nf(kgm * v.L, 1), "кг", nf(kgm * v.L / 1000, 3) + " т", true), S("Метров в тонне", kgm ? nf(1000 / kgm, 1) : "—", "м")] };
    },
    info: "Плотность стали 7850 кг/м³. Масса по формулам геометрии, ГОСТ-овские значения для уголка и профтрубы немного меньше из-за скруглений."
  });

  // ---------- Земляные работы ----------
  const SOILS = { sand: ["Песок", 1.6, 1.12, [0.5, 1]], sandy: ["Супесь", 1.65, 1.15, [0.25, 0.67]], loam: ["Суглинок", 1.75, 1.24, [0, 0.5]], clay: ["Глина", 1.8, 1.28, [0, 0.25]], fill: ["Насыпной грунт", 1.6, 1.1, [0.67, 1]] };
  add({
    id: "earth", cat: "found", name: "Котлован и траншея", kw: "котлован траншея земляные работы грунт откос разрыхление вывоз камаз самосвал копка объем земли",
    desc: "Объём выемки с откосами, грунт в разрыхлении и рейсы самосвала",
    inputs: [
      { k: "type", label: "Выемка", type: "sel", def: "pit", opts: [["pit", "Котлован"], ["trench", "Траншея"]] },
      { k: "L", label: "Длина по дну, м", def: 12 }, { k: "W", label: "Ширина по дну, м", def: 10 }, { k: "H", label: "Глубина, м", def: 1.8 },
      { k: "soil", label: "Грунт", type: "sel", def: "loam", opts: Object.entries(SOILS).map(([k, s]) => [k, s[0]]) },
      { k: "slope", label: "Откосы", type: "sel", def: "auto", opts: [["auto", "по нормам для грунта"], ["0", "вертикальные стенки (крепление)"]] },
      { k: "truck", label: "Самосвал, м³ кузова", def: 10 }
    ],
    run(v) {
      const s = SOILS[v.soil], m = v.slope === "0" ? 0 : (v.H <= 1.5 ? s[3][0] : s[3][1]);
      let V;
      if (v.type === "trench") V = (v.W + m * v.H) * v.H * v.L;
      else { const A1 = v.L * v.W, A2 = (v.L + 2 * m * v.H) * (v.W + 2 * m * v.H), Am = (v.L + m * v.H) * (v.W + m * v.H); V = v.H / 6 * (A1 + A2 + 4 * Am); }
      const loose = V * s[2], trips = v.truck > 0 ? ceil(loose / v.truck) : 0;
      const warn = (m === 0 && v.H > (v.soil === "sand" || v.soil === "fill" ? 1 : 1.5)) ? "При такой глубине вертикальные стенки без крепления недопустимы (СНиП 12-04): нужны откосы или крепление." : "";
      return {
        stats: [S("Объём в плотном теле", nf(V, 1), "м³"), S("В разрыхлении (вывоз)", nf(loose, 1), "м³", "Kр = " + nf(s[2], 2), true), S("Рейсов самосвала", nint(trips), "шт.", "по " + nf(v.truck, 0) + " м³"), S("Масса грунта", nf(V * s[1], 0), "т")],
        table: { head: ["Параметр", "Значение"], rows: [["Заложение откоса 1 : m", m ? "1 : " + nf(m, 2) : "вертикально"], ["Размер поверху", nf(v.L + 2 * m * v.H, 2) + " × " + nf((v.type === "trench" ? v.W : v.W) + 2 * m * v.H, 2) + " м"]] },
        warn
      };
    },
    info: "Крутизна откосов — по СНиП 12-04-2002 для глубины до 1,5 и до 3 м. Для котлована объём считается как усечённая пирамида. Обратная засыпка уплотняется: оставьте на месте объём пазух × коэффициент остаточного разрыхления."
  });

  // ---------- Сыпучие ----------
  const BULK = { sand: ["Песок карьерный", 1.5], sandw: ["Песок мытый влажный", 1.65], pgs: ["ПГС", 1.65], g520: ["Щебень гранитный 5–20", 1.37], g2040: ["Щебень гранитный 20–40", 1.38], gr: ["Щебень гравийный", 1.43], scr: ["Отсев", 1.5], soil: ["Грунт растительный", 1.2], keram: ["Керамзит", 0.4], cem: ["Цемент", 1.3] };
  add({
    id: "bulk", cat: "tech", name: "Песок, щебень: м³ ↔ тонны", kw: "песок щебень пгс отсев керамзит тонны кубы насыпная плотность самосвал подсыпка уплотнение доставка",
    desc: "Перевод кубов в тонны, подсыпка по площади и слою, рейсы машины",
    inputs: [
      { k: "mat", label: "Материал", type: "sel", def: "g520", opts: Object.entries(BULK).map(([k, b]) => [k, b[0] + " (" + nf(b[1], 2) + " т/м³)"]) },
      { k: "mode", label: "Известно", type: "sel", def: "area", opts: [["area", "площадь и толщина слоя"], ["m3", "объём, м³"], ["t", "масса, т"]] },
      { k: "A", label: "Площадь, м²", def: 60, show: v => v.mode === "area" }, { k: "h", label: "Слой после уплотнения, см", def: 15, show: v => v.mode === "area" },
      { k: "kc", label: "Коэффициент уплотнения", def: 1.25, show: v => v.mode === "area", hint: "Песок 1,15–1,25 · щебень 1,25–1,3" },
      { k: "V", label: "Объём, м³", def: 10, show: v => v.mode === "m3" }, { k: "T", label: "Масса, т", def: 20, show: v => v.mode === "t" },
      { k: "truck", label: "Машина, т", def: 20 }
    ],
    run(v) {
      const rho = BULK[v.mat][1];
      const V = v.mode === "area" ? v.A * v.h / 100 * v.kc : v.mode === "m3" ? v.V : v.T / rho;
      const T = V * rho;
      return { stats: [S("Объём (насыпной)", nf(V, 2), "м³"), S("Масса", nf(T, 2), "т", "", true), S("Рейсов", nint(v.truck > 0 ? ceil(T / v.truck) : 0), "шт.", "по " + nf(v.truck, 0) + " т")], items: [[BULK[v.mat][0], Math.round(T * 10) / 10, "т"]] };
    },
    info: "Насыпная плотность сильно зависит от влажности и фракции: при заказе уточняйте, в чём продаёт поставщик — в тоннах или в кубах."
  });

  // ---------- Справочник бетона ----------
  const CLS = [["B7,5", "М100", 7.5, "Подбетонка, подготовка под фундамент"], ["B10", "М150", 10, "Подготовка, стяжки, дорожки"], ["B12,5", "М150", 12.5, "Стяжки, отмостка, ненагруженные конструкции"], ["B15", "М200", 15, "Ленточные фундаменты лёгких строений, площадки"], ["B20", "М250", 20, "Фундаменты частных домов, перекрытия малых пролётов"], ["B22,5", "М300", 22.5, "Фундаменты, монолитные стены и перекрытия"], ["B25", "М350", 25, "Монолитные перекрытия, колонны, ростверки"], ["B30", "М400", 30, "Ответственные конструкции, бассейны, мосты"], ["B35", "М450", 35, "Гидротехнические, специальные конструкции"], ["B40", "М550", 40, "Специальные конструкции"]];
  add({
    id: "concref", cat: "tech", name: "Классы и марки бетона", kw: "класс марка бетона м200 м300 b25 мпа прочность кгс справочник таблица",
    desc: "Соответствие B и М, прочность в МПа и кгс/см², где применяют",
    inputs: [],
    run() {
      return { table: { cap: "Средняя прочность для класса — при коэффициенте вариации 13,5%: R = B / 0,778", head: ["Класс", "Марка", "B, МПа", "Средняя, МПа", "≈ кгс/см²", "Где применяют"], rows: CLS.map(c => [c[0], c[1], nf(c[2], 1), nf(c[2] / 0.778, 1), nint(c[2] / 0.778 * 10.197), c[3]]) } };
    }
  });

  // ====================================================================
  //  UI: sidebar, router, generic renderer
  // ====================================================================
  const byId = Object.fromEntries(CALCS.map(c => [c.id, c]));
  const main = $("gen-host");
  let current = null;
  window.__legacy = window.__legacy || {};

  // ---- sidebar ----
  const nav = $("side-nav"), q = $("side-q");
  // Открытие сайта с диска (file://): папки не открываются как страницы — добавляем index.html к ссылкам
  if (location.protocol === "file:") {
    if (window.PAGE && window.PAGE.urls) Object.keys(window.PAGE.urls).forEach(k => { const u = window.PAGE.urls[k]; if (/\/$/.test(u)) window.PAGE.urls[k] = u + "index.html"; });
    const fixA = a => { const h = a.getAttribute("href"); if (h && !/^(https?:|mailto:|#|data:)/.test(h) && /\/$/.test(h)) a.setAttribute("href", h + "index.html"); else if (h === "./" || h === "") a.setAttribute("href", "index.html"); };
    document.querySelectorAll("a[href]").forEach(fixA);
    new MutationObserver(ms => ms.forEach(m => m.addedNodes.forEach(n => { if (n.nodeType === 1) { if (n.matches && n.matches("a[href]")) fixA(n); n.querySelectorAll && n.querySelectorAll("a[href]").forEach(fixA); } }))).observe(document.body, { childList: true, subtree: true });
  }
  const MP = window.PAGE || null;
  const on = (id, ev, fn) => { const el = document.getElementById(id); if (el) el.addEventListener(ev, fn); };
  const urlOf = id => MP && MP.urls[id] != null ? MP.root + MP.urls[id] : "#" + id;
  const goal = name => { try { if (window.ym && window.METRIKA_ID) window.ym(window.METRIKA_ID, "reachGoal", name); } catch (e) {} };
  function go(id, params) { if (MP && id !== current && MP.urls[id] != null) { location.href = urlOf(id); return; } open(id, params); }
  function navLink(c) {
    const a = document.createElement("a");
    a.href = urlOf(c.id); a.className = "nav-item" + (current === c.id ? " on" : ""); a.dataset.id = c.id;
    a.innerHTML = '<span class="nav-name"></span>' + (c.mark ? '<span class="nav-mark"></span>' : "");
    a.querySelector(".nav-name").textContent = c.name;
    if (c.mark) a.querySelector(".nav-mark").textContent = c.mark;
    a.onclick = e => { if (MP) return; e.preventDefault(); open(c.id); closeDrawer(); };
    return a;
  }
  let navOpen = {}, lastCat = null;
  function renderNav() {
    const qs = norm(q.value.trim()).split(/\s+/).filter(Boolean);
    nav.innerHTML = "";
    const est = document.createElement("a");
    est.href = "#estimate"; est.className = "nav-item est" + (current === "estimate" ? " on" : "");
    est.innerHTML = '<span class="nav-name">Смета материалов</span><span class="badge" id="est-badge"></span>';
    est.href = urlOf("estimate"); est.onclick = e => { if (MP) return; e.preventDefault(); open("estimate"); closeDrawer(); };
    if (!qs.length) nav.appendChild(est);
    const match = c => { const hay = norm(c.name + " " + c.kw + " " + c.desc); return qs.every(t => hay.includes(t)); };
    let found = 0;
    if (!qs.length) {
      const rec = (store.get("recent") || []).filter(id => byId[id]).slice(0, 4);
      if (rec.length) { const h = document.createElement("div"); h.className = "nav-h"; h.textContent = "Недавние"; nav.appendChild(h); rec.forEach(id => nav.appendChild(navLink(byId[id]))); }
    }
    const curCat = byId[current] ? byId[current].cat : null;
    CATS.forEach(([cat, title]) => {
      const list = CALCS.filter(c => c.cat === cat && match(c));
      if (!list.length) return;
      found += list.length;
      const isOpen = qs.length ? true : (navOpen[cat] !== undefined ? navOpen[cat] : cat === curCat);
      const h = document.createElement("button"); h.type = "button"; h.className = "nav-cat" + (isOpen ? " open" : "") + (cat === curCat ? " cur" : "");
      h.setAttribute("aria-expanded", isOpen);
      h.innerHTML = '<span class="nc-t"></span><span class="nc-n">' + list.length + '</span><svg class="nc-ch" viewBox="0 0 12 12" aria-hidden="true"><path d="M3 4.5l3 3 3-3" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>';
      h.querySelector(".nc-t").textContent = title;
      h.onclick = () => { navOpen[cat] = !isOpen; renderNav(); };
      nav.appendChild(h);
      if (isOpen) { const box = document.createElement("div"); box.className = "nav-grp"; list.forEach(c => box.appendChild(navLink(c))); nav.appendChild(box); }
    });
    if (qs.length && !found) { const p = document.createElement("div"); p.className = "nav-empty"; p.textContent = "Ничего не найдено. Попробуйте другое слово: «плитка», «уклон», «кубы»."; nav.appendChild(p); }
    updateBadge();
  }
  q.addEventListener("input", renderNav);
  q.addEventListener("keydown", e => {
    if (e.key === "Enter") { const first = nav.querySelector(".nav-item:not(.est)"); if (first) { go(first.dataset.id); q.blur(); closeDrawer(); } }
    if (e.key === "Escape") { q.value = ""; renderNav(); }
  });
  document.addEventListener("keydown", e => {
    if (e.key === "/" && !/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)) { e.preventDefault(); openDrawer(); q.focus(); }
  });
  // drawer (mobile)
  function openDrawer() { document.body.classList.add("drawer-open"); }
  function closeDrawer() { document.body.classList.remove("drawer-open"); }
  $("menu-btn").onclick = () => { openDrawer(); setTimeout(() => q.focus(), 50); };
  $("drawer-bg").onclick = closeDrawer;

  // ---- единица измерения внутри поля ----
  const UNIT_RE = /^(.*\S),\s*(мм|см|м|м²|м³|кг|т|т\/м³|°C|°|%|кПа|Па|л|сут|суток|кВт|₽|кг\/м³|кг\/м²|м\/с|мм\/м|л\/сут|м³\/ч|т\/м|шт\.|кг\/м³)$/;
  const splitUnit = s => { const m = UNIT_RE.exec(String(s || "")); return m ? [m[1], m[2]] : [String(s || ""), ""]; };
  function enhanceUnits(root) {
    root.querySelectorAll(".field").forEach(f => {
      const lb = f.querySelector(":scope > label.lbl"), inp = f.querySelector(':scope > input[type="number"], :scope > input[type="text"]');
      if (!lb || !inp || inp.closest(".inp-u") || inp.classList.contains("pl-q")) return;
      const [t, u] = splitUnit(lb.textContent.trim());
      if (!u) return;
      lb.textContent = t;
      const w = document.createElement("div"); w.className = "inp-u"; inp.parentNode.insertBefore(w, inp); w.appendChild(inp);
      const sp = document.createElement("span"); sp.className = "u"; sp.textContent = u; w.appendChild(sp);
    });
  }
  ["tab-strength", "tab-volume", "tab-mix", "tab-rebar", "tab-brick"].forEach(id => { const el = document.getElementById(id); if (el) enhanceUnits(el); });

  // ---- выбор города в шапке (общий для всех расчётов) ----
  (function initCity() {
    const host = document.querySelector("header.top .top-r");
    if (!host) return;
    const PIN = '<svg viewBox="0 0 20 20" width="16" height="16" aria-hidden="true"><path d="M10 18s6-5.2 6-10a6 6 0 1 0-12 0c0 4.8 6 10 6 10z" fill="none" stroke="currentColor" stroke-width="1.6"/><circle cx="10" cy="8" r="2.2" fill="currentColor"/></svg>';
    const wrap = document.createElement("div"); wrap.className = "city";
    wrap.innerHTML = '<button type="button" class="btn sm ghost city-btn" aria-haspopup="dialog" aria-expanded="false">' + PIN + '<span class="city-n"></span></button>' +
      '<div class="city-pop" hidden role="dialog" aria-label="Выбор населённого пункта"><div class="card-title">Ваш населённый пункт</div><p class="hint">Город подставится во все расчёты, где нужна погода и климат: прочность бетона, промерзание, подбор растений, цветник.</p>' +
      '<input type="search" class="city-q" placeholder="Начните вводить: Арзамас, Казань…" aria-label="Населённый пункт"><div class="city-list" role="listbox"></div></div>';
    host.insertBefore(wrap, host.querySelector(".theme"));
    const btn = wrap.querySelector(".city-btn"), pop = wrap.querySelector(".city-pop"), qi = wrap.querySelector(".city-q"), list = wrap.querySelector(".city-list"), nameEl = wrap.querySelector(".city-n");
    const show = () => { const p = store.get("place"); nameEl.textContent = p ? p.name : "Ваш город"; btn.title = p ? [p.name, p.admin1, p.country].filter(Boolean).join(", ") : "Выбрать населённый пункт"; };
    show();
    const close = () => { pop.hidden = true; btn.setAttribute("aria-expanded", "false"); };
    btn.addEventListener("click", e => { e.stopPropagation(); pop.hidden = !pop.hidden; btn.setAttribute("aria-expanded", String(!pop.hidden)); if (!pop.hidden) setTimeout(() => qi.focus(), 30); });
    document.addEventListener("click", e => { if (!wrap.contains(e.target)) close(); });
    document.addEventListener("keydown", e => { if (e.key === "Escape") close(); });
    let tmr = null, ctl = null;
    qi.addEventListener("input", e => {
      e.stopPropagation();
      clearTimeout(tmr);
      const s = qi.value.trim();
      if (s.length < 2) { list.innerHTML = ""; return; }
      tmr = setTimeout(async () => {
        try {
          if (ctl) ctl.abort(); ctl = new AbortController();
          const r = await fetch("https://geocoding-api.open-meteo.com/v1/search?count=8&language=ru&format=json&name=" + encodeURIComponent(s), { signal: ctl.signal });
          const res = (await r.json()).results || [];
          list.innerHTML = res.length ? "" : '<p class="hint">Ничего не найдено.</p>';
          res.forEach(p => {
            const b = document.createElement("button"); b.type = "button"; b.className = "city-opt"; b.textContent = p.name;
            const sm = document.createElement("small"); sm.textContent = [p.admin1, p.country].filter(Boolean).join(", "); b.appendChild(sm);
            b.onclick = () => {
              store.set("place", { name: p.name, admin1: p.admin1 || "", country: p.country || "", latitude: p.latitude, longitude: p.longitude });
              show(); close();
              if (document.querySelector('.pf, #tab-strength')) location.reload();
            };
            list.appendChild(b);
          });
        } catch (err) { if (err.name !== "AbortError") list.innerHTML = '<p class="hint">Поиск городов недоступен на этой странице.</p>'; }
      }, 300);
    });
    qi.addEventListener("change", e => e.stopPropagation());
    // если город выбран внутри калькулятора — обновить шапку
    document.addEventListener("change", () => setTimeout(show, 0));
    document.addEventListener("click", () => setTimeout(show, 0));
  })();

  // ---- generic calc renderer ----
  const built = {}, loadCache = {}, loadPending = {};
  const PLACE_DEF = { name: "Москва", admin1: "", country: "Россия", latitude: 55.7558, longitude: 37.6173 };
  const placeLabel = p => p ? p.name + (p.admin1 ? ", " + p.admin1 : "") + (p.country ? ", " + p.country : "") : "";
  const defOf = (f, v) => typeof f.def === "function" ? f.def(v) : f.def;
  const fmtVal = (f, val) => f.type === "text" || f.type === "place" ? String(val) : String(val).replace(".", ",");
  function readVals(c, panel) {
    const v = {};
    c.inputs.forEach(f => {
      const el = panel.querySelector('[data-k="' + f.k + '"]');
      if (!el) return;
      if (f.type === "check") v[f.k] = el.checked;
      else if (f.type === "sel" || f.type === "text") v[f.k] = el.value;
      else if (f.type === "place") { try { v[f.k] = JSON.parse(el.value); } catch (e) { v[f.k] = PLACE_DEF; } }
      else if (f.type === "list") v[f.k] = el.value.split(/[\s;]+/).map(x => x.replace(",", ".").replace("−", "-")).filter(Boolean).map(Number).filter(x => !isNaN(x));
      else v[f.k] = num(el.value);
    });
    return v;
  }
  function rawVals(c, panel) {
    const o = {};
    c.inputs.forEach(f => { const el = panel.querySelector('[data-k="' + f.k + '"]'); if (el) o[f.k] = f.type === "check" ? (el.checked ? "1" : "0") : el.value; });
    return o;
  }
  function wirePlace(box, panel) {
    const qi = box.querySelector(".pl-q"), hid = box.querySelector('input[type="hidden"]'), sug = box.querySelector(".suggest"), hint = box.querySelector(".pl-hint");
    let tmr = null, ctl = null;
    const showHint = () => { try { const p = JSON.parse(hid.value); hint.textContent = "Координаты: " + nf(p.latitude, 2) + ", " + nf(p.longitude, 2); } catch (e) {} };
    showHint();
    qi.addEventListener("input", e => {
      e.stopPropagation();
      clearTimeout(tmr);
      const s = qi.value.trim();
      if (s.length < 2) { sug.classList.remove("show"); return; }
      tmr = setTimeout(async () => {
        try {
          if (ctl) ctl.abort(); ctl = new AbortController();
          const r = await fetch("https://geocoding-api.open-meteo.com/v1/search?count=7&language=ru&format=json&name=" + encodeURIComponent(s), { signal: ctl.signal });
          const list = (await r.json()).results || [];
          sug.innerHTML = list.length ? "" : '<button type="button" disabled>Ничего не найдено</button>';
          list.forEach(p => {
            const b = document.createElement("button"); b.type = "button"; b.textContent = p.name;
            const sm = document.createElement("small"); sm.textContent = [p.admin1, p.country].filter(Boolean).join(", "); b.appendChild(sm);
            b.onclick = () => {
              const pl = { name: p.name, admin1: p.admin1 || "", country: p.country || "", latitude: p.latitude, longitude: p.longitude };
              hid.value = JSON.stringify(pl); qi.value = placeLabel(pl); store.set("place", pl);
              sug.classList.remove("show"); showHint(); panel.dispatchEvent(new Event("change"));
            };
            sug.appendChild(b);
          });
          sug.classList.add("show");
        } catch (err) { if (err.name !== "AbortError") { sug.innerHTML = '<button type="button" disabled>Поиск недоступен на этой странице</button>'; sug.classList.add("show"); } }
      }, 300);
    });
    qi.addEventListener("change", e => e.stopPropagation());
    document.addEventListener("click", e => { if (!box.contains(e.target)) sug.classList.remove("show"); });
  }
  function build(c, params) {
    const panel = document.createElement("div");
    panel.className = "tab-panel gen"; panel.id = "tab-" + c.id; panel.hidden = true;
    const saved = Object.assign({}, store.get("g:" + c.id) || {}, params || {});
    const v0 = {};
    c.inputs.forEach(f => { if (typeof f.def !== "function") v0[f.k] = saved[f.k] != null ? saved[f.k] : f.def; });
    let html = "";
    if (c.inputs.length) {
      html += '<section class="card"><div class="form">';
      c.inputs.forEach(f => {
        let val = saved[f.k] != null ? saved[f.k] : defOf(f, v0);
        const id = "g-" + c.id + "-" + f.k;
        if (f.type === "place") {
          val = (params && params[f.k]) || JSON.stringify(store.get("place") || PLACE_DEF);
          let pl; try { pl = JSON.parse(val); } catch (e) { pl = PLACE_DEF; val = JSON.stringify(pl); }
          html += '<div class="field wide pf" data-f="' + f.k + '"><label class="lbl" for="' + id + '"></label><input type="text" class="pl-q" id="' + id + '" autocomplete="off" value="' + esc(placeLabel(pl)) + '" placeholder="Начните вводить город или посёлок"><input type="hidden" data-k="' + f.k + '" value="' + esc(val) + '"><div class="suggest"></div><div class="hint pl-hint"></div></div>';
          return;
        }
        let ctl;
        if (f.type === "sel") ctl = '<select id="' + id + '" data-k="' + f.k + '">' + f.opts.map(o => '<option value="' + esc(o[0]) + '"' + (String(o[0]) === String(val) ? " selected" : "") + ">" + esc(o[1]) + "</option>").join("") + "</select>";
        else if (f.type === "list") ctl = '<textarea id="' + id + '" data-k="' + f.k + '">' + esc(val) + "</textarea>";
        else if (f.type === "text") ctl = '<input type="text" inputmode="text" id="' + id + '" data-k="' + f.k + '" value="' + esc(fmtVal(f, val)) + '">';
        else if (f.type !== "check") ctl = '<div class="inp-u"><input type="text" inputmode="decimal" id="' + id + '" data-k="' + f.k + '" value="' + esc(fmtVal(f, val)) + '"><span class="u"></span></div>';
        if (f.type === "check") {
          const on = val === true || val === "1" || val === 1;
          html += '<div class="field wide" data-f="' + f.k + '"><label class="check"><input type="checkbox" id="' + id + '" data-k="' + f.k + '"' + (on ? " checked" : "") + '> <span>' + esc(f.label) + "</span></label></div>";
        } else {
          html += '<div class="field' + (f.type === "list" || f.wide ? " wide" : "") + '" data-f="' + f.k + '"><label class="lbl" for="' + id + '"></label>' + ctl + (f.hint ? '<div class="hint">' + esc(f.hint) + "</div>" : "") + "</div>";
        }
      });
      html += "</div></section>";
    }
    html += '<div class="banner" data-o="warn"></div><div class="stats auto" data-o="stats"></div><div class="blocks" data-o="blocks"></div><section class="card" data-o="tablecard" hidden><div class="row-scroll"><table class="data"><caption data-o="cap"></caption><thead data-o="thead"></thead><tbody data-o="tbody"></tbody></table></div></section>';
    if (c.info) html += '<section class="card method"><div class="card-title" style="margin-bottom:8px">Как считается</div><p>' + esc(c.info) + "</p></section>";
    panel.innerHTML = html;
    main.appendChild(panel);
    panel.querySelectorAll(".pf").forEach(b => wirePlace(b, panel));
    const lastDep = {};
    const recalc = () => {
      let v = readVals(c, panel);
      // dependent defaults (e.g. layer thickness from a preset)
      let changed = false;
      c.inputs.forEach(f => {
        if (!f.dep) return;
        if (lastDep[f.dep] !== undefined && lastDep[f.dep] !== v[f.dep]) { const el = panel.querySelector('[data-k="' + f.k + '"]'); if (el) { el.value = fmtVal(f, defOf(f, v)); changed = true; } }
      });
      if (changed) v = readVals(c, panel);
      c.inputs.forEach(f => { if (f.dep) lastDep[f.dep] = v[f.dep]; });
      c.inputs.forEach(f => {
        const box = panel.querySelector('[data-f="' + f.k + '"]');
        if (f.type !== "check") {
          const full = typeof f.label === "function" ? f.label(v) : f.label, uEl = box.querySelector(".u");
          if (uEl) { const [t, u] = splitUnit(full); box.querySelector(".lbl").textContent = t; uEl.textContent = u; uEl.parentNode.classList.toggle("no-u", !u); }
          else box.querySelector(".lbl").textContent = full;
        }
        box.hidden = f.show ? !f.show(v) : false;
      });
      store.set("g:" + c.id, rawVals(c, panel));
      let data = null, loading = false;
      if (c.load) {
        const key = c.id + ":" + c.loadKey(v);
        if (key in loadCache) data = loadCache[key];
        else {
          loading = true;
          if (!loadPending[key]) {
            loadPending[key] = 1;
            Promise.resolve().then(() => c.load(v)).then(d => { loadCache[key] = d; }, e => { loadCache[key] = { error: String(e && e.message || e) }; }).then(() => { delete loadPending[key]; recalc(); });
          }
        }
      }
      let out;
      try { out = c.run(v, data, loading) || {}; } catch (e) { out = { warn: "Проверьте введённые данные." }; console.error(e); }
      const wb = panel.querySelector('[data-o="warn"]');
      wb.textContent = out.warn || out.note || "";
      wb.className = "banner" + (out.warn ? " err" : "");
      const st = panel.querySelector('[data-o="stats"]');
      st.innerHTML = "";
      (out.stats || []).forEach(s => {
        const d = document.createElement("div"); d.className = "stat";
        d.innerHTML = '<div class="stat-label"></div><div class="stat-value' + (s.accent ? " s" : "") + '"><span class="v"></span>' + (s.unit ? '<span class="unit"></span>' : "") + '</div><div class="stat-sub"></div>';
        d.querySelector(".stat-label").textContent = s.label; d.querySelector(".v").textContent = s.value;
        if (s.unit) d.querySelector(".unit").textContent = " " + s.unit;
        d.querySelector(".stat-sub").textContent = s.sub || "";
        st.appendChild(d);
      });
      st.hidden = !(out.stats || []).length;
      const bl = panel.querySelector('[data-o="blocks"]');
      bl.innerHTML = (out.blocks || []).map(b => '<section class="card ' + (b.cls || "") + '">' + (b.title ? '<div class="card-head"><div class="card-title">' + esc(b.title) + "</div>" + (b.aside || "") + "</div>" : "") + b.html + "</section>").join("");
      bl.hidden = !(out.blocks || []).length;
      const rows = (out.table ? out.table.rows : []).concat(out.extra || []);
      const tc = panel.querySelector('[data-o="tablecard"]');
      tc.hidden = !rows.length;
      if (rows.length) {
        const head = out.table ? out.table.head : ["Параметр", "Значение"];
        panel.querySelector('[data-o="cap"]').textContent = out.table && out.table.cap || "";
        panel.querySelector('[data-o="thead"]').innerHTML = "<tr>" + head.map(h => "<th>" + esc(h) + "</th>").join("") + "</tr>";
        const tb = panel.querySelector('[data-o="tbody"]'); tb.innerHTML = "";
        if (out.table && out.extra) { out.table.rows.forEach(r => addRow(tb, r, head.length)); const sep = document.createElement("tr"); sep.className = "sep"; sep.innerHTML = '<td colspan="' + head.length + '"></td>'; tb.appendChild(sep); out.extra.forEach(r => addRow(tb, r, head.length)); }
        else rows.forEach(r => addRow(tb, r, head.length));
      }
      c._last = { v: rawVals(c, panel), out };
      if (c.after) { try { c.after(v, out, data); } catch (e) {} }
      updateActions();
    };
    const addRow = (tb, r, n) => { const tr = document.createElement("tr"); for (let i = 0; i < n; i++) { const td = document.createElement("td"); td.textContent = r[i] != null ? r[i] : ""; tr.appendChild(td); } tb.appendChild(tr); };
    panel.addEventListener("input", recalc); panel.addEventListener("change", recalc);
    panel.addEventListener("click", e => { const o = e.target.closest("[data-open]"); if (o) { e.preventDefault(); go(o.dataset.open); } });
    built[c.id] = { panel, recalc };
    recalc();
  }

  // ---- open / router ----
  const head = $("calc-head");
  function open(id, params, noHash) {
    if (id !== "estimate" && !byId[id]) id = "strength";
    current = id;
    const cc = byId[id] ? byId[id].cat : null;
    if (cc !== lastCat) { navOpen = {}; lastCat = cc; }
    document.querySelectorAll(".tab-panel").forEach(p => p.hidden = true);
    const c = byId[id];
    if (id === "estimate") { renderEstimate(); $("tab-estimate").hidden = false; }
    else if (c.legacy) { $("tab-" + id).hidden = false; }
    else if (c.custom) {
      if (!built[id]) { const p = document.createElement("div"); p.className = "tab-panel gen"; p.id = "tab-" + id; main.appendChild(p); built[id] = { panel: p, recalc() {} }; c.render(p, { open: go, setItems: items => { c._last = { v: {}, out: { items } }; updateActions(); } }); }
      built[id].panel.hidden = false;
    }
    else {
      if (!built[id]) build(c, params);
      else if (params) { const p = built[id].panel; Object.entries(params).forEach(([k, val]) => { const el = p.querySelector('[data-k="' + k + '"]'); if (el) { if (el.type === "checkbox") el.checked = val === "1"; else el.value = val; } }); built[id].recalc(); }
      built[id].panel.hidden = false;
    }
    if (!MP) {
      $("calc-title").textContent = id === "estimate" ? "Смета материалов" : c.name;
      $("calc-desc").textContent = id === "estimate" ? "Всё, что вы добавили из калькуляторов. Укажите цены — получится сумма." : c.desc;
    }
    if ($("menu-cur")) $("menu-cur").textContent = id === "estimate" ? "Смета" : c.name;
    if (id !== "estimate") { const rec = (store.get("recent") || []).filter(x => x !== id); rec.unshift(id); store.set("recent", rec.slice(0, 6)); }
    store.set("tab", id);
    if (!noHash && !MP) { try { history.replaceState(null, "", "#" + id); } catch (e) {} }
    renderNav(); updateActions();
    if (window.innerWidth < 900) window.scrollTo({ top: 0 });
  }
  window.App = { open: go };

  // ---- actions: add to estimate / share ----
  function currentItems() {
    if (!current || current === "estimate") return [];
    const c = byId[current];
    if (c.legacy) return (window.__legacy[current] || []).map(i => Array.isArray(i) ? i : [i.name, i.qty, i.unit]);
    return (c._last && c._last.out.items) || [];
  }
  function updateActions() {
    const items = currentItems().filter(i => i[1] > 0);
    if (!$("act-add")) return;
    $("act-add").hidden = !items.length;
    $("act-share").hidden = current === "estimate" || current === "strength" || !!(byId[current] && byId[current].custom);
  }
  // legacy calculators notify through this hook
  window.__legacyChanged = () => { if (current && byId[current] && byId[current].legacy) updateActions(); };

  let toastT;
  function toast(msg) { const t = $("toast"); t.textContent = msg; t.classList.add("show"); clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove("show"), 2600); }

  on("act-add", "click", () => {
    const items = currentItems().filter(i => i[1] > 0);
    const est = store.get("estimate") || [];
    const src = byId[current].name;
    items.forEach(i => est.push({ src, name: String(i[0]), qty: Number(i[1]), unit: i[2], price: "" }));
    store.set("estimate", est);
    updateBadge();
    toast("В смету добавлено позиций: " + items.length);
    goal("add_to_estimate");
  });

  function shareText() {
    const c = byId[current];
    let lines = [c.name];
    if (!c.legacy && !c.custom && c._last) {
      c.inputs.forEach(f => {
        const box = built[c.id].panel.querySelector('[data-f="' + f.k + '"]');
        if (box.hidden) return;
        const lbl = typeof f.label === "function" ? f.label(readVals(c, built[c.id].panel)) : f.label;
        let val = c._last.v[f.k];
        if (f.type === "sel") { const o = f.opts.find(o => String(o[0]) === String(val)); val = o ? o[1] : val; }
        if (f.type === "check") val = val === "1" ? "да" : "нет";
        lines.push("• " + lbl + ": " + val);
      });
      lines.push("");
      (c._last.out.stats || []).forEach(s => lines.push(s.label + ": " + s.value + (s.unit ? " " + s.unit : "") + (s.sub ? " (" + s.sub + ")" : "")));
    } else {
      currentItems().forEach(i => lines.push("• " + i[0] + ": " + (typeof i[1] === "number" ? i[1].toLocaleString("ru-RU") : i[1]) + " " + i[2]));
    }
    let link = "";
    try {
      const base = location.href.split("#")[0];
      const qs = !c.legacy && !c.custom && c._last ? "?" + new URLSearchParams(c._last.v).toString() : "";
      if (/^https?:/.test(base)) link = MP ? location.origin + location.pathname + qs : base + "#" + current + qs;
    } catch (e) {}
    if (link) lines.push("", link);
    return lines.join("\n");
  }
  async function copy(text) {
    try { await navigator.clipboard.writeText(text); toast("Скопировано — вставьте в мессенджер"); return; } catch (e) {}
    const box = $("copy-box"); box.querySelector("textarea").value = text; box.hidden = false; box.querySelector("textarea").select();
  }
  on("act-share", "click", () => { goal("share"); copy(shareText()); });
  on("copy-close", "click", () => { $("copy-box").hidden = true; });

  // ---- estimate ----
  function updateBadge() { const b = $("est-badge"); if (b) { const n = (store.get("estimate") || []).length; b.textContent = n || ""; b.hidden = !n; } }
  function renderEstimate() {
    const est = store.get("estimate") || [];
    const tb = $("est-body"); tb.innerHTML = "";
    $("est-empty").hidden = !!est.length; $("est-wrap").hidden = !est.length;
    let total = 0, src = null;
    est.forEach((it, i) => {
      if (it.src !== src) { src = it.src; const h = document.createElement("tr"); h.className = "grp"; h.innerHTML = '<td colspan="6"></td>'; h.firstChild.textContent = src; tb.appendChild(h); }
      const sum = num(it.qty) * num(it.price); total += sum;
      const tr = document.createElement("tr");
      tr.innerHTML = '<td class="nm"></td><td><input class="ein" data-i="' + i + '" data-f="qty" inputmode="decimal"></td><td class="u"></td><td><input class="ein" data-i="' + i + '" data-f="price" inputmode="decimal" placeholder="—"></td><td class="sm"></td><td><button type="button" class="rdel" data-del="' + i + '" aria-label="Удалить">×</button></td>';
      tr.querySelector(".nm").textContent = it.name; tr.querySelector(".u").textContent = it.unit;
      tr.querySelector('[data-f="qty"]').value = String(it.qty).replace(".", ",");
      tr.querySelector('[data-f="price"]').value = it.price ? String(it.price).replace(".", ",") : "";
      tr.querySelector(".sm").textContent = sum ? nint(sum) + " ₽" : "";
      tb.appendChild(tr);
    });
    $("est-total").textContent = total ? nint(total) + " ₽" : "—";
    updateBadge();
  }
  on("est-body", "change", e => {
    const t = e.target; if (!t.dataset.f) return;
    const est = store.get("estimate") || []; const it = est[+t.dataset.i]; if (!it) return;
    it[t.dataset.f] = t.dataset.f === "price" ? (t.value.trim() ? num(t.value) : "") : num(t.value);
    store.set("estimate", est); renderEstimate();
  });
  on("est-body", "click", e => {
    const d = e.target.closest("[data-del]"); if (!d) return;
    const est = store.get("estimate") || []; est.splice(+d.dataset.del, 1); store.set("estimate", est); renderEstimate();
  });
  on("est-clear", "click", () => { if ($("est-clear").dataset.arm) { store.set("estimate", []); delete $("est-clear").dataset.arm; $("est-clear").textContent = "Очистить"; renderEstimate(); } else { $("est-clear").dataset.arm = "1"; $("est-clear").textContent = "Точно очистить?"; setTimeout(() => { delete $("est-clear").dataset.arm; $("est-clear").textContent = "Очистить"; }, 3000); } });
  on("est-copy", "click", () => {
    const est = store.get("estimate") || []; let src = null, total = 0; const lines = ["Смета материалов"];
    est.forEach(it => { if (it.src !== src) { src = it.src; lines.push("", src + ":"); } const s = num(it.qty) * num(it.price); total += s; lines.push("• " + it.name + " — " + num(it.qty).toLocaleString("ru-RU") + " " + it.unit + (s ? " × " + nint(it.price) + " ₽ = " + nint(s) + " ₽" : "")); });
    if (total) lines.push("", "Итого: " + nint(total) + " ₽");
    copy(lines.join("\n"));
  });
  on("est-print", "click", () => { try { window.print(); } catch (e) { toast("Печать недоступна на этой странице"); } });

  // ---- start ----
  function fromHash() {
    const h = decodeURIComponent((location.hash || "").slice(1));
    if (!h) return null;
    const [id, qs] = h.split("?");
    const params = qs ? Object.fromEntries(new URLSearchParams(qs)) : null;
    return { id, params };
  }
  if (MP) {
    const sp = new URLSearchParams(location.search), params = sp.toString() ? Object.fromEntries(sp) : null;
    if (MP.id) open(MP.id, params, true); else { if (MP.cat) navOpen[MP.cat] = true; renderNav(); }
    let used = false;
    document.addEventListener("input", e => { if (!used && e.target.closest && e.target.closest(".main")) { used = true; goal("calc_used"); } });
  } else {
    const start = fromHash();
    open(start && (byId[start.id] || start.id === "estimate") ? start.id : (store.get("tab") || "strength"), start && start.params, false);
    window.addEventListener("hashchange", () => { const h = fromHash(); if (h && (h.id !== current || h.params)) open(h.id, h.params, true); });
  }
})();
</script>
