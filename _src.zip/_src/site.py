# -*- coding: utf-8 -*-
"""Сборка многостраничного сайта SPUTNIK из единой страницы калькуляторов."""
import os, re, json, shutil, datetime, html, sys
sys.path.insert(0, os.path.dirname(__file__))
from content import CATS, PAGES, RELATED
from marks import MARK, GMARK, FAVICON, header, footer
from pict import icon, hero_svg, PICT_CSS, CAT_ICON

SITE = os.environ.get("SITE_URL", "https://example.ru").rstrip("/")
OUT = os.environ.get("OUT", os.path.join(os.path.dirname(os.path.abspath(__file__)), "site"))
HERE = os.path.dirname(os.path.abspath(__file__))
TODAY = datetime.date.today().isoformat()

CAT_ORDER = ["found", "struct", "finish", "glass", "land", "green", "tech", "learn"]
CAT_OF = {}
for cat, ids in {
    "found": ["fselect", "frost", "loads", "fbs", "earth"],
    "struct": ["strength", "volume", "mix", "rebar", "brick", "block", "lintel", "slabs", "roof", "stairs", "lumber"],
    "finish": ["plaster", "screed", "tile", "wallpaper", "paint", "floor", "gkl", "insul"],
    "glass": ["glazing"], "land": ["pie", "septic", "drain"], "green": ["plants", "planting", "border"],
    "tech": ["beam", "slope", "metal", "bulk", "concref", "vent"], "learn": ["ventguide", "slabguide"],
}.items():
    for i in ids: CAT_OF[i] = cat
LEGACY = ["strength", "volume", "mix", "rebar", "brick"]
E = html.escape

def path_of(cid):
    if cid == "estimate": return "smeta/"
    return CATS[CAT_OF[cid]][0] + "/" + PAGES[cid]["slug"] + "/"

URLS = {cid: path_of(cid) for cid in PAGES}
URLS["estimate"] = "smeta/"

# ---------- исходники ----------
body = open(os.path.join(HERE, "body.html"), encoding="utf-8").read()
css = re.search(r"<style>([\s\S]*?)</style>", body).group(1)
scripts = re.findall(r"<script>([\s\S]*?)</script>", body)
assert len(scripts) == 3

def extract_div(src, start_marker):
    i = src.index(start_marker)
    depth, j = 0, i
    for m in re.finditer(r"<div\b|</div>", src[i:]):
        depth += 1 if m.group(0) == "<div" else -1
        if depth == 0:
            return src[i:i + m.end()]
    raise ValueError(start_marker)

LEG_HTML = {lid: extract_div(body, '<div class="tab-panel" id="tab-%s"' % lid) for lid in LEGACY}
EST_HTML = extract_div(body, '<div class="tab-panel" id="tab-estimate"')

FONT_FACES = ""
CYR = "U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116"
LAT = "U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD"
for fam, file, weights in [("Montserrat", "montserrat", [400, 500, 600, 700, 800]), ("Cormorant Garamond", "cormorant-garamond", [600])]:
    for w in weights:
        for sub, rng in [("cyrillic", CYR), ("latin", LAT)]:
            FONT_FACES += "@font-face{font-family:'%s';font-style:normal;font-weight:%d;font-display:swap;src:url(fonts/%s-%s-%d-normal.woff2) format('woff2');unicode-range:%s}\n" % (fam, w, file, sub, w, rng)

CONFIG_JS = """/* Настройки сайта SPUTNIK.
   METRIKA_ID — номер счётчика Яндекс.Метрики (только цифры). 0 — Метрика выключена. */
window.METRIKA_ID = 113535749;
(function () {
  if (!window.METRIKA_ID) return;
  (function (m, e, t, r, i, k, a) { m[i] = m[i] || function () { (m[i].a = m[i].a || []).push(arguments); }; m[i].l = 1 * new Date();
    for (var j = 0; j < document.scripts.length; j++) { if (document.scripts[j].src === r) { return; } }
    k = e.createElement(t), a = e.getElementsByTagName(t)[0], k.async = 1, k.src = r, a.parentNode.insertBefore(k, a); })
  (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");
  window.ym(window.METRIKA_ID, "init", { clickmap: true, trackLinks: true, accurateTrackBounce: true, webvisor: true });
})();
"""

# ---------- имена калькуляторов из JS ----------
NAMES = {}
for m in re.finditer(r'id: "(\w+)", cat: "\w+",[^\n]*?name: "([^"]+)"', scripts[2]):
    NAMES[m.group(1)] = m.group(2)
for cid in PAGES: NAMES.setdefault(cid, PAGES[cid]["h1"])
MARKS = {m.group(1): m.group(2) for m in re.finditer(r'id: "(\w+)", cat: "\w+",[^\n]*?mark: "([^"]+)"', scripts[2])}

def side_nav(root, cur=None):
    out = ['<a class="nav-item est" href="%ssmeta/"><span class="nav-name">Смета материалов</span></a>' % root]
    for cat in CAT_ORDER:
        slug, title, _ = CATS[cat]
        ids = [i for i in PAGES if CAT_OF[i] == cat]
        out.append('<a class="nav-cat%s" href="%s%s/"><span class="nc-t">%s</span><span class="nc-n">%d</span></a>' % (" cur" if cur and CAT_OF.get(cur) == cat else "", root, slug, E(title), len(ids)))
        out.append('<div class="nav-grp">' + "".join('<a class="nav-item%s" href="%s%s"><span class="nav-name">%s</span></a>' % (" on" if i == cur else "", root, URLS[i], E(NAMES[i])) for i in ids) + "</div>")
    return "\n".join(out)

def foot_links(root):
    return ('<a href="%so-proekte/">О проекте</a><a href="%skontakty/">Контакты</a><a href="%spolitika-konfidencialnosti/">Политика конфиденциальности</a><a href="%ssitemap.xml">Карта сайта</a>' % (root, root, root, root))

def crumbs(root, items):
    parts = ['<a href="%s">Главная</a>' % (root or "./")]
    for href, name in items:
        parts.append('<span aria-hidden="true">/</span>')
        parts.append('<a href="%s">%s</a>' % (href, E(name)) if href else '<span aria-current="page">%s</span>' % E(name))
    return '<nav class="crumbs" aria-label="Навигация">' + "".join(parts) + "</nav>"

def ld_breadcrumbs(items):
    lst = [{"@type": "ListItem", "position": i + 1, "name": n, "item": SITE + "/" + u} for i, (u, n) in enumerate([("", "Главная")] + items)]
    return {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": lst}

def page(root, rel, title, desc, main, page_id=None, ld=(), og_type="website", noindex=False, cat=None):
    canon = SITE + "/" + rel
    ld_html = "".join('<script type="application/ld+json">%s</script>\n' % json.dumps(x, ensure_ascii=False) for x in ld)
    pg = {"id": page_id, "root": root, "urls": URLS, "cat": cat}
    return f"""<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{E(title)}</title>
<meta name="description" content="{E(desc)}">
<link rel="canonical" href="{canon}">
{'<meta name="robots" content="noindex">' if noindex else ''}
<meta property="og:type" content="{og_type}">
<meta property="og:site_name" content="SPUTNIK">
<meta property="og:title" content="{E(title)}">
<meta property="og:description" content="{E(desc)}">
<meta property="og:url" content="{canon}">
<meta property="og:image" content="{SITE}/assets/og.png">
<meta property="og:locale" content="ru_RU">
<meta name="twitter:card" content="summary_large_image">
<link rel="icon" href="{root}favicon.svg" type="image/svg+xml">
<link rel="apple-touch-icon" href="{root}apple-touch-icon.png">
<meta name="theme-color" content="#F4F1EC" media="(prefers-color-scheme: light)">
<meta name="theme-color" content="#15181B" media="(prefers-color-scheme: dark)">
<link rel="preload" href="{root}assets/fonts/montserrat-cyrillic-400-normal.woff2" as="font" type="font/woff2" crossorigin>
<link rel="stylesheet" href="{root}assets/app.css">
<script src="{root}assets/config.js"></script>
{ld_html}</head>
<body>
<div class="page">
  {header(root or './')}
  <div class="app">
    <aside class="side" aria-label="Калькуляторы">
      <div class="side-search"><input type="search" id="side-q" placeholder="Поиск по калькуляторам" aria-label="Поиск по калькуляторам"><kbd>/</kbd></div>
      <nav id="side-nav">{side_nav(root, page_id)}</nav>
    </aside>
    <div class="drawer-bg" id="drawer-bg"></div>
    <main class="main" id="main">
{main}
      {footer(foot_links(root))}
    </main>
  </div>
</div>
<div class="toast" id="toast" role="status"></div>
<div class="copy-box" id="copy-box" hidden><div class="copy-in"><div class="card-title">Скопируйте текст</div><textarea readonly></textarea><button type="button" class="btn sm" id="copy-close">Закрыть</button></div></div>
<script>window.PAGE = {json.dumps(pg, ensure_ascii=False)};</script>
<script src="{root}assets/app.js"></script>
</body>
</html>
"""

def write(rel, text):
    p = os.path.join(OUT, rel)
    if rel.endswith("/") or rel == "": p = os.path.join(p, "index.html")
    os.makedirs(os.path.dirname(p), exist_ok=True)
    open(p, "w", encoding="utf-8").write(text)

def cards(ids, root):
    return '<div class="cards">' + "".join('<a class="ccard" href="%s%s"><div class="ccard-top">%s%s</div><b>%s</b><span>%s</span></a>' % (root, URLS[i], icon(i), ('<em>%s</em>' % E(MARKS[i]) if i in MARKS else ""), E(NAMES[i]), E(PAGES[i]["desc"])) for i in ids) + "</div>"

def build():
    if os.path.exists(OUT): shutil.rmtree(OUT)
    os.makedirs(os.path.join(OUT, "assets", "fonts"))
    for f in os.listdir(os.path.join(HERE, "site_assets", "fonts")):
        shutil.copy(os.path.join(HERE, "site_assets", "fonts", f), os.path.join(OUT, "assets", "fonts", f))
    open(os.path.join(OUT, "assets", "app.css"), "w", encoding="utf-8").write(FONT_FACES + css + PICT_CSS)
    open(os.path.join(OUT, "assets", "app.js"), "w", encoding="utf-8").write("\n".join(scripts))
    open(os.path.join(OUT, "assets", "config.js"), "w", encoding="utf-8").write(CONFIG_JS)
    open(os.path.join(OUT, "favicon.svg"), "w", encoding="utf-8").write(FAVICON)
    urls = [""]

    # ---- калькуляторы
    for cid, c in PAGES.items():
        cat = CAT_OF[cid]; cslug, ctitle, _ = CATS[cat]
        rel = URLS[cid]; root = "../../"
        title = "%s — SPUTNIK" % c["h1"]
        if cid in LEGACY: panel = re.sub(r'^(<div class="tab-panel" id="tab-\w+")\s+hidden>', r'\1>', LEG_HTML[cid])
        else: panel = ""
        seo = ['<h2>О расчёте</h2><p>%s</p>' % E(c["intro"])]
        if c["steps"]: seo.append("<h2>Как пользоваться</h2><ol>" + "".join("<li>%s</li>" % E(s) for s in c["steps"]) + "</ol>")
        if c["notes"]: seo.append("<h2>На что обратить внимание</h2><ul>" + "".join("<li>%s</li>" % E(s) for s in c["notes"]) + "</ul>")
        if c["faq"]: seo.append('<div class="faq"><h2>Частые вопросы</h2>' + "".join("<details><summary>%s</summary><p>%s</p></details>" % (E(q), E(a)) for q, a in c["faq"]) + "</div>")
        if c["norm"]: seo.append('<p class="norm">Нормативы: %s</p>' % E(c["norm"]))
        rel_ids = [r for r in RELATED.get(cid, []) if r in PAGES]
        related = ('<section aria-label="Связанные расчёты"><div class="sec-h">Посчитайте также</div><div class="related" style="margin-top:8px">' + "".join('<a href="%s%s">%s</a>' % (root, URLS[r], E(NAMES[r])) for r in rel_ids) + "</div></section>") if rel_ids else ""
        main = f"""      {crumbs(root, [(root + cslug + '/', ctitle), (None, c['h1'])])}
      <div class="calc-head">
        <div class="head-ic">{icon(cid, 48)}<div><h1 id="calc-title">{E(c['h1'])}</h1><p id="calc-desc">{E(c['desc'])}</p></div></div>
        <div class="acts"><button type="button" class="btn sm" id="act-add" hidden>Добавить в смету</button><button type="button" class="btn sm ghost" id="act-share" hidden>Поделиться</button></div>
      </div>
      {panel}
      <div id="gen-host"></div>
      <section class="card"><article class="seo">{''.join(seo)}</article></section>
      {related}"""
        ld = [ld_breadcrumbs([(cslug + "/", ctitle), (rel, c["h1"])]),
              {"@context": "https://schema.org", "@type": "WebApplication", "name": c["h1"], "description": c["desc"], "url": SITE + "/" + rel, "applicationCategory": "UtilitiesApplication", "operatingSystem": "Any", "inLanguage": "ru", "isAccessibleForFree": True, "offers": {"@type": "Offer", "price": "0", "priceCurrency": "RUB"}, "publisher": {"@type": "Organization", "name": "SPUTNIK"}}]
        if c["faq"]: ld.append({"@context": "https://schema.org", "@type": "FAQPage", "mainEntity": [{"@type": "Question", "name": q, "acceptedAnswer": {"@type": "Answer", "text": a}} for q, a in c["faq"]]})
        write(rel, page(root, rel, title, c["desc"], main, cid, ld))
        urls.append(rel)

    # ---- разделы
    for cat in CAT_ORDER:
        cslug, ctitle, cdesc = CATS[cat]; root = "../"
        ids = [i for i in PAGES if CAT_OF[i] == cat]
        main = f"""      {crumbs(root, [(None, ctitle)])}
      <div class="calc-head"><div class="head-ic">{icon(CAT_ICON[cat], 48)}<div><h1 id="calc-title">{E(ctitle)}</h1><p id="calc-desc">{E(cdesc)}</p></div></div></div>
      {cards(ids, root)}"""
        write(cslug + "/", page(root, cslug + "/", "%s — SPUTNIK" % ctitle, cdesc, main, None, [ld_breadcrumbs([(cslug + "/", ctitle)])], cat=cat))
        urls.append(cslug + "/")

    # ---- смета
    root = "../"
    main = f"""      {crumbs(root, [(None, 'Смета материалов')])}
      <div class="calc-head"><div class="head-ic">{icon('estimate', 48)}<div><h1 id="calc-title">Смета материалов</h1><p id="calc-desc">Материалы, добавленные из калькуляторов. Укажите цены — получится сумма. Список хранится в вашем браузере.</p></div></div><div class="acts"><button type="button" class="btn sm" id="act-add" hidden>Добавить в смету</button><button type="button" class="btn sm ghost" id="act-share" hidden>Поделиться</button></div></div>
      {re.sub(r'^(<div class="tab-panel" id="tab-estimate")\s+hidden>', r'\1>', EST_HTML)}"""
    write("smeta/", page(root, "smeta/", "Смета материалов — SPUTNIK", "Сводная смета материалов из калькуляторов SPUTNIK: количество, цены и итог.", main, "estimate", noindex=True))

    # ---- главная
    root = ""
    feats = [("По погоде вашего участка", "Набор прочности бетона, промерзание грунта и зона зимостойкости считаются по фактической погоде за последние годы."),
             ("Подбор, а не только объём", "Калькуляторы помогают выбрать решение: тип фундамента, перемычки, толщину стекла, растения для участка."),
             ("Схемы и чертежи", "Раскладка ФБС по рядам, пустотных плит, план цветника, разрезы пирогов и узлы остекления."),
             ("Общая смета", "Материалы из любых расчётов собираются в одну смету с ценами и итогом."),
             ("Расчёт по ссылке", "Расчётом можно поделиться: коллега откроет его с теми же исходными данными."),
             ("Обучение", "Короткие уроки со схемами и тестами: вентиляция, раскладка плит.")]
    sections = "".join('<section><div class="sec-h"><a href="%s/" style="color:inherit;text-decoration:none">%s</a></div><div style="margin-top:12px">%s</div></section>' % (CATS[c][0], E(CATS[c][1]), cards([i for i in PAGES if CAT_OF[i] == c], root)) for c in CAT_ORDER)
    main = f"""      <section class="hero"><h1 id="calc-title">Помощник строителя</h1><p>SPUTNIK — набор инженерных калькуляторов для частного строительства: от выбора фундамента и раскладки блоков до отделки, остекления и озеленения участка. Расчёты выполняются в браузере, с пояснениями и ссылками на нормативы.</p></section>
      <section class="card">{hero_svg({c: CATS[c][0] + '/' for c in CAT_ORDER})}</section>
      <section class="card"><div class="feat">{''.join('<div><b>%s</b><span>%s</span></div>' % (E(a), E(b)) for a, b in feats)}</div></section>
      {sections}"""
    ld = [{"@context": "https://schema.org", "@type": "WebSite", "name": "SPUTNIK", "alternateName": "Спутник — помощник строителя", "url": SITE + "/", "inLanguage": "ru"},
          {"@context": "https://schema.org", "@type": "Organization", "name": "SPUTNIK", "url": SITE + "/", "logo": SITE + "/favicon.svg", "parentOrganization": {"@type": "Organization", "name": "GURYANOW GROUP"}}]
    write("", page(root, "", "SPUTNIK — помощник строителя: калькуляторы и расчёты", "Инженерные калькуляторы для частного строительства: фундамент, бетон, кладка, перемычки, плиты, кровля, отделка, остекление, благоустройство и озеленение.", main, None, ld))

    # ---- служебные
    root = "../"
    about = f"""      {crumbs(root, [(None, 'О проекте')])}
      <div class="calc-head"><div><h1 id="calc-title">О проекте</h1><p id="calc-desc">SPUTNIK — технологическое направление GURYANOW GROUP.</p></div></div>
      <section class="card"><article class="seo">
        <h2>Что это</h2><p>SPUTNIK — помощник строителя: набор калькуляторов и обучающих материалов для частного строительства. Мы делаем инструменты, которые не только считают объём материалов, но и помогают выбрать решение и понять, почему оно такое.</p>
        <h2>Как устроены расчёты</h2><ul><li>Расчёты выполняются в вашем браузере. Введённые данные не отправляются на сервер, кроме координат населённого пункта для запроса погоды.</li><li>Методики основаны на действующих сводах правил и ГОСТ; ссылки на нормативы приведены на страницах калькуляторов.</li><li>Результаты носят справочный характер. Проектные решения принимает проектировщик по данным инженерных изысканий.</li></ul>
        <h2>Автор</h2><p>Проект ведёт инженер-строитель с опытом управления строительными проектами. <!-- Здесь можно указать имя, фото и опыт автора. --></p>
        <h2>Обратная связь</h2><p>Если вы нашли ошибку в расчёте или хотите предложить новый калькулятор, напишите нам — контакты на странице <a href="../kontakty/">Контакты</a>.</p>
      </article></section>"""
    write("o-proekte/", page(root, "o-proekte/", "О проекте — SPUTNIK", "SPUTNIK — помощник строителя, технологическое направление GURYANOW GROUP. Как устроены расчёты и кто ведёт проект.", about, None, [ld_breadcrumbs([("o-proekte/", "О проекте")])]))
    contacts = f"""      {crumbs(root, [(None, 'Контакты')])}
      <div class="calc-head"><div><h1 id="calc-title">Контакты</h1><p id="calc-desc">Вопросы, замечания к расчётам и предложения по сотрудничеству.</p></div></div>
      <section class="card"><article class="seo"><p>Электронная почта: <a href="mailto:GAE.100@yandex.ru">GAE.100@yandex.ru</a></p><p>Для партнёров — производителей ЖБИ, бетонных заводов, питомников и поставщиков: калькуляторы SPUTNIK можно разместить на вашем сайте. Напишите нам, чтобы обсудить условия.</p></article></section>"""
    write("kontakty/", page(root, "kontakty/", "Контакты — SPUTNIK", "Связаться с проектом SPUTNIK: вопросы по расчётам и сотрудничество.", contacts, None, [ld_breadcrumbs([("kontakty/", "Контакты")])]))
    policy = f"""      {crumbs(root, [(None, 'Политика конфиденциальности')])}
      <div class="calc-head"><div><h1 id="calc-title">Политика конфиденциальности</h1><p id="calc-desc">Редакция от {datetime.date.today().strftime('%d.%m.%Y')}.</p></div></div>
      <section class="card"><article class="seo">
        <h2>1. Общие положения</h2><p>Настоящая политика описывает, какие данные обрабатываются при использовании сайта SPUTNIK (далее — Сайт), и составлена в соответствии с Федеральным законом от 27.07.2006 № 152-ФЗ «О персональных данных». Оператор — владелец Сайта; контакты указаны на странице «Контакты».</p>
        <h2>2. Какие данные обрабатываются</h2><ul><li>Данные, которые вы вводите в калькуляторы, обрабатываются только в вашем браузере и хранятся в его локальном хранилище (localStorage) для удобства. На сервер они не передаются.</li><li>Для калькуляторов, использующих погоду, координаты выбранного населённого пункта передаются сервису Open-Meteo. Ваше местоположение не определяется.</li><li>Сайт может использовать сервис веб-аналитики Яндекс.Метрика, который с помощью файлов cookie собирает обезличенные сведения: IP-адрес, тип браузера и устройства, посещённые страницы, действия на сайте.</li></ul>
        <h2>3. Цели обработки</h2><p>Анализ посещаемости и улучшение работы Сайта.</p>
        <h2>4. Согласие и отказ</h2><p>Продолжая пользоваться Сайтом, вы соглашаетесь на обработку данных в описанном объёме. Вы можете отключить cookie в настройках браузера и очистить локальное хранилище — это не помешает работе калькуляторов, кроме сохранения введённых значений.</p>
        <h2>5. Передача третьим лицам</h2><p>Данные не продаются и не передаются третьим лицам, кроме сервисов, указанных в разделе 2, в объёме, необходимом для их работы.</p>
        <h2>6. Контакты</h2><p>По вопросам обработки данных пишите на адрес, указанный на странице «Контакты».</p>
      </article></section>"""
    write("politika-konfidencialnosti/", page(root, "politika-konfidencialnosti/", "Политика конфиденциальности — SPUTNIK", "Политика конфиденциальности сайта SPUTNIK.", policy, None))
    urls += ["o-proekte/", "kontakty/", "politika-konfidencialnosti/"]

    # ---- 404 (корневые ссылки)
    from urllib.parse import urlparse
    base = (urlparse(SITE).path.rstrip("/") + "/") or "/"
    nf = page(base, "404", "Страница не найдена — SPUTNIK", "Страница не найдена.", """      <div class="calc-head"><div><h1 id="calc-title">Страница не найдена</h1><p id="calc-desc">Возможно, адрес изменился. Воспользуйтесь поиском слева или перейдите на <a href="' + base + '">главную</a>.</p></div></div>""".replace("' + base + '", base), None, noindex=True)
    open(os.path.join(OUT, "404.html"), "w", encoding="utf-8").write(nf)

    # ---- sitemap, robots
    sm = ['<?xml version="1.0" encoding="UTF-8"?>', '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">']
    for u in urls:
        pr = "1.0" if u == "" else "0.8" if u.count("/") == 2 else "0.6"
        sm.append("  <url><loc>%s/%s</loc><lastmod>%s</lastmod><priority>%s</priority></url>" % (SITE, u, TODAY, pr))
    sm.append("</urlset>")
    open(os.path.join(OUT, "sitemap.xml"), "w", encoding="utf-8").write("\n".join(sm) + "\n")
    open(os.path.join(OUT, "robots.txt"), "w", encoding="utf-8").write("User-agent: *\nDisallow: /smeta/\nAllow: /\n\nSitemap: %s/sitemap.xml\n" % SITE)
    print("pages:", len(urls) + 2)

if __name__ == "__main__":
    build()
