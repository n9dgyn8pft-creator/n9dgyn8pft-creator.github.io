#!/bin/sh
# Сборка сайта SPUTNIK. Запускать из папки _src:  sh make.sh  [https://адрес-сайта]
# Результат копируется в корень репозитория (на уровень выше), папки _src и .git не трогаются.
set -e
cd "$(dirname "$0")"
[ -n "$1" ] && export SITE_URL="$1"
python3 build.py            # собирает body.html (одностраничная версия) из base.html + app.js + модулей
python3 site.py             # собирает многостраничный сайт в ./site
python3 icons.py || echo "иконки и og.png не пересобраны (нужен playwright) — используются прежние"
cd site
for f in * .[!.]*; do [ -e "$f" ] || continue; rm -rf "../../$f"; cp -R "$f" "../../$f"; done
echo "Готово: сайт обновлён в корне репозитория."
